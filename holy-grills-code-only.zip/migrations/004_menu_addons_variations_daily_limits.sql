-- ─────────────────────────────────────────────────────────────────────────────
-- Migration 004: Menu add-ons, variation groups, daily limits, kitchen capacity
-- ─────────────────────────────────────────────────────────────────────────────

-- 1. Daily limit per menu item (null = unlimited)
ALTER TABLE menu_items ADD COLUMN IF NOT EXISTS daily_limit integer DEFAULT NULL;

-- 2. Optional add-ons: standalone extras customers can append to any order
--    e.g. "Extra Sauce", "Bottled Water", "Foam Container"
CREATE TABLE IF NOT EXISTS menu_addons (
    id          uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
    name        text        NOT NULL,
    description text        DEFAULT '',
    price       numeric(10,2) NOT NULL DEFAULT 0,
    is_available boolean   DEFAULT true,
    is_archived boolean    DEFAULT false,
    sort_order  integer    DEFAULT 0,
    created_at  timestamptz DEFAULT now(),
    updated_at  timestamptz DEFAULT now()
);

-- 3. Variation groups attached to a menu item
--    e.g. a combo that lets customers choose which side accompanies their meal
CREATE TABLE IF NOT EXISTS menu_item_variation_groups (
    id              uuid    PRIMARY KEY DEFAULT gen_random_uuid(),
    menu_item_id    uuid    NOT NULL REFERENCES menu_items(id) ON DELETE CASCADE,
    name            text    NOT NULL,              -- "Choose your side"
    is_required     boolean DEFAULT false,          -- must the customer pick?
    min_selections  integer DEFAULT 0,
    max_selections  integer DEFAULT 1,
    sort_order      integer DEFAULT 0,
    created_at      timestamptz DEFAULT now()
);

-- 4. Individual options within a variation group
--    e.g. Coleslaw (₦0 extra), Plantain (₦200 extra), Jollof Rice (₦0 extra)
CREATE TABLE IF NOT EXISTS menu_item_variation_options (
    id                  uuid    PRIMARY KEY DEFAULT gen_random_uuid(),
    variation_group_id  uuid    NOT NULL REFERENCES menu_item_variation_groups(id) ON DELETE CASCADE,
    name                text    NOT NULL,          -- "Coleslaw"
    price_delta         numeric(10,2) DEFAULT 0,  -- extra charge (0 = included)
    is_available        boolean DEFAULT true,
    sort_order          integer DEFAULT 0,
    created_at          timestamptz DEFAULT now()
);

-- 5. Kitchen settings store (key-value for daily capacity, etc.)
CREATE TABLE IF NOT EXISTS kitchen_settings (
    key         text        PRIMARY KEY,
    value       text        NOT NULL DEFAULT '',
    updated_at  timestamptz DEFAULT now(),
    updated_by  uuid        REFERENCES profiles(id)
);

-- Seed default capacity (150 orders/day; admin can change via API)
INSERT INTO kitchen_settings (key, value)
VALUES ('daily_order_capacity', '150')
ON CONFLICT (key) DO NOTHING;

-- 6. Extend order_items to store chosen variations and flag add-on rows
ALTER TABLE order_items
    ADD COLUMN IF NOT EXISTS selected_variations jsonb   DEFAULT '[]'::jsonb,
    ADD COLUMN IF NOT EXISTS is_addon            boolean DEFAULT false,
    ADD COLUMN IF NOT EXISTS addon_id            uuid    REFERENCES menu_addons(id);

-- Allow menu_item_id to be nullable so add-on rows can exist without a menu item
ALTER TABLE order_items ALTER COLUMN menu_item_id DROP NOT NULL;

-- Indexes
CREATE INDEX IF NOT EXISTS idx_menu_item_variation_groups_item ON menu_item_variation_groups(menu_item_id);
CREATE INDEX IF NOT EXISTS idx_menu_item_variation_options_group ON menu_item_variation_options(variation_group_id);
CREATE INDEX IF NOT EXISTS idx_menu_addons_available ON menu_addons(is_available, is_archived);
