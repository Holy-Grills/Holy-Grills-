-- ─────────────────────────────────────────────────────────────────────────────
-- Migration 005: Security fixes, RLS gaps, missing tables, advisor corrections
-- Apply AFTER 004_menu_addons_variations_daily_limits.sql
-- ─────────────────────────────────────────────────────────────────────────────

-- ══════════════════════════════════════════════════════════════════════════════
-- 1. MISSING TABLE: cron_locks  (Celery distributed-lock table)
-- ══════════════════════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS cron_locks (
    lock_name   text        PRIMARY KEY,
    locked_at   timestamptz NOT NULL DEFAULT now(),
    locked_until timestamptz NOT NULL,
    locked_by   text        NOT NULL DEFAULT ''   -- worker hostname
);
ALTER TABLE cron_locks ENABLE ROW LEVEL SECURITY;
-- Only server (service role) should read/write locks — no client access
-- RLS enabled + no policies = fully blocked for anon/user JWT (server uses service role)


-- ══════════════════════════════════════════════════════════════════════════════
-- 2. SECURITY FIX: Remove orders_own_insert RLS policy
--    VULNERABILITY: Allowed authenticated users to INSERT orders directly,
--    bypassing payment validation, price checks, stock checks, and HP logic.
--    Orders must only be created via the backend API (service role key).
-- ══════════════════════════════════════════════════════════════════════════════
DROP POLICY IF EXISTS orders_own_insert ON orders;


-- ══════════════════════════════════════════════════════════════════════════════
-- 3. SECURITY FIX: order_reviews — restrict from ALL to SELECT + INSERT only
--    Prevents users from UPDATE-ing their own rating after submission or
--    DELETE-ing their review to escape accountability.
-- ══════════════════════════════════════════════════════════════════════════════
DROP POLICY IF EXISTS reviews_own ON order_reviews;

CREATE POLICY reviews_own_select ON order_reviews
    FOR SELECT USING (user_id = auth.uid());

CREATE POLICY reviews_own_insert ON order_reviews
    FOR INSERT WITH CHECK (user_id = auth.uid());


-- ══════════════════════════════════════════════════════════════════════════════
-- 4. RLS POLICIES — tables with RLS enabled but NO policies
--    (RLS on + no policies = fully blocked for JWT callers, safe but broken)
-- ══════════════════════════════════════════════════════════════════════════════

-- hall_of_fame: Public read (it's a leaderboard), admin writes
CREATE POLICY hall_of_fame_public_read ON hall_of_fame
    FOR SELECT USING (true);

CREATE POLICY hall_of_fame_admin_write ON hall_of_fame
    FOR ALL USING (is_admin());

-- flash_redemptions: Own read, admin all
CREATE POLICY flash_redemptions_own_read ON flash_redemptions
    FOR SELECT USING (user_id = auth.uid() OR is_admin());

CREATE POLICY flash_redemptions_admin_write ON flash_redemptions
    FOR ALL USING (is_admin());

-- hp_bundle_purchases: Own read, admin all
CREATE POLICY hp_bundle_own_read ON hp_bundle_purchases
    FOR SELECT USING (event_host_id = auth.uid() OR is_admin());

CREATE POLICY hp_bundle_admin_write ON hp_bundle_purchases
    FOR ALL USING (is_admin());

-- hp_unlock_log: Own read, admin all
CREATE POLICY hp_unlock_log_own_read ON hp_unlock_log
    FOR SELECT USING (user_id = auth.uid() OR is_admin());

CREATE POLICY hp_unlock_log_admin_write ON hp_unlock_log
    FOR ALL USING (is_admin());

-- leaderboard_monthly: Public read (monthly leaderboard), admin write
CREATE POLICY leaderboard_monthly_public_read ON leaderboard_monthly
    FOR SELECT USING (true);

CREATE POLICY leaderboard_monthly_admin_write ON leaderboard_monthly
    FOR ALL USING (is_admin());

-- spin_win_entries: Own read, admin all
CREATE POLICY spin_win_own_read ON spin_win_entries
    FOR SELECT USING (user_id = auth.uid() OR is_admin());

CREATE POLICY spin_win_admin_write ON spin_win_entries
    FOR ALL USING (is_admin());


-- ══════════════════════════════════════════════════════════════════════════════
-- 5. RLS POLICIES — migration 004 tables (no policies were added in mig 004)
-- ══════════════════════════════════════════════════════════════════════════════

-- menu_addons: Public read (active, non-archived), admin write
ALTER TABLE menu_addons ENABLE ROW LEVEL SECURITY;

CREATE POLICY menu_addons_public_read ON menu_addons
    FOR SELECT USING (is_available = true AND is_archived = false OR is_admin());

CREATE POLICY menu_addons_admin_write ON menu_addons
    FOR ALL USING (is_admin());

-- menu_item_variation_groups: Public read, admin write
ALTER TABLE menu_item_variation_groups ENABLE ROW LEVEL SECURITY;

CREATE POLICY variation_groups_public_read ON menu_item_variation_groups
    FOR SELECT USING (true);

CREATE POLICY variation_groups_admin_write ON menu_item_variation_groups
    FOR ALL USING (is_admin());

-- menu_item_variation_options: Public read, admin write
ALTER TABLE menu_item_variation_options ENABLE ROW LEVEL SECURITY;

CREATE POLICY variation_options_public_read ON menu_item_variation_options
    FOR SELECT USING (true);

CREATE POLICY variation_options_admin_write ON menu_item_variation_options
    FOR ALL USING (is_admin());

-- kitchen_settings: Kitchen + admin read, admin write only
ALTER TABLE kitchen_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY kitchen_settings_read ON kitchen_settings
    FOR SELECT USING (is_admin() OR is_kitchen());

CREATE POLICY kitchen_settings_admin_write ON kitchen_settings
    FOR ALL USING (is_admin());


-- ══════════════════════════════════════════════════════════════════════════════
-- 6. RLS POLICIES — other tables with inadequate policies
-- ══════════════════════════════════════════════════════════════════════════════

-- pending_hp_transactions: Own read only (server writes via service role)
CREATE POLICY pending_hp_own_read ON pending_hp_transactions
    FOR SELECT USING (user_id = auth.uid() OR is_admin());

-- user_addresses: Own CRUD, admin read all
CREATE POLICY addresses_public_read ON user_addresses
    FOR SELECT USING (user_id = auth.uid() OR is_admin());

CREATE POLICY addresses_own_all ON user_addresses
    FOR ALL USING (user_id = auth.uid());


-- ══════════════════════════════════════════════════════════════════════════════
-- 7. CONSTRAINT HARDENING — close remaining data-integrity gaps
-- ══════════════════════════════════════════════════════════════════════════════

-- Prevent negative pending HP balance at DB level (belt + suspenders)
ALTER TABLE profiles
    ADD CONSTRAINT IF NOT EXISTS chk_pending_hp_non_negative
        CHECK (pending_hp_balance >= 0);

-- Prevent hp_overflow going negative
ALTER TABLE profiles
    ADD CONSTRAINT IF NOT EXISTS chk_hp_overflow_non_negative
        CHECK (hp_overflow >= 0);

-- Ensure referral completions are de-duplicated
ALTER TABLE referrals
    ADD CONSTRAINT IF NOT EXISTS uq_referral_pair
        UNIQUE (referrer_id, referred_user_id);

-- Prevent a user from completing the same challenge twice (beyond max_completions)
-- Already handled by app logic, but enforce UNIQUE if max_completions_per_user = 1 at DB level
-- (Partial unique index: one per user per challenge when completion is limited)
CREATE UNIQUE INDEX IF NOT EXISTS uq_challenge_completion_once
    ON challenge_completions (user_id, challenge_id)
    WHERE (SELECT max_completions_per_user FROM challenges c WHERE c.id = challenge_id) = 1;

-- Reward redemptions: prevent double-spending HP on the same reward in same session
-- (App-level idempotency via reference_id, but add partial index for 'completed' state)
CREATE INDEX IF NOT EXISTS idx_reward_redemptions_user_reward
    ON reward_redemptions (user_id, reward_id, status);


-- ══════════════════════════════════════════════════════════════════════════════
-- 8. PERFORMANCE INDEXES — identified gaps from query patterns
-- ══════════════════════════════════════════════════════════════════════════════

-- HP transactions: most common query (balance = SUM WHERE user_id AND status='active')
CREATE INDEX IF NOT EXISTS idx_hp_tx_user_status
    ON hp_transactions (user_id, status);

-- HP transactions: 120-day rolling window calc
CREATE INDEX IF NOT EXISTS idx_hp_tx_user_created
    ON hp_transactions (user_id, created_at DESC)
    WHERE amount > 0;

-- Orders: kitchen queue (status IN ready states)
CREATE INDEX IF NOT EXISTS idx_orders_status_created
    ON orders (status, created_at DESC);

-- Orders: per-user history
CREATE INDEX IF NOT EXISTS idx_orders_user_created
    ON orders (user_id, created_at DESC);

-- Referrals: look up referrer's completed count
CREATE INDEX IF NOT EXISTS idx_referrals_referrer_status
    ON referrals (referrer_id, status);

-- Pending HP: per-user pending rows
CREATE INDEX IF NOT EXISTS idx_pending_hp_user_status
    ON pending_hp_transactions (user_id, status);

-- Notifications: per-user unread
CREATE INDEX IF NOT EXISTS idx_notifications_user_read
    ON notifications (user_id, is_read)
    WHERE is_read = false;

-- Webhook events: dedup lookups by idempotency key
CREATE INDEX IF NOT EXISTS idx_webhook_idem
    ON webhook_events (idempotency_key);


-- ══════════════════════════════════════════════════════════════════════════════
-- 9. MENU ADDONS — public SELECT policy fix (OR precedence fix)
-- ══════════════════════════════════════════════════════════════════════════════
DROP POLICY IF EXISTS menu_addons_public_read ON menu_addons;

CREATE POLICY menu_addons_public_read ON menu_addons
    FOR SELECT USING (
        (is_available = true AND is_archived = false) OR is_admin()
    );
