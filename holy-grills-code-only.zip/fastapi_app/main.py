"""
Holy Grills — FastAPI application factory.

Parallel implementation of the Flask app. Shares all services and DB layer.
Swagger UI available at /api/docs  (OpenAPI JSON at /api/openapi.json).
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from fastapi_app.routers import (
    auth, menu, orders, hp, wallet, rewards, referrals,
    notifications, leaderboard, marketplace, storefront,
    admin, kitchen, riders, webhooks, analytics, challenges, events,
)


def create_fastapi_app() -> FastAPI:
    app = FastAPI(
        title="Holy Grills API",
        description=(
            "Backend API for the Holy Grills Student Participation Engine — "
            "HP ecosystem, food ordering, marketplace, events, wallet, and admin operations.\n\n"
            "**Auth:** All protected endpoints require `Authorization: Bearer <supabase_jwt>`.\n\n"
            "This is the FastAPI parallel of the Flask backend. "
            "Both implementations share the same Supabase database and service layer."
        ),
        version="2.0.0",
        contact={"name": "Holy Grills Engineering", "email": "dev@holygrills.ng"},
        docs_url="/api/docs",
        redoc_url="/api/redoc",
        openapi_url="/api/openapi.json",
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    prefix = "/api"
    app.include_router(auth.router,          prefix=f"{prefix}/auth",          tags=["Auth"])
    app.include_router(menu.router,          prefix=f"{prefix}/menu",          tags=["Menu"])
    app.include_router(orders.router,        prefix=f"{prefix}/orders",        tags=["Orders"])
    app.include_router(hp.router,            prefix=f"{prefix}/hp",            tags=["HP"])
    app.include_router(wallet.router,        prefix=f"{prefix}/wallet",        tags=["Wallet"])
    app.include_router(rewards.router,       prefix=f"{prefix}/rewards",       tags=["Rewards"])
    app.include_router(referrals.router,     prefix=f"{prefix}/referrals",     tags=["Referrals"])
    app.include_router(notifications.router, prefix=f"{prefix}/notifications", tags=["Notifications"])
    app.include_router(leaderboard.router,   prefix=f"{prefix}/leaderboard",   tags=["Leaderboard"])
    app.include_router(marketplace.router,   prefix=f"{prefix}/marketplace",   tags=["Marketplace"])
    app.include_router(storefront.router,    prefix=f"{prefix}/storefront",    tags=["Storefront"])
    app.include_router(admin.router,         prefix=f"{prefix}/admin",         tags=["Admin"])
    app.include_router(kitchen.router,       prefix=f"{prefix}/kitchen",       tags=["Kitchen"])
    app.include_router(riders.router,        prefix=f"{prefix}/riders",        tags=["Riders"])
    app.include_router(webhooks.router,      prefix=f"{prefix}/webhooks",      tags=["Webhooks"])
    app.include_router(analytics.router,     prefix=f"{prefix}/analytics",     tags=["Analytics"])
    app.include_router(challenges.router,    prefix=f"{prefix}/challenges",    tags=["Challenges"])
    app.include_router(events.router,        prefix=f"{prefix}/events",        tags=["Events"])

    return app


app = create_fastapi_app()
