"""Menu routes — categories, items, add-ons, variation groups, daily limits, kitchen capacity."""

from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, Query
from datetime import datetime, timezone

from fastapi_app.deps import UserContext, get_current_user, require_role
from fastapi_app.schemas import (
    CategoryCreate, CategoryUpdate,
    MenuItemCreate, MenuItemUpdate,
    AddonCreate, AddonUpdate,
    VariationGroupCreate, VariationGroupUpdate,
    VariationOptionCreate, VariationOptionUpdate,
    KitchenCapacityUpdate,
)
from fastapi_app.deps import get_db

router = APIRouter()


def _today_start_iso():
    return datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0).isoformat()


def _kitchen_stats(db):
    row = db.table("kitchen_settings").select("value").eq("key", "daily_order_capacity").single().execute()
    raw = row.get("value") if row else ""
    capacity = int(raw) if raw and str(raw).isdigit() else None
    today_orders = db.table("orders").select("id").gte("created_at", _today_start_iso()).execute() or []
    count = len(today_orders)
    at_capacity = capacity is not None and count >= capacity
    return capacity, count, at_capacity


def _daily_item_counts(db):
    today_orders = db.table("orders").select("id").gte("created_at", _today_start_iso()).execute() or []
    order_ids = {o["id"] for o in today_orders}
    counts = {}
    if order_ids:
        rows = db.table("order_items").select("menu_item_id,quantity,order_id").execute() or []
        for row in rows:
            if row.get("order_id") in order_ids and row.get("menu_item_id"):
                mid = row["menu_item_id"]
                counts[mid] = counts.get(mid, 0) + int(row.get("quantity", 1))
    return counts


def _enrich_item(item, counts, at_capacity):
    daily_limit = item.get("daily_limit")
    count = counts.get(item.get("id"), 0)
    if at_capacity:
        item["is_sold_out"] = True
        item["daily_remaining"] = 0
    elif daily_limit is not None:
        remaining = max(0, int(daily_limit) - count)
        item["daily_remaining"] = remaining
        item["is_sold_out"] = remaining == 0
    else:
        item["is_sold_out"] = False
        item["daily_remaining"] = None
    return item


# ─── Categories ──────────────────────────────────────────────────────────────

@router.get("/categories", summary="List all active menu categories.")
def list_categories():
    db = get_db()
    cats = db.table("menu_categories").select("*").eq("is_active", True).order("sort_order").execute()
    return cats or []


@router.post("/categories", status_code=201, summary="[Admin] Create a menu category.")
def create_category(body: CategoryCreate, _: UserContext = Depends(require_role("admin"))):
    db = get_db()
    try:
        row = db.table("menu_categories").insert(body.model_dump()).execute()
        return row
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@router.patch("/categories/{category_id}", summary="[Admin] Update a category.")
def update_category(category_id: str, body: CategoryUpdate, _: UserContext = Depends(require_role("admin"))):
    db   = get_db()
    data = {k: v for k, v in body.model_dump().items() if v is not None}
    db.table("menu_categories").update(data).eq("id", category_id).execute()
    return db.table("menu_categories").select("*").eq("id", category_id).single().execute()


# ─── Items ───────────────────────────────────────────────────────────────────

@router.get("/items", summary="List all active menu items with sold-out/daily status.")
def list_items(category_id: Optional[str] = Query(None)):
    db = get_db()
    capacity, orders_today, at_capacity = _kitchen_stats(db)
    counts = _daily_item_counts(db)
    q = db.table("menu_items").select("*").eq("is_archived", False)
    if category_id:
        q = q.eq("category_id", category_id)
    items = q.order("name").execute() or []
    for item in items:
        _enrich_item(item, counts, at_capacity)
    return {
        "items": items,
        "kitchen": {
            "daily_order_capacity": capacity,
            "orders_today": orders_today,
            "is_at_capacity": at_capacity,
        },
    }


@router.get("/items/{item_id}", summary="Get a single menu item with variation groups.")
def get_item(item_id: str):
    db = get_db()
    item = db.table("menu_items").select("*").eq("id", item_id).eq("is_archived", False).single().execute()
    if not item:
        raise HTTPException(status_code=404, detail="Menu item not found")
    capacity, _, at_capacity = _kitchen_stats(db)
    counts = _daily_item_counts(db)
    _enrich_item(item, counts, at_capacity)
    groups = db.table("menu_item_variation_groups").select("*").eq("menu_item_id", item_id).execute() or []
    for group in groups:
        group["options"] = db.table("menu_item_variation_options").select("*").eq("group_id", group["id"]).execute() or []
    item["variation_groups"] = groups
    return item


@router.post("/items", status_code=201, summary="[Admin] Create a menu item.")
def create_item(body: MenuItemCreate, user: UserContext = Depends(require_role("admin"))):
    db   = get_db()
    data = body.model_dump()
    data["last_edited_by"] = user.user_id
    row  = db.table("menu_items").insert(data).execute()
    return row


@router.patch("/items/{item_id}", summary="[Admin] Update a menu item.")
def update_item(item_id: str, body: MenuItemUpdate, user: UserContext = Depends(require_role("admin"))):
    db   = get_db()
    data = {k: v for k, v in body.model_dump().items() if v is not None}
    data["last_edited_by"] = user.user_id
    db.table("menu_items").update(data).eq("id", item_id).execute()
    return db.table("menu_items").select("*").eq("id", item_id).single().execute()


@router.post("/items/{item_id}/archive", summary="[Admin] Archive (soft-delete) a menu item.")
def archive_item(item_id: str, user: UserContext = Depends(require_role("admin"))):
    from datetime import datetime, timezone as tz
    db = get_db()
    db.table("menu_items").update({
        "is_archived": True,
        "archived_at": datetime.now(tz.utc).isoformat(),
        "archived_by": user.user_id,
    }).eq("id", item_id).execute()
    return {"message": "Item archived"}


# ─── Add-ons ─────────────────────────────────────────────────────────────────

@router.get("/addons", summary="List all active add-ons.")
def list_addons():
    db = get_db()
    return db.table("menu_addons").select("*").eq("is_archived", False).execute() or []


@router.post("/addons", status_code=201, summary="[Admin] Create an add-on.")
def create_addon(body: AddonCreate, _: UserContext = Depends(require_role("admin"))):
    db  = get_db()
    row = db.table("menu_addons").insert(body.model_dump()).execute()
    return row


@router.patch("/addons/{addon_id}", summary="[Admin] Update an add-on.")
def update_addon(addon_id: str, body: AddonUpdate, _: UserContext = Depends(require_role("admin"))):
    db   = get_db()
    data = {k: v for k, v in body.model_dump().items() if v is not None}
    db.table("menu_addons").update(data).eq("id", addon_id).execute()
    return db.table("menu_addons").select("*").eq("id", addon_id).single().execute()


@router.post("/addons/{addon_id}/archive", summary="[Admin] Archive an add-on.")
def archive_addon(addon_id: str, _: UserContext = Depends(require_role("admin"))):
    from datetime import datetime, timezone as tz
    db = get_db()
    db.table("menu_addons").update({"is_archived": True, "archived_at": datetime.now(tz.utc).isoformat()}).eq("id", addon_id).execute()
    return {"message": "Add-on archived"}


# ─── Variation Groups ────────────────────────────────────────────────────────

@router.post("/items/{item_id}/variation-groups", status_code=201,
    summary="[Admin] Create a variation group for an item (e.g. 'Choose your side').")
def create_variation_group(item_id: str, body: VariationGroupCreate, _: UserContext = Depends(require_role("admin"))):
    db   = get_db()
    data = body.model_dump()
    data["menu_item_id"] = item_id
    return db.table("menu_item_variation_groups").insert(data).execute()


@router.patch("/variation-groups/{group_id}", summary="[Admin] Update a variation group.")
def update_variation_group(group_id: str, body: VariationGroupUpdate, _: UserContext = Depends(require_role("admin"))):
    db   = get_db()
    data = {k: v for k, v in body.model_dump().items() if v is not None}
    db.table("menu_item_variation_groups").update(data).eq("id", group_id).execute()
    return db.table("menu_item_variation_groups").select("*").eq("id", group_id).single().execute()


@router.post("/variation-groups/{group_id}/options", status_code=201,
    summary="[Admin] Add an option to a variation group.")
def create_variation_option(group_id: str, body: VariationOptionCreate, _: UserContext = Depends(require_role("admin"))):
    db   = get_db()
    data = body.model_dump()
    data["group_id"] = group_id
    return db.table("menu_item_variation_options").insert(data).execute()


@router.patch("/variation-options/{option_id}", summary="[Admin] Update a variation option.")
def update_variation_option(option_id: str, body: VariationOptionUpdate, _: UserContext = Depends(require_role("admin"))):
    db   = get_db()
    data = {k: v for k, v in body.model_dump().items() if v is not None}
    db.table("menu_item_variation_options").update(data).eq("id", option_id).execute()
    return db.table("menu_item_variation_options").select("*").eq("id", option_id).single().execute()


# ─── Kitchen capacity ────────────────────────────────────────────────────────

@router.get("/kitchen-capacity", summary="Get kitchen daily order capacity and today's count.")
def get_kitchen_capacity():
    db = get_db()
    capacity, orders_today, is_at_capacity = _kitchen_stats(db)
    return {
        "daily_order_capacity": capacity,
        "orders_today": orders_today,
        "is_at_capacity": is_at_capacity,
    }


@router.patch("/kitchen-capacity", summary="[Admin] Set or remove the daily order capacity cap.")
def update_kitchen_capacity(body: KitchenCapacityUpdate, _: UserContext = Depends(require_role("admin"))):
    db  = get_db()
    val = str(body.daily_order_capacity) if body.daily_order_capacity is not None else ""
    existing = db.table("kitchen_settings").select("id").eq("key", "daily_order_capacity").execute()
    if existing:
        db.table("kitchen_settings").update({"value": val}).eq("key", "daily_order_capacity").execute()
    else:
        db.table("kitchen_settings").insert({"key": "daily_order_capacity", "value": val}).execute()
    capacity, orders_today, is_at_capacity = _kitchen_stats(db)
    return {"daily_order_capacity": capacity, "orders_today": orders_today, "is_at_capacity": is_at_capacity}
