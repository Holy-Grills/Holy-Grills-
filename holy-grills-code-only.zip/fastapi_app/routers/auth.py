"""Auth routes — register, login, refresh, profile, logout."""

from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, status

from fastapi_app.deps import UserContext, get_current_user
from fastapi_app.schemas import (
    RegisterRequest, LoginRequest, RefreshRequest, UpdateProfileRequest,
)
from app.services import auth_service
from fastapi_app.deps import get_db

router = APIRouter()


@router.post("/register", status_code=201,
    summary="Register a new student account",
    description="Rate limited: 10 requests/hour. Returns Supabase session tokens on success.")
def register(body: RegisterRequest):
    try:
        result = auth_service.register(
            email=body.email,
            password=body.password,
            full_name=body.full_name,
            phone=body.phone,
            date_of_birth=body.date_of_birth,
            referred_by_code=body.referred_by_code,
        )
        return result
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Registration failed: {exc}")


@router.post("/login",
    summary="Login with email and password",
    description="Returns access_token, refresh_token, and expires_in (seconds).")
def login(body: LoginRequest):
    try:
        result = auth_service.login(email=body.email, password=body.password)
        return result
    except ValueError as exc:
        raise HTTPException(status_code=401, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Login failed: {exc}")


@router.post("/refresh",
    summary="Refresh access token using refresh_token.")
def refresh(body: RefreshRequest):
    try:
        result = auth_service.refresh_token(body.refresh_token)
        return result
    except ValueError as exc:
        raise HTTPException(status_code=401, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Token refresh failed: {exc}")


@router.post("/logout",
    summary="Invalidate the current session.")
def logout(user: UserContext = Depends(get_current_user)):
    try:
        auth_service.logout(user.token)
        return {"message": "Logged out successfully"}
    except Exception:
        return {"message": "Logged out"}


@router.get("/profile",
    summary="Get current user's profile.")
def get_profile(user: UserContext = Depends(get_current_user)):
    db = get_db()
    profile = (
        db.table("profiles")
        .select("id,email,full_name,phone,role,date_of_birth,referral_code,referred_by,push_enabled,email_notifications,created_at,is_active")
        .eq("id", user.user_id)
        .single()
        .execute()
    )
    return profile


@router.patch("/profile",
    summary="Update profile fields (full_name, phone, date_of_birth, notification prefs).")
def update_profile(body: UpdateProfileRequest, user: UserContext = Depends(get_current_user)):
    db   = get_db()
    data = {k: v for k, v in body.model_dump().items() if v is not None}
    if not data:
        raise HTTPException(status_code=400, detail="No fields provided to update")
    db.table("profiles").update(data).eq("id", user.user_id).execute()
    profile = (
        db.table("profiles")
        .select("id,email,full_name,phone,role,date_of_birth,referral_code,push_enabled,email_notifications")
        .eq("id", user.user_id)
        .single()
        .execute()
    )
    return profile


@router.delete("/profile",
    status_code=200,
    summary="Deactivate account (soft delete).")
def deactivate_account(user: UserContext = Depends(get_current_user)):
    from datetime import datetime, timezone
    db = get_db()
    db.table("profiles").update({
        "is_active": False,
        "deactivated_at": datetime.now(timezone.utc).isoformat(),
        "deactivated_by": user.user_id,
    }).eq("id", user.user_id).execute()
    return {"message": "Account deactivated"}
