from fastapi_app.routers import (
    auth, menu, orders, hp, wallet, rewards, referrals,
    notifications, leaderboard, marketplace, storefront,
    admin, kitchen, riders, webhooks, analytics, challenges, events,
)

__all__ = [
    "auth", "menu", "orders", "hp", "wallet", "rewards", "referrals",
    "notifications", "leaderboard", "marketplace", "storefront",
    "admin", "kitchen", "riders", "webhooks", "analytics", "challenges", "events",
]
