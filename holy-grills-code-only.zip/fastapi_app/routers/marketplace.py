"""Marketplace routes — listings, HP purchases, code redemption."""

from typing import Any, Dict, List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel

from fastapi_app.deps import UserContext, get_current_user, require_role
from fastapi_app.schemas import ListingCreate, ListingUpdate
from app.services.hp_service import spend_hp, get_hp_balance, award_active_hp
from app.services.wallet_service import debit_wallet
from fastapi_app.deps import get_db

router = APIRouter()


class PurchaseRequest(BaseModel):
    use_hp_pricing:     bool = False
    payment_method:     str  = "wallet"
    wallet_amount:      float = 0.0
    payment_reference:  str  = ""


class ListingRequestCreate(BaseModel):
    vendor_name:         str
    vendor_email:        str
    vendor_phone:        Optional[str] = None
    service_title:       str
    category:            str
    description:         str
    proposed_price:      float


class UploadCodesRequest(BaseModel):
    codes: List[str]


@router.get("", summary="List active marketplace listings.")
def list_listings(
    category: Optional[str] = Query(None),
    q:        Optional[str] = Query(None),
):
    db      = get_db()
    query   = db.table("marketplace_listings").select("*,tiers(name,slug)").eq("is_active", True).eq("is_out_of_stock", False)
    if category:
        query = query.eq("category", category)
    if q:
        query = query.ilike("title", f"%{q}%")
    return query.order("is_featured", ascending=False).order("sort_order").execute() or []


@router.get("/{listing_id}", summary="Get a single marketplace listing.")
def get_listing(listing_id: str):
    db      = get_db()
    listing = db.table("marketplace_listings").select("*,tiers(name,slug)").eq("id", listing_id).single().execute()
    if not listing:
        raise HTTPException(status_code=404, detail="Listing not found")
    codes = db.table("marketplace_codes").select("id").eq("listing_id", listing_id).eq("status", "available").execute() or []
    listing["codes_remaining"] = len(codes)
    return listing


@router.post("/{listing_id}/purchase", status_code=201,
    summary="Purchase a marketplace listing via HP, wallet, card, or split.")
def purchase(listing_id: str, body: PurchaseRequest, user: UserContext = Depends(get_current_user)):
    db      = get_db()
    listing = db.table("marketplace_listings").select("*").eq("id", listing_id).eq("is_active", True).single().execute()
    if not listing:
        raise HTTPException(status_code=404, detail="Listing not available")
    if listing.get("is_out_of_stock"):
        raise HTTPException(status_code=400, detail="Listing is out of stock")

    if body.use_hp_pricing:
        hp_to_spend   = listing.get("hp_price_points", 0)
        naira_to_pay  = float(listing.get("hp_price_naira", 0))
    else:
        hp_to_spend   = 0
        naira_to_pay  = float(listing.get("standard_price", 0))

    if hp_to_spend > 0:
        bal = get_hp_balance(user.user_id)
        if bal["active"] < hp_to_spend:
            raise HTTPException(status_code=400, detail=f"Insufficient HP: need {hp_to_spend}, have {bal['active']}")

    wallet_amount = 0.0
    card_amount   = 0.0
    if body.payment_method == "wallet":
        wallet_amount = naira_to_pay
        debit_wallet(user.user_id, wallet_amount, listing_id, "marketplace", f"Purchase: {listing['title']}")
    elif body.payment_method == "card":
        card_amount = naira_to_pay
    elif body.payment_method == "split":
        wallet_amount = body.wallet_amount
        card_amount   = naira_to_pay - wallet_amount
        if wallet_amount > 0:
            debit_wallet(user.user_id, wallet_amount, listing_id, "marketplace", f"Wallet portion: {listing['title']}")

    purchase_record: Dict[str, Any] = {
        "user_id":            user.user_id,
        "listing_id":         listing_id,
        "standard_price":     listing.get("standard_price"),
        "amount_paid_naira":  naira_to_pay,
        "hp_spent":           hp_to_spend,
        "used_hp_pricing":    body.use_hp_pricing,
        "payment_method":     body.payment_method,
        "wallet_amount":      wallet_amount,
        "card_amount":        card_amount,
        "payment_reference":  body.payment_reference,
        "is_fulfilled":       False,
    }

    if listing.get("listing_type") == "code":
        result = db.rpc("claim_marketplace_code", {"p_listing_id": listing_id, "p_user_id": user.user_id})
        if result and isinstance(result, dict) and result.get("code_id"):
            purchase_record["code_id"]    = result["code_id"]
            purchase_record["is_fulfilled"] = True
        else:
            db.table("marketplace_listings").update({"is_out_of_stock": True}).eq("id", listing_id).execute()
            raise HTTPException(status_code=400, detail="No codes available. Listing is now out of stock.")

    if hp_to_spend > 0:
        spend_hp(user.user_id, hp_to_spend, listing_id, "marketplace_purchase", f"HP discount on: {listing['title']}")

    saved        = db.table("marketplace_purchases").insert(purchase_record).execute()
    purchase_row = saved[0] if isinstance(saved, list) else saved

    award_active_hp(
        user_id=user.user_id, amount=50, txn_type="earn",
        reference_id=purchase_row.get("id"), reference_type="marketplace_purchase",
        notes="HP earned on marketplace purchase",
    )

    code_value = None
    if purchase_record.get("code_id"):
        code_row = db.table("marketplace_codes").select("code").eq("id", purchase_record["code_id"]).single().execute()
        code_value = code_row.get("code") if code_row else None

    return {"purchase": purchase_row, "code": code_value, "hp_earned": 50}


@router.post("/requests", status_code=201, summary="Submit a vendor listing request for admin review.")
def submit_listing_request(body: ListingRequestCreate):
    db   = get_db()
    data = body.model_dump()
    data["status"] = "pending"
    result = db.table("marketplace_listing_requests").insert(data).execute()
    return result[0] if isinstance(result, list) else result


@router.post("/admin/codes/{listing_id}", status_code=201,
    summary="[Admin] Upload access codes for a listing.")
def upload_codes(listing_id: str, body: UploadCodesRequest, user: UserContext = Depends(require_role("admin"))):
    from datetime import datetime, timezone
    db = get_db()
    if not body.codes:
        raise HTTPException(status_code=400, detail="codes list is required")
    records = [{"listing_id": listing_id, "code": c, "status": "available", "uploaded_by": user.user_id} for c in body.codes]
    db.table("marketplace_codes").insert(records).execute()
    db.table("marketplace_listings").update({"is_out_of_stock": False, "updated_at": datetime.now(timezone.utc).isoformat()}).eq("id", listing_id).execute()
    return {"uploaded": len(records)}


@router.post("", status_code=201, summary="[Admin] Create a marketplace listing.")
def create_listing(body: ListingCreate, _: UserContext = Depends(require_role("admin"))):
    db  = get_db()
    row = db.table("marketplace_listings").insert(body.model_dump()).execute()
    return row


@router.patch("/{listing_id}", summary="[Admin] Update a marketplace listing.")
def update_listing(listing_id: str, body: ListingUpdate, _: UserContext = Depends(require_role("admin"))):
    db   = get_db()
    data = {k: v for k, v in body.model_dump().items() if v is not None}
    db.table("marketplace_listings").update(data).eq("id", listing_id).execute()
    return db.table("marketplace_listings").select("*").eq("id", listing_id).single().execute()
