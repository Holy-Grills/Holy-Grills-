"""Webhook routes — Paystack payment callbacks. Idempotency enforced."""

import hashlib, hmac, json, os
from datetime import datetime, timezone
from fastapi import APIRouter, Request, HTTPException
from fastapi.responses import JSONResponse

from fastapi_app.deps import get_db
from app.services.order_service import confirm_order_payment
from app.services.wallet_service import credit_wallet
from app.services.notification_service import send_notification

router = APIRouter()

PAYSTACK_SECRET = os.environ.get("PAYSTACK_WEBHOOK_SECRET", "")


@router.post("/paystack",
    summary="Paystack webhook — charge.success, transfer.success, dedicatedaccount.assign.success.",
    description="Signature-verified. Idempotent via idempotency_key. Never trust client success — all payment confirmation flows through here.")
async def paystack_webhook(request: Request):
    payload_bytes = await request.body()
    signature     = request.headers.get("x-paystack-signature", "")

    if PAYSTACK_SECRET:
        computed = hmac.new(PAYSTACK_SECRET.encode(), payload_bytes, hashlib.sha512).hexdigest()
        if not hmac.compare_digest(computed, signature):
            raise HTTPException(status_code=401, detail="Invalid Paystack signature")

    try:
        payload = json.loads(payload_bytes)
    except json.JSONDecodeError:
        raise HTTPException(status_code=400, detail="Invalid JSON")

    event_type       = payload.get("event")
    data             = payload.get("data", {})
    reference        = data.get("reference") or data.get("transfer_code", "")
    idempotency_key  = f"paystack:{event_type}:{reference}"

    db       = get_db()
    existing = db.table("webhook_events").select("id").eq("idempotency_key", idempotency_key).execute()
    if existing:
        return JSONResponse({"message": "Already processed"})

    webhook_record = {
        "provider":           "paystack",
        "event_type":         event_type,
        "idempotency_key":    idempotency_key,
        "payment_reference":  reference,
        "signature":          signature,
        "signature_verified": bool(PAYSTACK_SECRET),
        "raw_payload":        payload,
        "processing_status":  "processing",
    }
    db.table("webhook_events").insert(webhook_record).execute()

    try:
        if event_type == "charge.success":
            _handle_charge_success(db, data)
        elif event_type == "dedicatedaccount.assign.success":
            _handle_dva_assign(db, data)
        elif event_type == "transfer.success":
            _handle_transfer(db, data)

        db.table("webhook_events").update({
            "processing_status": "success",
            "processed_at":      datetime.now(timezone.utc).isoformat(),
        }).eq("idempotency_key", idempotency_key).execute()
    except Exception as exc:
        db.table("webhook_events").update({
            "processing_status": "failed",
            "error_message":     str(exc),
        }).eq("idempotency_key", idempotency_key).execute()

    return JSONResponse({"message": "OK"})


def _handle_charge_success(db, data: dict):
    reference = data.get("reference", "")
    metadata  = data.get("metadata") or {}
    purpose   = metadata.get("purpose", "order")

    if purpose == "wallet_topup":
        user_id = metadata.get("user_id")
        amount  = float(data.get("amount", 0)) / 100
        if user_id and amount > 0:
            credit_wallet(user_id, amount, None, "topup", f"Card top-up via Paystack ref {reference}", provider_response=data, payment_reference=reference)
    else:
        order = db.table("orders").select("id,user_id,total").eq("payment_reference", reference).single().execute()
        if order:
            confirm_order_payment(order["id"])


def _handle_dva_assign(db, data: dict):
    customer  = data.get("customer", {})
    email     = customer.get("email")
    dva       = data.get("dedicated_account", {})
    if not email:
        return
    profile = db.table("profiles").select("id").eq("email", email).single().execute()
    if not profile:
        return
    db.table("wallets").update({
        "virtual_account_number": dva.get("account_number"),
        "virtual_account_bank":   dva.get("bank", {}).get("name"),
        "virtual_account_name":   dva.get("account_name"),
        "virtual_account_ref":    dva.get("id"),
    }).eq("user_id", profile["id"]).execute()


def _handle_transfer(db, data: dict):
    pass
