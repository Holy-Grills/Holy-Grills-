"""Analytics routes — admin-only reporting."""

from datetime import datetime, timezone, timedelta
from typing import Optional
from fastapi import APIRouter, Depends, Query

from fastapi_app.deps import UserContext, require_role
from fastapi_app.deps import get_db

router = APIRouter()


@router.get("/sales", summary="[Admin] Sales analytics — revenue, order volume, AOV by date range.")
def sales_analytics(
    from_date: Optional[str] = Query(None),
    to_date:   Optional[str] = Query(None),
    _: UserContext = Depends(require_role("admin")),
):
    db        = get_db()
    from_date = from_date or (datetime.now(timezone.utc) - timedelta(days=30)).date().isoformat()
    to_date   = to_date   or datetime.now(timezone.utc).date().isoformat()

    orders = (
        db.table("orders")
        .select("id,total,subtotal,status,payment_method,created_at,wallet_amount,card_amount")
        .gte("created_at", from_date)
        .lte("created_at", to_date + "T23:59:59Z")
        .neq("status", "cancelled")
        .execute()
    ) or []

    delivered     = [o for o in orders if o.get("status") == "delivered"]
    total_revenue = sum(float(o.get("total", 0)) for o in delivered)
    order_count   = len(delivered)
    aov           = total_revenue / order_count if order_count > 0 else 0
    wallet_rev    = sum(float(o.get("wallet_amount", 0)) for o in delivered)
    card_rev      = sum(float(o.get("card_amount", 0)) for o in delivered)

    return {
        "from_date":            from_date,
        "to_date":              to_date,
        "total_revenue":        round(total_revenue, 2),
        "order_count":          order_count,
        "average_order_value":  round(aov, 2),
        "wallet_revenue":       round(wallet_rev, 2),
        "card_revenue":         round(card_rev, 2),
    }


@router.get("/hp", summary="[Admin] HP ecosystem analytics — issued, redeemed, tier distribution.")
def hp_analytics(_: UserContext = Depends(require_role("admin"))):
    db      = get_db()
    hp_txns = db.table("hp_transactions").select("amount,type,status").execute() or []
    earned   = sum(t["amount"] for t in hp_txns if t.get("type") in ("earn","earn_order","earn_first_order","admin_grant") and t.get("amount", 0) > 0 and t.get("status") == "active")
    spent    = abs(sum(t["amount"] for t in hp_txns if t.get("type") == "spend"))
    expired  = abs(sum(t["amount"] for t in hp_txns if t.get("type") == "expire"))
    pending  = sum(t["amount"] for t in hp_txns if t.get("status") == "pending" and t.get("amount", 0) > 0)
    overflow = sum(t["amount"] for t in hp_txns if t.get("status") == "overflow" and t.get("amount", 0) > 0)

    tiers = db.table("user_tiers").select("tier_id,is_current,tiers(name)").eq("is_current", True).execute() or []
    tier_dist: dict = {}
    for t in tiers:
        name = (t.get("tiers") or {}).get("name", "Unknown")
        tier_dist[name] = tier_dist.get(name, 0) + 1

    return {
        "hp_earned_active":  earned,
        "hp_spent":          spent,
        "hp_expired":        expired,
        "hp_pending":        pending,
        "hp_overflow":       overflow,
        "tier_distribution": tier_dist,
    }


@router.get("/referrals", summary="[Admin] Referral analytics — total referrals, completion rate.")
def referral_analytics(_: UserContext = Depends(require_role("admin"))):
    db    = get_db()
    refs  = db.table("referrals").select("status").execute() or []
    total = len(refs)
    done  = len([r for r in refs if r.get("status") == "completed"])
    pend  = len([r for r in refs if r.get("status") == "pending"])
    return {
        "total_referrals":     total,
        "completed":           done,
        "pending":             pend,
        "completion_rate_pct": round(done / total * 100, 1) if total > 0 else 0,
    }


@router.get("/users", summary="[Admin] User growth and activity analytics.")
def user_analytics(_: UserContext = Depends(require_role("admin"))):
    db      = get_db()
    profiles = db.table("profiles").select("role,is_active,created_at").execute() or []
    active   = [p for p in profiles if p.get("is_active")]
    students = [p for p in active if p.get("role") == "student"]
    from datetime import date
    today_str = date.today().isoformat()[:7]
    new_this_month = [p for p in profiles if (p.get("created_at") or "")[:7] == today_str]
    return {
        "total_users":      len(profiles),
        "active_users":     len(active),
        "students":         len(students),
        "new_this_month":   len(new_this_month),
    }
