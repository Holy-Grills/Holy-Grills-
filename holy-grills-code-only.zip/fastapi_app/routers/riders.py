"""Rider dashboard routes — role: rider | admin."""

from typing import Optional
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from fastapi_app.deps import UserContext, require_role
from app.services.order_service import update_order_status
from fastapi_app.deps import get_db

router = APIRouter()


class AttemptRequest(BaseModel):
    notes: Optional[str] = "Delivery attempted — customer unreachable"


@router.get("/my-batch",
    summary="[Rider] Get the active delivery batch assigned to this rider.")
def my_batch(user: UserContext = Depends(require_role("rider", "admin"))):
    db = get_db()
    batches = (
        db.table("delivery_batches")
        .select("id,window_id,zone,status,delivery_windows(label,opens_at,closes_at)")
        .eq("rider_id", user.user_id)
        .in_("status", ["assigned", "in_progress"])
        .order("assigned_at", ascending=False)
        .limit(1)
        .execute()
    )
    if not batches:
        return {"batch": None, "orders": []}

    batch    = batches[0]
    batch_id = batch["id"]
    orders   = (
        db.table("orders")
        .select("id,status,notes,delivery_address,order_items(name_snapshot,quantity),profiles(full_name)")
        .eq("batch_id", batch_id)
        .execute()
    ) or []

    safe_orders = [
        {
            "id":               o["id"],
            "status":           o["status"],
            "notes":            o.get("notes"),
            "customer_name":    (o.get("profiles") or {}).get("full_name"),
            "delivery_address": o.get("delivery_address"),
            "items":            o.get("order_items", []),
        }
        for o in orders
    ]
    return {"batch": batch, "orders": safe_orders}


@router.post("/orders/{order_id}/deliver",
    summary="[Rider] Mark an order as delivered.")
def mark_delivered(order_id: str, user: UserContext = Depends(require_role("rider", "admin"))):
    try:
        result = update_order_status(order_id, "delivered", user.user_id, "Marked delivered by rider")
        return result
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@router.post("/orders/{order_id}/attempt",
    summary="[Rider] Log a failed delivery attempt (customer unreachable).")
def mark_attempted(order_id: str, body: AttemptRequest, user: UserContext = Depends(require_role("rider", "admin"))):
    try:
        result = update_order_status(order_id, "attempted", user.user_id, body.notes)
        return result
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@router.get("/call/{order_id}",
    summary="[Rider] Get a secure tel: call link for the customer. Phone never exposed as plain text.")
def get_customer_call_link(order_id: str, _: UserContext = Depends(require_role("rider", "admin"))):
    db    = get_db()
    order = db.table("orders").select("user_id,guest_phone").eq("id", order_id).single().execute()
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")

    phone = order.get("guest_phone")
    if order.get("user_id"):
        profile = db.table("profiles").select("phone").eq("id", order["user_id"]).single().execute()
        phone   = (profile.get("phone") if profile else None) or phone

    if not phone:
        raise HTTPException(status_code=404, detail="No phone number available")
    return {"call_link": f"tel:{phone}"}


@router.patch("/batch/{batch_id}/status",
    summary="[Rider] Update delivery batch status (in_progress → completed).")
def update_batch_status(batch_id: str, status: str, user: UserContext = Depends(require_role("rider", "admin"))):
    from datetime import datetime, timezone
    db   = get_db()
    data = {"status": status}
    if status == "completed":
        data["completed_at"] = datetime.now(timezone.utc).isoformat()
    db.table("delivery_batches").update(data).eq("id", batch_id).execute()
    return {"message": f"Batch {batch_id} updated to {status}"}
