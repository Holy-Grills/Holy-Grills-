"""Order routes — create, track, manage delivery."""

from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, Query

from fastapi_app.deps import UserContext, get_current_user, get_optional_user, require_role
from fastapi_app.schemas import CreateOrderRequest, ReviewRequest, OrderStatusUpdate
from app.services import order_service
from fastapi_app.deps import get_db

router = APIRouter()


@router.post("", status_code=201,
    summary="Create a new order. Supports authenticated and guest checkout.",
    description="Guest orders require guest_name and guest_phone. Cannot use wallet/HP.")
def create_order(body: CreateOrderRequest, user: Optional[UserContext] = Depends(get_optional_user)):
    user_id  = user.user_id if user else None
    is_guest = user_id is None

    if is_guest:
        if not body.guest_name or not body.guest_phone:
            raise HTTPException(status_code=400, detail="guest_name and guest_phone required for guest checkout")
        if body.payment_method == "wallet":
            raise HTTPException(status_code=400, detail="Wallet payment requires a logged-in account")
        if (body.hp_points_to_redeem or 0) > 0:
            raise HTTPException(status_code=400, detail="HP redemption requires a logged-in account")

    data = body.model_dump()
    data["delivery_address"] = body.delivery_address.model_dump()
    data["items"] = [i.model_dump() for i in body.items]
    if body.addons:
        data["addons"] = [a.model_dump() for a in body.addons]

    try:
        order = order_service.create_order(user_id, data)
        return order
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Order creation failed: {exc}")


@router.get("", summary="List orders for the authenticated user (most recent first).")
def list_orders(
    limit:  int = Query(20, ge=1, le=100),
    offset: int = Query(0, ge=0),
    status: Optional[str] = Query(None),
    user:   UserContext = Depends(get_current_user),
):
    db = get_db()
    q  = db.table("orders").select("*").eq("user_id", user.user_id)
    if status:
        q = q.eq("status", status)
    orders = q.order("created_at", ascending=False).limit(limit).offset(offset).execute()
    return orders or []


@router.get("/admin/all", summary="[Admin/Kitchen] List all orders with optional status filter.")
def admin_list_orders(
    limit:  int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    status: Optional[str] = Query(None),
    user:   UserContext = Depends(require_role("admin", "kitchen")),
):
    db = get_db()
    q  = db.table("orders").select("*,profiles(full_name,phone)")
    if status:
        q = q.eq("status", status)
    orders = q.order("created_at", ascending=False).limit(limit).offset(offset).execute()
    return orders or []


@router.get("/{order_id}", summary="Get a single order (owner or admin).")
def get_order(order_id: str, user: UserContext = Depends(get_current_user)):
    db    = get_db()
    order = db.table("orders").select("*").eq("id", order_id).single().execute()
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    if order.get("user_id") != user.user_id and user.role not in ("admin", "kitchen", "rider"):
        raise HTTPException(status_code=403, detail="Not authorised to view this order")
    items = db.table("order_items").select("*").eq("order_id", order_id).execute() or []
    order["items"] = items
    return order


@router.patch("/{order_id}/status", summary="[Admin/Kitchen/Rider] Update order status.")
def update_order_status(order_id: str, body: OrderStatusUpdate, user: UserContext = Depends(require_role("admin", "kitchen", "rider"))):
    db    = get_db()
    order = db.table("orders").select("id,status,user_id").eq("id", order_id).single().execute()
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")

    valid_transitions = {
        "created":           ["payment_pending", "confirmed", "cancelled"],
        "payment_pending":   ["confirmed", "cancelled"],
        "confirmed":         ["preparing", "cancelled"],
        "preparing":         ["out_for_delivery"],
        "out_for_delivery":  ["delivered"],
        "delivered":         [],
        "cancelled":         [],
    }
    current = order.get("status", "")
    if body.status not in valid_transitions.get(current, []):
        raise HTTPException(status_code=400, detail=f"Cannot transition from '{current}' to '{body.status}'")

    db.table("orders").update({"status": body.status}).eq("id", order_id).execute()
    db.table("order_status_log").insert({
        "order_id":   order_id,
        "from_status": current,
        "to_status":   body.status,
        "changed_by":  user.user_id,
        "notes":       body.notes,
    }).execute()

    if body.status == "delivered" and order.get("user_id"):
        try:
            from app.services.hp_service import earn_pending_hp
            order_service.complete_order_hp(order_id, order["user_id"])
        except Exception:
            pass

    return {"message": "Status updated", "status": body.status}


@router.post("/{order_id}/review", status_code=201, summary="Submit a review for a delivered order.")
def submit_review(order_id: str, body: ReviewRequest, user: UserContext = Depends(get_current_user)):
    db    = get_db()
    order = db.table("orders").select("id,status,user_id,review_submitted").eq("id", order_id).single().execute()
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    if order.get("user_id") != user.user_id:
        raise HTTPException(status_code=403, detail="Not your order")
    if order.get("status") != "delivered":
        raise HTTPException(status_code=400, detail="Order must be delivered before review")
    if order.get("review_submitted"):
        raise HTTPException(status_code=400, detail="Order already reviewed")

    try:
        result = order_service.submit_review(order_id, user.user_id, body.rating, body.comment)
        return result
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


@router.get("/guest/{claim_token}", summary="Retrieve a guest order using its claim token.")
def get_guest_order(claim_token: str):
    db    = get_db()
    order = db.table("orders").select("*").eq("claim_token", claim_token).single().execute()
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    items = db.table("order_items").select("*").eq("order_id", order["id"]).execute() or []
    order["items"] = items
    return order
