"""Referral routes — view, complete, milestones."""

from fastapi import APIRouter, Depends, HTTPException

from fastapi_app.deps import UserContext, get_current_user
from fastapi_app.schemas import CompleteReferralRequest
from fastapi_app.deps import get_db
from app.services.hp_service import earn_pending_hp

router = APIRouter()

_MILESTONE_AWARDS = [
    {"at": 5,  "hp": 150, "badge": "super_referrer_5"},
    {"at": 10, "hp": 400, "badge": "super_referrer_10"},
    {"at": 20, "hp": 750, "badge": "super_referrer_20"},
]


@router.get("", summary="Get current user's referral code, link, and completed referral count.")
def my_referrals(user: UserContext = Depends(get_current_user)):
    db      = get_db()
    profile = db.table("profiles").select("referral_code").eq("id", user.user_id).single().execute()
    code    = profile.get("referral_code", "") if profile else ""
    refs    = db.table("referrals").select("*").eq("referrer_id", user.user_id).execute() or []
    completed = [r for r in refs if r.get("status") == "completed"]
    return {
        "referral_code":       code,
        "referral_link":       f"https://holygrill.app?ref={code}",
        "total_referrals":     len(refs),
        "completed_referrals": len(completed),
        "referrals":           refs,
    }


@router.post("/complete", status_code=201,
    summary="Mark a referral as complete and award pending HP (75 HP) to the referrer. No monthly cap.")
def complete_referral(body: CompleteReferralRequest, user: UserContext = Depends(get_current_user)):
    db = get_db()

    existing = (
        db.table("referrals")
        .select("id,status")
        .eq("referrer_id", user.user_id)
        .eq("referred_user_id", body.referred_user_id)
        .execute()
    )
    if not existing:
        raise HTTPException(status_code=404, detail="Referral not found")
    ref = existing[0]
    if ref.get("status") == "completed":
        raise HTTPException(status_code=400, detail="Referral already completed")

    db.table("referrals").update({"status": "completed"}).eq("id", ref["id"]).execute()

    earn_pending_hp(
        user_id=user.user_id,
        amount=75,
        source_type="referral",
        reference_id=ref["id"],
        notes=f"Referral completed: {body.referred_user_id}",
    )

    total_completed = len([r for r in (db.table("referrals").select("id").eq("referrer_id", user.user_id).eq("status", "completed").execute() or []) ])
    for milestone in _MILESTONE_AWARDS:
        if total_completed == milestone["at"]:
            earn_pending_hp(
                user_id=user.user_id,
                amount=milestone["hp"],
                source_type="referral",
                reference_id=ref["id"],
                notes=f"Referral milestone: {milestone['at']} referrals — {milestone['hp']} HP",
            )
            break

    return {"message": "Referral completed", "hp_awarded": 75, "total_completed": total_completed}


@router.get("/milestones", summary="Get the referral milestone thresholds and rewards.")
def milestones():
    return {"milestones": _MILESTONE_AWARDS}
