"""Admin panel routes — users, orders, delivery windows, promo codes, batches, audit log."""

from typing import Optional
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel

from fastapi_app.deps import UserContext, require_role
from fastapi_app.schemas import PromocodeCreate, DeliveryWindowCreate, BatchCreate
from app.services.hp_service import get_hp_balance, get_user_tier
from app.services.notification_service import send_notification
from fastapi_app.deps import get_db

router = APIRouter()


# ── Users ─────────────────────────────────────────────────────────────────────

@router.get("/users", summary="[Admin] List all users with HP and tier info.")
def list_users(
    q:      Optional[str] = Query(None),
    role:   Optional[str] = Query(None),
    limit:  int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    _: UserContext = Depends(require_role("admin")),
):
    db    = get_db()
    query = db.table("profiles").select("id,full_name,phone,role,is_active,created_at,referral_code,monthly_hp_earned,hp_earned_120day")
    if role:
        query = query.eq("role", role)
    if q:
        query = query.ilike("full_name", f"%{q}%")
    return query.order("created_at", ascending=False).limit(limit).offset(offset).execute() or []


@router.get("/users/{user_id}", summary="[Admin] Full user profile with HP, tier, wallet, recent orders.")
def get_user(user_id: str, _: UserContext = Depends(require_role("admin"))):
    db      = get_db()
    profile = db.table("profiles").select("*").eq("id", user_id).single().execute()
    if not profile:
        raise HTTPException(status_code=404, detail="User not found")
    balance = get_hp_balance(user_id)
    tier    = get_user_tier(user_id)
    wallet  = db.table("wallets").select("balance").eq("user_id", user_id).single().execute()
    orders  = db.table("orders").select("id,status,total,created_at").eq("user_id", user_id).order("created_at", ascending=False).limit(10).execute() or []
    return {"profile": profile, "hp_balance": balance, "tier": tier, "wallet_balance": float(wallet.get("balance", 0)) if wallet else 0, "recent_orders": orders}


@router.post("/users/{user_id}/deactivate", summary="[Admin] Deactivate a user account.")
def deactivate_user(user_id: str, user: UserContext = Depends(require_role("admin"))):
    db = get_db()
    db.table("profiles").update({"is_active": False, "deactivated_at": datetime.now(timezone.utc).isoformat(), "deactivated_by": user.user_id}).eq("id", user_id).execute()
    db.table("admin_audit_log").insert({"admin_id": user.user_id, "action": "deactivate_user", "target_id": user_id, "target_type": "profile"}).execute()
    return {"message": f"User {user_id} deactivated"}


@router.post("/users/{user_id}/reactivate", summary="[Admin] Reactivate a previously deactivated user.")
def reactivate_user(user_id: str, user: UserContext = Depends(require_role("admin"))):
    db = get_db()
    db.table("profiles").update({"is_active": True, "deactivated_at": None}).eq("id", user_id).execute()
    db.table("admin_audit_log").insert({"admin_id": user.user_id, "action": "reactivate_user", "target_id": user_id, "target_type": "profile"}).execute()
    return {"message": f"User {user_id} reactivated"}


@router.patch("/users/{user_id}/role", summary="[Admin] Change a user's role.")
def change_user_role(user_id: str, role: str, user: UserContext = Depends(require_role("admin"))):
    if role not in {"student", "admin", "kitchen", "rider"}:
        raise HTTPException(status_code=400, detail="Invalid role")
    db = get_db()
    db.table("profiles").update({"role": role}).eq("id", user_id).execute()
    db.table("admin_audit_log").insert({"admin_id": user.user_id, "action": "change_role", "target_id": user_id, "target_type": "profile", "details": {"new_role": role}}).execute()
    return {"message": f"User role updated to {role}"}


# ── Delivery Windows ──────────────────────────────────────────────────────────

@router.get("/delivery-windows", summary="[Admin] List all delivery windows.")
def list_windows(_: UserContext = Depends(require_role("admin", "kitchen"))):
    db = get_db()
    return db.table("delivery_windows").select("*").order("opens_at", ascending=False).execute() or []


@router.post("/delivery-windows", status_code=201, summary="[Admin] Create a new delivery window.")
def create_window(body: DeliveryWindowCreate, user: UserContext = Depends(require_role("admin"))):
    db  = get_db()
    row = db.table("delivery_windows").insert({"label": body.label, "opens_at": body.opens_at, "closes_at": body.closes_at, "status": "open", "created_by": user.user_id}).execute()
    return row


@router.post("/delivery-windows/{window_id}/close", summary="[Admin] Close a delivery window.")
def close_window(window_id: str, user: UserContext = Depends(require_role("admin"))):
    db = get_db()
    db.table("delivery_windows").update({"status": "closed", "modified_by": user.user_id}).eq("id", window_id).execute()
    return {"message": "Window closed"}


# ── Delivery Batches ──────────────────────────────────────────────────────────

@router.post("/batches", status_code=201, summary="[Admin] Assign orders to a rider batch.")
def create_batch(body: BatchCreate, user: UserContext = Depends(require_role("admin"))):
    db  = get_db()
    row = db.table("delivery_batches").insert({"window_id": body.window_id, "rider_id": body.rider_id, "zone": body.zone, "status": "assigned", "assigned_at": datetime.now(timezone.utc).isoformat()}).execute()
    return row


@router.get("/batches", summary="[Admin] List all delivery batches.")
def list_batches(
    window_id: Optional[str] = Query(None),
    _: UserContext = Depends(require_role("admin")),
):
    db = get_db()
    q  = db.table("delivery_batches").select("*,profiles(full_name),delivery_windows(label)")
    if window_id:
        q = q.eq("window_id", window_id)
    return q.order("assigned_at", ascending=False).execute() or []


# ── Promo Codes ───────────────────────────────────────────────────────────────

@router.get("/promo-codes", summary="[Admin] List all promo codes.")
def list_promo_codes(_: UserContext = Depends(require_role("admin"))):
    db = get_db()
    return db.table("promo_codes").select("*").order("created_at", ascending=False).execute() or []


@router.post("/promo-codes", status_code=201, summary="[Admin] Create a promo code.")
def create_promo_code(body: PromocodeCreate, user: UserContext = Depends(require_role("admin"))):
    db   = get_db()
    data = body.model_dump()
    data["created_by"] = user.user_id
    data["code"]       = data["code"].upper()
    row  = db.table("promo_codes").insert(data).execute()
    return row


@router.delete("/promo-codes/{code_id}", summary="[Admin] Deactivate a promo code.")
def delete_promo_code(code_id: str, _: UserContext = Depends(require_role("admin"))):
    db = get_db()
    db.table("promo_codes").update({"is_active": False}).eq("id", code_id).execute()
    return {"message": "Promo code deactivated"}


# ── Audit Log ─────────────────────────────────────────────────────────────────

@router.get("/audit-log", summary="[Admin] View admin action audit log.")
def audit_log(
    limit:  int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    _: UserContext = Depends(require_role("admin")),
):
    db = get_db()
    return db.table("admin_audit_log").select("*,profiles(full_name)").order("created_at", ascending=False).limit(limit).offset(offset).execute() or []


# ── Dashboard Stats ───────────────────────────────────────────────────────────

@router.get("/dashboard", summary="[Admin] Quick stats: active users, today's orders, HP issued.")
def dashboard(_: UserContext = Depends(require_role("admin"))):
    from datetime import date
    db         = get_db()
    today_str  = date.today().isoformat()
    users      = db.table("profiles").select("id").eq("is_active", True).execute() or []
    orders     = db.table("orders").select("id,total").gte("created_at", today_str).execute() or []
    delivered  = db.table("orders").select("id").eq("status", "delivered").gte("created_at", today_str).execute() or []
    hp_today   = db.table("hp_transactions").select("amount").gte("created_at", today_str).execute() or []
    total_hp   = sum(t.get("amount", 0) for t in hp_today if t.get("amount", 0) > 0)
    total_rev  = sum(float(o.get("total", 0)) for o in orders)
    return {
        "active_users":     len(users),
        "orders_today":     len(orders),
        "delivered_today":  len(delivered),
        "revenue_today":    round(total_rev, 2),
        "hp_issued_today":  total_hp,
    }
