"""Notification routes — inbox, mark read, admin blasts."""

from fastapi import APIRouter, Depends, HTTPException, Query

from fastapi_app.deps import UserContext, get_current_user, require_role
from fastapi_app.schemas import NotificationBlastRequest
from fastapi_app.deps import get_db

router = APIRouter()


@router.get("", summary="Get the authenticated user's notification inbox.")
def list_notifications(
    limit:       int  = Query(50, ge=1, le=200),
    offset:      int  = Query(0, ge=0),
    unread_only: bool = Query(False),
    user:        UserContext = Depends(get_current_user),
):
    db = get_db()
    q  = db.table("notifications").select("*").eq("user_id", user.user_id)
    if unread_only:
        q = q.eq("is_read", False)
    notifs = q.order("created_at", ascending=False).limit(limit).offset(offset).execute()
    unread = len([n for n in (db.table("notifications").select("id").eq("user_id", user.user_id).eq("is_read", False).execute() or []) ])
    return {"notifications": notifs or [], "unread_count": unread}


@router.post("/{notification_id}/read", summary="Mark a single notification as read.")
def mark_read(notification_id: str, user: UserContext = Depends(get_current_user)):
    db    = get_db()
    notif = db.table("notifications").select("id,user_id").eq("id", notification_id).single().execute()
    if not notif:
        raise HTTPException(status_code=404, detail="Notification not found")
    if notif.get("user_id") != user.user_id:
        raise HTTPException(status_code=403, detail="Not your notification")
    db.table("notifications").update({"is_read": True}).eq("id", notification_id).execute()
    return {"message": "Marked as read"}


@router.post("/read-all", summary="Mark all notifications as read.")
def mark_all_read(user: UserContext = Depends(get_current_user)):
    db = get_db()
    db.table("notifications").update({"is_read": True}).eq("user_id", user.user_id).eq("is_read", False).execute()
    return {"message": "All notifications marked as read"}


@router.post("/blast", status_code=201, summary="[Admin] Send a notification blast to all users or a specific role.")
def send_blast(body: NotificationBlastRequest, _: UserContext = Depends(require_role("admin"))):
    db = get_db()
    q  = db.table("profiles").select("id")
    if body.role:
        q = q.eq("role", body.role)
    users = q.eq("is_active", True).execute() or []

    records = [
        {
            "user_id": u["id"],
            "title":   body.title,
            "message": body.message,
            "type":    body.type or "system",
            "is_read": False,
        }
        for u in users
    ]
    if records:
        db.table("notifications").insert(records).execute()

    blast = db.table("notification_blasts").insert({
        "title":        body.title,
        "message":      body.message,
        "target_role":  body.role,
        "sent_count":   len(records),
    }).execute()
    return {"message": f"Blast sent to {len(records)} users", "blast": blast}
