"""Leaderboard routes — monthly rankings, hall of fame, personal rank."""

from datetime import date, timedelta
from typing import Optional
from fastapi import APIRouter, Depends, Query

from fastapi_app.deps import UserContext, get_current_user
from fastapi_app.deps import get_db

router = APIRouter()


@router.get("", summary="Get leaderboard rankings. period_type: monthly | weekly | all_time.")
def get_leaderboard(
    period_type: str = Query("monthly"),
    limit:       int = Query(10, ge=1, le=50),
):
    db    = get_db()
    today = date.today()
    if period_type == "monthly":
        period = today.strftime("%Y-%m")
    elif period_type == "weekly":
        week_start = today - timedelta(days=today.weekday())
        period = week_start.isoformat()
    else:
        period = "all_time"

    snapshots = (
        db.table("leaderboard_snapshots")
        .select("*,profiles(full_name),tiers(name,slug,badge_color_hex)")
        .eq("period", period_type)
        .order("rank")
        .limit(limit)
        .execute()
    )

    if not snapshots:
        field = "hp_earned_120day" if period_type == "all_time" else "monthly_hp_earned"
        profile_data = (
            db.table("profiles")
            .select(f"id,full_name,{field}")
            .eq("is_active", True)
            .eq("role", "student")
            .order(field, ascending=False)
            .limit(limit)
            .execute()
        ) or []
        rankings = [
            {"rank": i + 1, "user_id": p["id"], "full_name": p.get("full_name"), "hp_total": p.get(field, 0) or 0}
            for i, p in enumerate(profile_data)
        ]
        return {"period": period, "period_type": period_type, "rankings": rankings}

    return {"period": period, "period_type": period_type, "rankings": snapshots}


@router.get("/hall-of-fame", summary="Permanent Hall of Fame — all-time monthly #1 winners.")
def hall_of_fame():
    db = get_db()
    try:
        entries = db.table("hall_of_fame").select("*,profiles(full_name)").order("month", ascending=False).execute()
        return entries or []
    except Exception:
        return (
            db.table("leaderboard_snapshots")
            .select("*,profiles(full_name)")
            .eq("rank", "1")
            .order("week_start", ascending=False)
            .execute()
        ) or []


@router.get("/my-rank", summary="Get the authenticated user's current rank and HP stats.")
def my_rank(
    period_type: str = Query("monthly"),
    user:        UserContext = Depends(get_current_user),
):
    db = get_db()
    snapshot = (
        db.table("leaderboard_snapshots")
        .select("*")
        .eq("user_id", user.user_id)
        .eq("period", period_type)
        .order("computed_at", ascending=False)
        .limit(1)
        .execute()
    )
    profile = (
        db.table("profiles")
        .select("monthly_hp_earned,hp_earned_120day")
        .eq("id", user.user_id)
        .single()
        .execute()
    )
    return {
        "snapshot":           snapshot[0] if snapshot else None,
        "monthly_hp_earned":  profile.get("monthly_hp_earned", 0) if profile else 0,
        "hp_earned_120day":   profile.get("hp_earned_120day", 0) if profile else 0,
    }
