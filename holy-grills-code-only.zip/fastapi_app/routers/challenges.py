"""Challenge routes — list active challenges, complete, admin CRUD."""

from datetime import datetime, timezone
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from fastapi_app.deps import UserContext, get_current_user, require_role
from fastapi_app.schemas import ChallengeCreate
from app.services.hp_service import earn_pending_hp
from fastapi_app.deps import get_db

router = APIRouter()


class ChallengeUpdate(BaseModel):
    title:       Optional[str] = None
    description: Optional[str] = None
    hp_reward:   Optional[int] = None
    is_active:   Optional[bool] = None
    ends_at:     Optional[str] = None


@router.get("", summary="List all currently active challenges.")
def list_challenges():
    db  = get_db()
    now = datetime.now(timezone.utc).isoformat()
    return (
        db.table("challenges")
        .select("*")
        .eq("is_active", True)
        .lte("starts_at", now)
        .gte("ends_at", now)
        .execute()
    ) or []


@router.get("/my-completions", summary="Get challenges the authenticated user has completed.")
def my_completions(user: UserContext = Depends(get_current_user)):
    db = get_db()
    return (
        db.table("challenge_completions")
        .select("*,challenges(title,hp_reward)")
        .eq("user_id", user.user_id)
        .order("created_at", ascending=False)
        .execute()
    ) or []


@router.post("/{challenge_id}/complete", status_code=200,
    summary="Mark a challenge as completed. Awards pending HP.")
def complete_challenge(challenge_id: str, user: UserContext = Depends(get_current_user)):
    db  = get_db()
    now = datetime.now(timezone.utc).isoformat()

    challenge = (
        db.table("challenges")
        .select("*")
        .eq("id", challenge_id)
        .eq("is_active", True)
        .single()
        .execute()
    )
    if not challenge:
        raise HTTPException(status_code=404, detail="Challenge not found or inactive")
    if challenge.get("ends_at") and challenge["ends_at"] < now:
        raise HTTPException(status_code=400, detail="Challenge has ended")

    existing       = db.table("challenge_completions").select("id").eq("user_id", user.user_id).eq("challenge_id", challenge_id).execute() or []
    max_completions = challenge.get("max_completions_per_user", 1) or 1
    if len(existing) >= max_completions:
        raise HTTPException(status_code=400, detail="Challenge already completed (max completions reached)")

    db.table("challenge_completions").insert({
        "user_id":      user.user_id,
        "challenge_id": challenge_id,
        "completed_at": now,
    }).execute()

    hp_amount = challenge.get("hp_reward", 0) or 0
    hp_result = {}
    if hp_amount > 0:
        hp_result = earn_pending_hp(
            user_id=user.user_id,
            amount=hp_amount,
            source_type="challenge",
            reference_id=challenge_id,
            reference_type="challenge_completion",
            notes=f"Challenge completed: {challenge.get('title', '')}",
        )

    return {
        "message":            "Challenge completed",
        "hp_added_to_pending": hp_result.get("added_to_pending", 0),
        "hp_added_to_overflow": hp_result.get("added_to_overflow", 0),
    }


@router.post("", status_code=201, summary="[Admin] Create a new challenge.")
def create_challenge(body: ChallengeCreate, user: UserContext = Depends(require_role("admin"))):
    db   = get_db()
    data = body.model_dump()
    data["is_active"]   = True
    data["created_by"]  = user.user_id
    result = db.table("challenges").insert(data).execute()
    return result[0] if isinstance(result, list) else result


@router.patch("/{challenge_id}", summary="[Admin] Update a challenge.")
def update_challenge(challenge_id: str, body: ChallengeUpdate, _: UserContext = Depends(require_role("admin"))):
    db   = get_db()
    data = {k: v for k, v in body.model_dump().items() if v is not None}
    db.table("challenges").update(data).eq("id", challenge_id).execute()
    return db.table("challenges").select("*").eq("id", challenge_id).single().execute()
