"""Rewards store routes — browse, redeem, flash redeem."""

from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, Query

from fastapi_app.deps import UserContext, get_current_user, require_role
from fastapi_app.schemas import RewardCreate, RewardUpdate, RedeemRequest, FlashRedeemRequest
from app.services import hp_service
from fastapi_app.deps import get_db

router = APIRouter()


@router.get("", summary="List all active rewards. Filter by category.")
def list_rewards(
    category: Optional[str] = Query(None),
    limit:    int = Query(50, ge=1, le=200),
    offset:   int = Query(0, ge=0),
):
    db = get_db()
    q  = db.table("rewards").select("*").eq("is_active", True)
    if category:
        q = q.eq("category", category)
    rewards = q.order("hp_cost").limit(limit).offset(offset).execute()
    return rewards or []


@router.get("/{reward_id}", summary="Get a single reward by ID.")
def get_reward(reward_id: str):
    db     = get_db()
    reward = db.table("rewards").select("*").eq("id", reward_id).single().execute()
    if not reward:
        raise HTTPException(status_code=404, detail="Reward not found")
    return reward


@router.post("/{reward_id}/redeem", status_code=201,
    summary="Redeem a reward with active HP.")
def redeem_reward(reward_id: str, body: RedeemRequest, user: UserContext = Depends(get_current_user)):
    db     = get_db()
    reward = db.table("rewards").select("*").eq("id", reward_id).eq("is_active", True).single().execute()
    if not reward:
        raise HTTPException(status_code=404, detail="Reward not found or inactive")

    if reward.get("quantity_available") is not None:
        if reward.get("quantity_redeemed", 0) >= reward["quantity_available"]:
            raise HTTPException(status_code=400, detail="Reward is out of stock")

    if reward.get("min_tier_id"):
        tier = hp_service.get_user_tier(user.user_id)
        if tier:
            user_sort  = tier.get("tier", {}).get("sort_order", 1)
            req_tier   = db.table("tiers").select("sort_order").eq("id", reward["min_tier_id"]).single().execute()
            if req_tier and user_sort < req_tier.get("sort_order", 1):
                raise HTTPException(status_code=400, detail="Your tier is not high enough")

    try:
        bal = hp_service.get_hp_balance(user.user_id)
        if bal["active"] < reward["hp_cost"]:
            raise HTTPException(
                status_code=400,
                detail=f"Insufficient HP. Need {reward['hp_cost']}, have {bal['active']}",
            )

        hp_service.spend_hp(
            user_id=user.user_id,
            amount=reward["hp_cost"],
            source_type="reward_redemption",
            reference_type="reward_redemption",
            notes=f"Redeemed: {reward['name']}",
        )

        redemption = db.table("reward_redemptions").insert({
            "user_id":   user.user_id,
            "reward_id": reward_id,
            "hp_spent":  reward["hp_cost"],
            "notes":     body.notes,
        }).execute()

        db.table("rewards").update({"quantity_redeemed": reward.get("quantity_redeemed", 0) + 1}).eq("id", reward_id).execute()
        return redemption
    except HTTPException:
        raise
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


@router.get("/my/redemptions", summary="Get the authenticated user's redemption history.")
def my_redemptions(
    limit:  int = Query(20, ge=1, le=100),
    offset: int = Query(0, ge=0),
    user:   UserContext = Depends(get_current_user),
):
    db = get_db()
    rows = (
        db.table("reward_redemptions")
        .select("*,rewards(name,category,image_url)")
        .eq("user_id", user.user_id)
        .order("created_at", ascending=False)
        .limit(limit)
        .offset(offset)
        .execute()
    )
    return rows or []


@router.post("", status_code=201, summary="[Admin] Create a new reward.")
def create_reward(body: RewardCreate, _: UserContext = Depends(require_role("admin"))):
    db  = get_db()
    row = db.table("rewards").insert(body.model_dump()).execute()
    return row


@router.patch("/{reward_id}", summary="[Admin] Update a reward.")
def update_reward(reward_id: str, body: RewardUpdate, _: UserContext = Depends(require_role("admin"))):
    db   = get_db()
    data = {k: v for k, v in body.model_dump().items() if v is not None}
    db.table("rewards").update(data).eq("id", reward_id).execute()
    return db.table("rewards").select("*").eq("id", reward_id).single().execute()


@router.post("/flash/redeem", status_code=201, summary="Flash-redeem a time-limited reward.")
def flash_redeem(body: FlashRedeemRequest, user: UserContext = Depends(get_current_user)):
    db     = get_db()
    reward = db.table("rewards").select("*").eq("id", body.reward_id).eq("is_active", True).single().execute()
    if not reward:
        raise HTTPException(status_code=404, detail="Flash reward not found")
    existing = (
        db.table("flash_redemptions")
        .select("id")
        .eq("user_id", user.user_id)
        .eq("reward_id", body.reward_id)
        .execute()
    )
    if existing:
        raise HTTPException(status_code=400, detail="Already redeemed this flash reward")
    bal = hp_service.get_hp_balance(user.user_id)
    if bal["active"] < reward["hp_cost"]:
        raise HTTPException(status_code=400, detail=f"Insufficient HP. Need {reward['hp_cost']}, have {bal['active']}")
    hp_service.spend_hp(
        user_id=user.user_id,
        amount=reward["hp_cost"],
        source_type="reward_redemption",
        reference_type="flash_redemption",
        notes=f"Flash redemption: {reward['name']}",
    )
    row = db.table("flash_redemptions").insert({"user_id": user.user_id, "reward_id": body.reward_id}).execute()
    return row
