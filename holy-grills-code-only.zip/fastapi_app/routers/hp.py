"""HP (Holy Points) routes — balance, transactions, tiers, admin grants."""

from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, Query

from fastapi_app.deps import UserContext, get_current_user, require_role
from fastapi_app.schemas import AdminGrantHPRequest, SpendHPRequest
from app.services.hp_service import (
    get_hp_balance, get_user_tier, spend_hp, earn_pending_hp, award_active_hp,
)
from fastapi_app.deps import get_db

router = APIRouter()


@router.get("/balance", summary="Get authenticated user's HP balance: active, pending, overflow.")
def balance(user: UserContext = Depends(get_current_user)):
    bal  = get_hp_balance(user.user_id)
    tier = get_user_tier(user.user_id)
    return {**bal, "tier": tier}


@router.get("/transactions", summary="HP transaction history for the authenticated user.")
def transactions(
    limit:    int = Query(50, ge=1, le=200),
    offset:   int = Query(0, ge=0),
    txn_type: Optional[str] = Query(None, alias="type"),
    user:     UserContext = Depends(get_current_user),
):
    db = get_db()
    q  = db.table("hp_transactions").select("*").eq("user_id", user.user_id)
    if txn_type:
        q = q.eq("type", txn_type)
    txns = q.order("created_at", ascending=False).limit(limit).offset(offset).execute()
    return txns or []


@router.get("/tiers", summary="List all tiers with thresholds, multipliers, and perks.")
def list_tiers():
    db = get_db()
    return db.table("tiers").select("*").order("sort_order").execute() or []


@router.get("/tier", summary="Get the current user's tier and grace period status.")
def my_tier(user: UserContext = Depends(get_current_user)):
    return get_user_tier(user.user_id)


@router.post("/admin/grant", summary="[Admin] Directly award active HP to any user.")
def admin_grant(body: AdminGrantHPRequest, user: UserContext = Depends(require_role("admin"))):
    try:
        result = award_active_hp(
            user_id=body.user_id,
            amount=body.amount,
            source_type="admin",
            reference_type="admin_grant",
            notes=body.reason or f"Admin grant by {user.user_id}",
            issued_by_admin_id=user.user_id,
        )
        return {"message": "HP granted", "transaction": result}
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


@router.get("/pending", summary="Get pending HP pool details for the authenticated user.")
def pending_hp(user: UserContext = Depends(get_current_user)):
    db = get_db()
    txns = (
        db.table("pending_hp_transactions")
        .select("*")
        .eq("user_id", user.user_id)
        .eq("status", "pending")
        .order("created_at", ascending=False)
        .execute()
    )
    return txns or []


@router.get("/unlock-log", summary="Get HP unlock history for the authenticated user.")
def unlock_log(
    limit:  int = Query(20, ge=1, le=100),
    offset: int = Query(0, ge=0),
    user:   UserContext = Depends(get_current_user),
):
    db = get_db()
    rows = (
        db.table("hp_unlock_log")
        .select("*")
        .eq("user_id", user.user_id)
        .order("created_at", ascending=False)
        .limit(limit)
        .offset(offset)
        .execute()
    )
    return rows or []


@router.get("/admin/user/{user_id}", summary="[Admin] View any user's HP balance and tier.")
def admin_user_hp(user_id: str, _: UserContext = Depends(require_role("admin"))):
    bal  = get_hp_balance(user_id)
    tier = get_user_tier(user_id)
    return {**bal, "tier": tier}
