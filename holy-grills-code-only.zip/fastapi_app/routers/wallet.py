"""Wallet routes — balance, top-up, transaction history."""

from fastapi import APIRouter, Depends, HTTPException, Query

from fastapi_app.deps import UserContext, get_current_user
from fastapi_app.schemas import FundWalletRequest
from app.services import payment_service, wallet_service
from fastapi_app.deps import get_db

router = APIRouter()


@router.get("", summary="Get the authenticated user's wallet balance and virtual account details.")
def get_wallet(user: UserContext = Depends(get_current_user)):
    db     = get_db()
    wallet = db.table("wallets").select("*").eq("user_id", user.user_id).single().execute()
    if not wallet:
        raise HTTPException(status_code=404, detail="Wallet not found")
    return wallet


@router.post("/fund/card", status_code=201,
    summary="Initiate a card top-up via Paystack. Returns authorization_url to redirect user.")
def fund_wallet_card(body: FundWalletRequest, user: UserContext = Depends(get_current_user)):
    try:
        result = payment_service.initiate_wallet_topup(
            user_id=user.user_id,
            amount=body.amount,
            callback_url=body.callback_url,
        )
        return result
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Top-up initiation failed: {exc}")


@router.get("/transactions", summary="Get the authenticated user's wallet transaction history.")
def wallet_transactions(
    limit:  int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    user:   UserContext = Depends(get_current_user),
):
    db = get_db()
    wallet = db.table("wallets").select("id").eq("user_id", user.user_id).single().execute()
    if not wallet:
        raise HTTPException(status_code=404, detail="Wallet not found")
    txns = (
        db.table("wallet_transactions")
        .select("*")
        .eq("wallet_id", wallet["id"])
        .order("created_at", ascending=False)
        .limit(limit)
        .offset(offset)
        .execute()
    )
    return txns or []


@router.get("/virtual-account", summary="Get the user's dedicated virtual account number for bank transfers.")
def virtual_account(user: UserContext = Depends(get_current_user)):
    db     = get_db()
    wallet = db.table("wallets").select("virtual_account_number,virtual_account_bank,virtual_account_name,virtual_account_ref").eq("user_id", user.user_id).single().execute()
    if not wallet:
        raise HTTPException(status_code=404, detail="Wallet not found")
    if not wallet.get("virtual_account_number"):
        raise HTTPException(status_code=404, detail="No virtual account yet — a bank transfer DVA is created on first top-up")
    return wallet
