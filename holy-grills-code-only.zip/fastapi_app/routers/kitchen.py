"""Kitchen dashboard routes — role: kitchen | admin."""

from typing import Optional
from fastapi import APIRouter, Depends, Query
from datetime import datetime, timezone

from fastapi_app.deps import UserContext, require_role
from fastapi_app.deps import get_db

router = APIRouter()


@router.get("/queue", summary="[Kitchen] Live order queue — confirmed and preparing orders.")
def live_queue(
    window_id: Optional[str] = Query(None),
    _: UserContext = Depends(require_role("kitchen", "admin")),
):
    db = get_db()
    q  = (
        db.table("orders")
        .select("id,status,notes,created_at,delivery_windows(label,closes_at),order_items(name_snapshot,quantity)")
        .in_("status", ["confirmed", "preparing"])
        .order("created_at")
    )
    if window_id:
        q = q.eq("delivery_window_id", window_id)
    return q.execute() or []


@router.get("/windows", summary="[Kitchen] Current and upcoming delivery windows with order counts.")
def delivery_windows(_: UserContext = Depends(require_role("kitchen", "admin"))):
    db  = get_db()
    now = datetime.now(timezone.utc).isoformat()
    windows = (
        db.table("delivery_windows")
        .select("id,label,opens_at,closes_at,status")
        .gte("closes_at", now)
        .order("opens_at")
        .execute()
    ) or []
    for w in windows:
        rows = db.table("orders").select("id").eq("delivery_window_id", w["id"]).execute() or []
        w["order_count"] = len(rows)
    return windows


@router.get("/batch-summary/{window_id}",
    summary="[Kitchen] Aggregated prep list for a delivery window (total qty per item).")
def batch_summary(window_id: str, _: UserContext = Depends(require_role("kitchen", "admin"))):
    db     = get_db()
    orders = (
        db.table("orders")
        .select("id,order_items(name_snapshot,quantity)")
        .eq("delivery_window_id", window_id)
        .in_("status", ["confirmed", "preparing", "out_for_delivery"])
        .execute()
    ) or []
    aggregated: dict = {}
    for order in orders:
        for item in order.get("order_items", []):
            name = item.get("name_snapshot", "Unknown")
            qty  = int(item.get("quantity", 1))
            aggregated[name] = aggregated.get(name, 0) + qty
    summary = [{"item_name": k, "total_quantity": v} for k, v in sorted(aggregated.items())]
    return {"window_id": window_id, "summary": summary, "total_orders": len(orders)}


@router.post("/orders/{order_id}/start-prep",
    summary="[Kitchen] Move order from confirmed → preparing.")
def start_prep(order_id: str, user: UserContext = Depends(require_role("kitchen", "admin"))):
    db    = get_db()
    order = db.table("orders").select("id,status").eq("id", order_id).single().execute()
    if not order:
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail="Order not found")
    db.table("orders").update({"status": "preparing"}).eq("id", order_id).execute()
    db.table("order_status_log").insert({
        "order_id": order_id, "from_status": order.get("status"),
        "to_status": "preparing", "changed_by": user.user_id,
    }).execute()
    return {"message": "Order moved to preparing"}


@router.post("/orders/{order_id}/ready",
    summary="[Kitchen] Mark order ready for dispatch (preparing → out_for_delivery).")
def mark_ready(order_id: str, user: UserContext = Depends(require_role("kitchen", "admin"))):
    db    = get_db()
    order = db.table("orders").select("id,status").eq("id", order_id).single().execute()
    if not order:
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail="Order not found")
    db.table("orders").update({"status": "out_for_delivery"}).eq("id", order_id).execute()
    db.table("order_status_log").insert({
        "order_id": order_id, "from_status": order.get("status"),
        "to_status": "out_for_delivery", "changed_by": user.user_id,
    }).execute()
    return {"message": "Order ready for dispatch"}
