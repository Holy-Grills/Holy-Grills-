"""Events routes — discovery, check-in, catering requests."""

from typing import Optional
from datetime import datetime, timezone
import hashlib, uuid as _uuid
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from fastapi_app.deps import UserContext, get_current_user, require_role
from fastapi_app.schemas import EventCreate, EventUpdate
from app.services.hp_service import earn_pending_hp
from app.services.notification_service import send_notification
from fastapi_app.deps import get_db

router = APIRouter()


class CheckinBody(BaseModel):
    qr_token: str


class CateringRequest(BaseModel):
    organizer_name:      str
    organizer_email:     str
    event_name:          str
    event_date:          str
    venue:               str
    expected_attendance: int
    organizer_phone:     Optional[str] = None
    event_time:          Optional[str] = None
    budget_range:        Optional[str] = None
    catering_notes:      Optional[str] = None
    hp_promo_optin:      Optional[bool] = False


@router.get("", summary="List active upcoming events.")
def list_events():
    db  = get_db()
    now = datetime.now(timezone.utc).isoformat()
    return (
        db.table("events")
        .select("id,title,slug,description,venue,event_date,event_end_date,hp_earn,hp_promo_enabled,is_featured,ticket_listing_id")
        .eq("is_active", True)
        .gte("event_date", now)
        .order("is_featured", ascending=False)
        .order("event_date")
        .execute()
    ) or []


@router.get("/{event_id}", summary="Get event detail with check-in count.")
def get_event(event_id: str):
    db    = get_db()
    event = db.table("events").select("*").eq("id", event_id).single().execute()
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")
    checkins          = db.table("event_checkins").select("id").eq("event_id", event_id).execute() or []
    event["checkin_count"] = len(checkins)
    return event


@router.post("/{event_id}/checkin", status_code=200,
    summary="Check in to a Holy Grills event via QR token. Awards pending HP (max 3×/month).")
def checkin(event_id: str, body: CheckinBody, user: UserContext = Depends(get_current_user)):
    db = get_db()
    try:
        result = db.rpc("checkin_event_atomic", {
            "p_event_id": event_id, "p_user_id": user.user_id, "p_qr_token": body.qr_token.strip(),
        })
        if isinstance(result, dict) and result.get("error"):
            raise HTTPException(status_code=400, detail=result["error"])
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))

    event     = db.table("events").select("hp_earn,title").eq("id", event_id).single().execute()
    hp_amount = (event.get("hp_earn") or 40) if event else 40
    now       = datetime.now(timezone.utc)
    month_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0).isoformat()
    checkins_this_month = db.table("event_checkins").select("id").eq("user_id", user.user_id).gte("checked_in_at", month_start).execute() or []

    if len(checkins_this_month) >= 3:
        return {"message": "Monthly event check-in limit reached (3x/month). No HP awarded.", "hp_awarded": 0}

    hp_result = earn_pending_hp(
        user_id=user.user_id, amount=hp_amount, source_type="event",
        reference_id=event_id, notes=f"Event check-in HP: {event.get('title', '') if event else ''}",
    )
    send_notification(
        user_id=user.user_id, notif_type="hp_earned",
        title=f"+{hp_result['added_to_pending']} HP Pending!",
        body=f"You earned HP for attending {event.get('title', 'the event') if event else 'the event'}. Order food to unlock it!",
        channels=["in_app"],
    )
    return {"message": "Check-in successful", "hp_added_to_pending": hp_result["added_to_pending"], "hp_added_to_overflow": hp_result.get("added_to_overflow", 0)}


@router.post("/catering-requests", status_code=201,
    summary="Submit a catering / event partnership enquiry.")
def submit_catering_request(body: CateringRequest):
    db   = get_db()
    data = body.model_dump()
    data["status"] = "pending"
    result = db.table("catering_requests").insert(data).execute()
    saved  = result[0] if isinstance(result, list) else result
    admins = db.table("profiles").select("id").eq("role", "admin").execute() or []
    for admin in admins:
        send_notification(
            user_id=admin["id"], notif_type="catering_request",
            title="New Catering Request",
            body=f"{body.organizer_name} submitted a catering request for '{body.event_name}'",
            reference_id=saved.get("id"), reference_type="catering_request", channels=["in_app"],
        )
    return saved


@router.post("", status_code=201, summary="[Admin] Create a new event listing (generates QR token).")
def create_event(body: EventCreate, user: UserContext = Depends(require_role("admin"))):
    db   = get_db()
    data = body.model_dump()
    data["qr_code_token"] = hashlib.sha256(str(_uuid.uuid4()).encode()).hexdigest()[:32]
    data["slug"]          = body.title.lower().replace(" ", "-")[:60]
    data["is_active"]     = True
    data["created_by"]    = user.user_id
    result = db.table("events").insert(data).execute()
    return result[0] if isinstance(result, list) else result


@router.patch("/{event_id}", summary="[Admin] Update an event.")
def update_event(event_id: str, body: EventUpdate, _: UserContext = Depends(require_role("admin"))):
    db   = get_db()
    data = {k: v for k, v in body.model_dump().items() if v is not None}
    db.table("events").update(data).eq("id", event_id).execute()
    return db.table("events").select("*").eq("id", event_id).single().execute()
