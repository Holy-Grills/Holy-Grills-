"""Storefront routes — CMS sections, operating hours, banners, promo code validation."""

from datetime import datetime, timezone, date
from typing import Any, Dict, Optional
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from fastapi_app.deps import UserContext, require_role
from fastapi_app.schemas import BannerCreate, SectionCreate
from fastapi_app.deps import get_db

router = APIRouter()


class SectionUpdate(BaseModel):
    title:       Optional[str] = None
    subtitle:    Optional[str] = None
    body:        Optional[str] = None
    image_url:   Optional[str] = None
    cta_text:    Optional[str] = None
    cta_url:     Optional[str] = None
    is_active:   Optional[bool] = None
    sort_order:  Optional[int] = None
    config:      Optional[Dict[str, Any]] = None


class PromoValidateRequest(BaseModel):
    code:        str
    order_total: float


@router.get("/sections", summary="List active storefront CMS sections (homepage, banners, etc).")
def list_sections():
    db = get_db()
    return db.table("storefront_sections").select("*").eq("is_active", True).order("sort_order").execute() or []


@router.patch("/sections/{section_id}", summary="[Admin] Update a storefront section.")
def update_section(section_id: str, body: SectionUpdate, user: UserContext = Depends(require_role("admin"))):
    db   = get_db()
    data = {k: v for k, v in body.model_dump().items() if v is not None}
    data["last_edited_by"] = user.user_id
    data["updated_at"]     = datetime.now(timezone.utc).isoformat()
    db.table("storefront_sections").update(data).eq("id", section_id).execute()
    return db.table("storefront_sections").select("*").eq("id", section_id).single().execute()


@router.post("/sections", status_code=201, summary="[Admin] Create a storefront section.")
def create_section(body: SectionCreate, user: UserContext = Depends(require_role("admin"))):
    db   = get_db()
    data = body.model_dump()
    data["created_by"] = user.user_id
    result = db.table("storefront_sections").insert(data).execute()
    return result[0] if isinstance(result, list) else result


@router.get("/operating-hours", summary="Get operating hours schedule and today's status.")
def get_hours():
    db    = get_db()
    hours = db.table("operating_hours").select("*").order("day").execute() or []
    today_str = date.today().isoformat()
    override  = db.table("operating_hour_overrides").select("*").eq("date", today_str).single().execute()
    today_day = date.today().weekday()
    today_hours = next((h for h in hours if h.get("day") == today_day), None)
    is_open = False
    if override:
        is_open = override.get("is_open", False)
    elif today_hours:
        is_open = today_hours.get("is_open", False)
    return {
        "schedule":      hours,
        "override":      override,
        "today_is_open": is_open,
        "today_hours":   today_hours,
    }


@router.get("/banners", summary="Get all active storefront banners sorted by sort_order.")
def list_banners():
    db = get_db()
    return db.table("banners").select("*").eq("is_active", True).order("sort_order").execute() or []


@router.post("/banners", status_code=201, summary="[Admin] Create a banner.")
def create_banner(body: BannerCreate, _: UserContext = Depends(require_role("admin"))):
    db  = get_db()
    row = db.table("banners").insert(body.model_dump()).execute()
    return row


@router.patch("/banners/{banner_id}", summary="[Admin] Update a banner.")
def update_banner(banner_id: str, body: BannerCreate, _: UserContext = Depends(require_role("admin"))):
    db   = get_db()
    data = {k: v for k, v in body.model_dump().items() if v is not None}
    db.table("banners").update(data).eq("id", banner_id).execute()
    return db.table("banners").select("*").eq("id", banner_id).single().execute()


@router.post("/promo/validate", summary="Validate a promo code against an order total.")
def validate_promo(body: PromoValidateRequest):
    db   = get_db()
    code = db.table("promo_codes").select("*").eq("code", body.code.upper()).eq("is_active", True).single().execute()
    if not code:
        raise HTTPException(status_code=404, detail="Promo code not found or inactive")

    now = datetime.now(timezone.utc).isoformat()
    if code.get("expires_at") and code["expires_at"] < now:
        raise HTTPException(status_code=400, detail="Promo code has expired")
    if code.get("starts_at") and code["starts_at"] > now:
        raise HTTPException(status_code=400, detail="Promo code is not yet active")
    if code.get("min_order_amount") and body.order_total < float(code["min_order_amount"]):
        raise HTTPException(status_code=400, detail=f"Minimum order amount is ₦{code['min_order_amount']}")
    if code.get("max_uses") and (code.get("times_used", 0) or 0) >= code["max_uses"]:
        raise HTTPException(status_code=400, detail="Promo code usage limit reached")

    discount_type  = code.get("discount_type", "percentage")
    discount_value = float(code.get("discount_value", 0))
    if discount_type == "percentage":
        discount_amount = round(body.order_total * discount_value / 100, 2)
    else:
        discount_amount = min(discount_value, body.order_total)

    return {
        "valid":           True,
        "code":            code["code"],
        "discount_type":   discount_type,
        "discount_value":  discount_value,
        "discount_amount": discount_amount,
        "final_total":     round(body.order_total - discount_amount, 2),
    }
