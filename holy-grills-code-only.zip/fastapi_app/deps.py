"""
FastAPI dependency injection layer.
Mirrors Flask's app/middleware/auth.py but using FastAPI Depends().
"""

from __future__ import annotations

import os
from typing import Optional

import jwt
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

import app.db as _appdb
from app.db import SupabaseError


def get_db():
    """
    Central DB accessor for the FastAPI layer.
    Always resolves through the app.db module attribute so unit-test patches
    to ``app.db.get_db`` are transparent here without needing extra patches.
    """
    return _appdb.get_db()

_security = HTTPBearer(auto_error=False)

JWT_SECRET    = os.environ.get("JWT_SECRET", "")
JWT_ALGORITHM = os.environ.get("JWT_ALGORITHM", "HS256")


class UserContext:
    """Thin wrapper around a decoded JWT + profile row."""

    def __init__(self, user_id: str, role: str, profile: dict, token: str = ""):
        self.user_id = user_id
        self.role    = role
        self.profile = profile
        self.token   = token


# ─── token decoding ──────────────────────────────────────────────────────────

def _decode_token(token: str) -> dict:
    try:
        return jwt.decode(
            token,
            JWT_SECRET,
            algorithms=[JWT_ALGORITHM],
            options={"verify_aud": False},
        )
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token has expired")
    except jwt.InvalidTokenError as exc:
        raise HTTPException(status_code=401, detail=f"Invalid token: {exc}")


def _load_profile(user_id: str, fields: str = "id,full_name,role,is_active,phone,date_of_birth,referral_code,referred_by") -> dict:
    db = get_db()
    try:
        profile = (
            db.table("profiles")
            .select(fields)
            .eq("id", user_id)
            .single()
            .execute()
        )
    except SupabaseError:
        raise HTTPException(status_code=401, detail="User profile not found")

    if not profile.get("is_active", True):
        raise HTTPException(status_code=403, detail="Account is deactivated")

    return profile


# ─── core dependencies ────────────────────────────────────────────────────────

async def get_current_user(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(_security),
) -> UserContext:
    """Require a valid Bearer JWT. Raises 401 if missing or invalid."""
    if not credentials:
        raise HTTPException(status_code=401, detail="Missing Authorization header")
    payload  = _decode_token(credentials.credentials)
    user_id  = payload.get("sub")
    profile  = _load_profile(user_id)
    return UserContext(user_id=user_id, role=profile.get("role", "student"), profile=profile, token=credentials.credentials)


async def get_optional_user(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(_security),
) -> Optional[UserContext]:
    """Try to load user but return None for guest requests (no token or bad token)."""
    if not credentials:
        return None
    try:
        payload = _decode_token(credentials.credentials)
        user_id = payload.get("sub")
        profile = _load_profile(user_id)
        return UserContext(user_id=user_id, role=profile.get("role", "student"), profile=profile, token=credentials.credentials)
    except HTTPException:
        return None


def require_role(*roles: str):
    """
    Returns a FastAPI dependency that enforces role membership.

    Usage:
        @router.get("/admin-only")
        def endpoint(user: UserContext = Depends(require_role("admin"))):
            ...
    """
    async def _dep(
        credentials: Optional[HTTPAuthorizationCredentials] = Depends(_security),
    ) -> UserContext:
        if not credentials:
            raise HTTPException(status_code=401, detail="Missing Authorization header")
        payload  = _decode_token(credentials.credentials)
        user_id  = payload.get("sub")
        profile  = _load_profile(user_id, fields="id,full_name,role,is_active")
        role     = profile.get("role", "")
        if role not in roles:
            raise HTTPException(
                status_code=403,
                detail=f"Requires one of roles: {', '.join(roles)}",
            )
        return UserContext(user_id=user_id, role=role, profile=profile, token=credentials.credentials)

    return _dep
