"""
Pydantic v2 request/response schemas for the FastAPI implementation.
All schemas mirror the validation the Flask routes enforce manually.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field, field_validator


# ─── Auth ────────────────────────────────────────────────────────────────────

class RegisterRequest(BaseModel):
    email: str
    password: str = Field(min_length=8)
    full_name: str
    phone: Optional[str] = None
    date_of_birth: Optional[str] = None
    referred_by_code: Optional[str] = None


class LoginRequest(BaseModel):
    email: str
    password: str


class RefreshRequest(BaseModel):
    refresh_token: str


class UpdateProfileRequest(BaseModel):
    full_name: Optional[str] = None
    phone: Optional[str] = None
    date_of_birth: Optional[str] = None
    push_enabled: Optional[bool] = None
    email_notifications: Optional[bool] = None


# ─── Menu ────────────────────────────────────────────────────────────────────

class CategoryCreate(BaseModel):
    name: str
    slug: str
    description: Optional[str] = None
    sort_order: Optional[int] = 0
    image_url: Optional[str] = None


class CategoryUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    sort_order: Optional[int] = None
    is_active: Optional[bool] = None
    image_url: Optional[str] = None


class MenuItemCreate(BaseModel):
    category_id: str
    name: str
    description: Optional[str] = None
    sku: Optional[str] = None
    price: float
    cost_price: Optional[float] = None
    perceived_value: Optional[float] = None
    hp_earn_value: Optional[int] = None
    dietary_tags: Optional[List[str]] = None
    image_url: Optional[str] = None
    daily_limit: Optional[int] = None


class MenuItemUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    price: Optional[float] = None
    cost_price: Optional[float] = None
    perceived_value: Optional[float] = None
    hp_earn_value: Optional[int] = None
    dietary_tags: Optional[List[str]] = None
    is_available: Optional[bool] = None
    image_url: Optional[str] = None
    category_id: Optional[str] = None
    daily_limit: Optional[int] = None


class AddonCreate(BaseModel):
    name: str
    description: Optional[str] = None
    price: float
    is_available: Optional[bool] = True
    image_url: Optional[str] = None


class AddonUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    price: Optional[float] = None
    is_available: Optional[bool] = None
    image_url: Optional[str] = None


class VariationGroupCreate(BaseModel):
    name: str
    is_required: Optional[bool] = False
    min_selections: Optional[int] = 0
    max_selections: Optional[int] = 1


class VariationGroupUpdate(BaseModel):
    name: Optional[str] = None
    is_required: Optional[bool] = None
    min_selections: Optional[int] = None
    max_selections: Optional[int] = None


class VariationOptionCreate(BaseModel):
    name: str
    price_delta: Optional[float] = 0
    is_available: Optional[bool] = True


class VariationOptionUpdate(BaseModel):
    name: Optional[str] = None
    price_delta: Optional[float] = None
    is_available: Optional[bool] = None


class KitchenCapacityUpdate(BaseModel):
    daily_order_capacity: Optional[int] = None


# ─── Orders ──────────────────────────────────────────────────────────────────

class OrderItemIn(BaseModel):
    menu_item_id: str
    quantity: int = Field(ge=1)
    selected_variations: Optional[List[Dict[str, str]]] = None


class DeliveryAddress(BaseModel):
    address_line: str
    landmark: Optional[str] = None
    zone: Optional[str] = None


class AddonIn(BaseModel):
    addon_id: str
    quantity: int = Field(default=1, ge=1)


class CreateOrderRequest(BaseModel):
    items: List[OrderItemIn] = Field(min_length=1)
    delivery_window_id: str
    payment_method: str
    delivery_address: DeliveryAddress
    promo_code: Optional[str] = None
    hp_points_to_redeem: Optional[int] = 0
    notes: Optional[str] = None
    addons: Optional[List[AddonIn]] = None
    is_scheduled: Optional[bool] = False
    scheduled_for_window_id: Optional[str] = None
    guest_name: Optional[str] = None
    guest_phone: Optional[str] = None
    guest_email: Optional[str] = None

    @field_validator("payment_method")
    @classmethod
    def validate_payment_method(cls, v: str) -> str:
        if v not in {"wallet", "card", "split"}:
            raise ValueError("payment_method must be wallet, card, or split")
        return v


class ReviewRequest(BaseModel):
    rating: int = Field(ge=1, le=5)
    comment: Optional[str] = None


class OrderStatusUpdate(BaseModel):
    status: str
    notes: Optional[str] = None


# ─── HP ──────────────────────────────────────────────────────────────────────

class AdminGrantHPRequest(BaseModel):
    user_id: str
    amount: int = Field(ge=1)
    reason: Optional[str] = None


class SpendHPRequest(BaseModel):
    amount: int = Field(ge=1)
    reason: Optional[str] = None


# ─── Wallet ──────────────────────────────────────────────────────────────────

class FundWalletRequest(BaseModel):
    amount: float = Field(ge=100, description="Minimum ₦100")
    callback_url: Optional[str] = None


class BankTransferRequest(BaseModel):
    pass


# ─── Rewards ─────────────────────────────────────────────────────────────────

class RewardCreate(BaseModel):
    name: str
    description: Optional[str] = None
    category: str
    hp_cost: int = Field(ge=1)
    image_url: Optional[str] = None
    quantity_available: Optional[int] = None
    min_tier_id: Optional[str] = None
    starts_at: Optional[str] = None
    ends_at: Optional[str] = None


class RewardUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    hp_cost: Optional[int] = None
    is_active: Optional[bool] = None
    quantity_available: Optional[int] = None


class RedeemRequest(BaseModel):
    notes: Optional[str] = None


class FlashRedeemRequest(BaseModel):
    reward_id: str


# ─── Referrals ───────────────────────────────────────────────────────────────

class CompleteReferralRequest(BaseModel):
    referred_user_id: str


# ─── Notifications ───────────────────────────────────────────────────────────

class NotificationBlastRequest(BaseModel):
    title: str
    message: str
    role: Optional[str] = None
    type: Optional[str] = "system"


# ─── Marketplace ─────────────────────────────────────────────────────────────

class ListingCreate(BaseModel):
    title: str
    description: Optional[str] = None
    hp_price: int = Field(ge=1)
    quantity_available: Optional[int] = None
    image_url: Optional[str] = None
    category: Optional[str] = None
    ends_at: Optional[str] = None


class ListingUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    hp_price: Optional[int] = None
    quantity_available: Optional[int] = None
    is_active: Optional[bool] = None


class PurchaseRequest(BaseModel):
    listing_id: str
    quantity: Optional[int] = 1


# ─── Storefront ──────────────────────────────────────────────────────────────

class PageCreate(BaseModel):
    slug: str
    title: str
    is_published: Optional[bool] = False


class SectionCreate(BaseModel):
    page_id: str
    type: str
    content: Optional[Dict[str, Any]] = None
    sort_order: Optional[int] = 0


class BannerCreate(BaseModel):
    title: str
    image_url: str
    link_url: Optional[str] = None
    is_active: Optional[bool] = True
    sort_order: Optional[int] = 0


# ─── Admin ───────────────────────────────────────────────────────────────────

class UserRoleUpdate(BaseModel):
    role: str


class UserStatusUpdate(BaseModel):
    is_active: bool
    reason: Optional[str] = None


class PromocodeCreate(BaseModel):
    code: str
    discount_type: str
    discount_value: float
    min_order_amount: Optional[float] = None
    max_uses: Optional[int] = None
    starts_at: Optional[str] = None
    expires_at: Optional[str] = None


class DeliveryWindowCreate(BaseModel):
    label: str
    opens_at: str
    closes_at: str


class BatchCreate(BaseModel):
    window_id: str
    rider_id: str
    zone: Optional[str] = None


# ─── Events ──────────────────────────────────────────────────────────────────

class EventCreate(BaseModel):
    title: str
    description: Optional[str] = None
    location: Optional[str] = None
    starts_at: str
    ends_at: Optional[str] = None
    hp_reward: Optional[int] = None
    max_attendees: Optional[int] = None


class EventUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    location: Optional[str] = None
    starts_at: Optional[str] = None
    ends_at: Optional[str] = None
    hp_reward: Optional[int] = None
    is_active: Optional[bool] = None


class CheckinRequest(BaseModel):
    event_id: str
    qr_code: Optional[str] = None


# ─── Challenges ──────────────────────────────────────────────────────────────

class ChallengeCreate(BaseModel):
    title: str
    description: Optional[str] = None
    hp_reward: int = Field(ge=1)
    target_type: str
    target_value: int = Field(ge=1)
    starts_at: Optional[str] = None
    ends_at: Optional[str] = None


class ChallengeCompleteRequest(BaseModel):
    challenge_id: str


# ─── Kitchen ─────────────────────────────────────────────────────────────────

class KitchenStatusUpdate(BaseModel):
    order_id: str
    status: str
    notes: Optional[str] = None


# ─── Riders ──────────────────────────────────────────────────────────────────

class RiderProfileUpdate(BaseModel):
    full_name: Optional[str] = None
    phone: Optional[str] = None
    vehicle_type: Optional[str] = None
    vehicle_plate: Optional[str] = None


class BatchStatusUpdate(BaseModel):
    status: str


# ─── Webhooks ────────────────────────────────────────────────────────────────

class PaystackWebhookEvent(BaseModel):
    event: str
    data: Dict[str, Any]
