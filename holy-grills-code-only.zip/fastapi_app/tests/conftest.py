"""
FastAPI test configuration.

Uses FastAPI's TestClient (synchronous, Starlette-based).
Mocks app.db.get_db identically to the Flask conftest so the same
mock DB patterns work across both implementations.
No live Supabase connection is made during tests.
"""

import os
import pytest
from datetime import datetime, timezone, timedelta
from unittest.mock import MagicMock, patch

import jwt
from fastapi.testclient import TestClient

# ── env setup (must happen before app imports) ─────────────────────────────
os.environ.setdefault("JWT_SECRET",              "test-fastapi-secret")
os.environ.setdefault("JWT_ALGORITHM",           "HS256")
os.environ.setdefault("SUPABASE_URL",            "https://mock.supabase.co")
os.environ.setdefault("SUPABASE_SERVICE_ROLE_KEY","mock-service-key")
os.environ.setdefault("SUPABASE_ANON_KEY",       "mock-anon-key")
os.environ.setdefault("SECRET_KEY",              "test-secret-key")
os.environ.setdefault("PAYSTACK_SECRET_KEY",     "sk_test_mock")
os.environ.setdefault("PAYSTACK_WEBHOOK_SECRET", "mock-webhook-secret")
os.environ.setdefault("REDIS_URL",               "redis://localhost:6379/0")

# ── Fixed IDs ──────────────────────────────────────────────────────────────
STUDENT_ID   = "aaaaaaaa-0000-0000-0000-000000000001"
ADMIN_ID     = "aaaaaaaa-0000-0000-0000-000000000002"
KITCHEN_ID   = "aaaaaaaa-0000-0000-0000-000000000003"
RIDER_ID     = "aaaaaaaa-0000-0000-0000-000000000004"
ORDER_ID     = "bbbbbbbb-0000-0000-0000-000000000001"
MENU_ITEM_ID = "cccccccc-0000-0000-0000-000000000001"
WINDOW_ID    = "dddddddd-0000-0000-0000-000000000001"
REWARD_ID    = "eeeeeeee-0000-0000-0000-000000000001"
ADDON_ID     = "ffffffff-0000-0000-0000-000000000001"

JWT_SECRET = os.environ["JWT_SECRET"]


def make_jwt(user_id: str, role: str = "student") -> str:
    payload = {
        "sub":   user_id,
        "role":  role,
        "email": f"{role}@test.com",
        "aud":   "authenticated",
        "exp":   int((datetime.now(timezone.utc) + timedelta(hours=1)).timestamp()),
        "iat":   int(datetime.now(timezone.utc).timestamp()),
    }
    return jwt.encode(payload, JWT_SECRET, algorithm="HS256")


# Convenience token helpers
def student_token() -> str: return make_jwt(STUDENT_ID, "student")
def admin_token()   -> str: return make_jwt(ADMIN_ID,   "admin")
def kitchen_token() -> str: return make_jwt(KITCHEN_ID, "kitchen")
def rider_token()   -> str: return make_jwt(RIDER_ID,   "rider")


# ── Sample DB objects ──────────────────────────────────────────────────────
SAMPLE_PROFILE = {
    "id": STUDENT_ID, "email": "student@test.com", "full_name": "Test Student",
    "role": "student", "is_active": True, "referral_code": "HG-TEST01",
    "phone": "08012345678", "date_of_birth": None, "referred_by": None,
    "push_enabled": True, "email_notifications": True,
}
ADMIN_PROFILE = {**SAMPLE_PROFILE, "id": ADMIN_ID, "role": "admin", "email": "admin@test.com", "full_name": "Admin User"}
KITCHEN_PROFILE = {**SAMPLE_PROFILE, "id": KITCHEN_ID, "role": "kitchen", "email": "kitchen@test.com", "full_name": "Kitchen Staff"}
RIDER_PROFILE   = {**SAMPLE_PROFILE, "id": RIDER_ID, "role": "rider", "email": "rider@test.com", "full_name": "Test Rider"}

SAMPLE_MENU_ITEM = {
    "id": MENU_ITEM_ID, "name": "Grilled Chicken", "price": 2500.0,
    "category_id": "cat-001", "is_available": True, "is_archived": False,
    "daily_limit": None, "description": "Juicy grilled chicken", "image_url": None,
}
SAMPLE_ORDER = {
    "id": ORDER_ID, "user_id": STUDENT_ID, "status": "confirmed",
    "total": 2500.0, "subtotal": 2500.0, "discount": 0, "hp_discount": 0,
    "payment_method": "wallet", "delivery_window_id": WINDOW_ID,
    "delivery_address": {"address_line": "Room 1, Block A", "zone": "Main Campus"},
    "review_submitted": False, "created_at": datetime.now(timezone.utc).isoformat(),
}
SAMPLE_REWARD = {
    "id": REWARD_ID, "name": "Free Drink", "hp_cost": 100, "is_active": True,
    "category": "food", "quantity_available": None, "quantity_redeemed": 0,
    "min_tier_id": None, "description": "A free soft drink",
}
SAMPLE_WALLET = {
    "id": "wallet-001", "user_id": STUDENT_ID, "balance": 5000.0, "currency": "NGN",
    "virtual_account_number": None, "virtual_account_bank": None,
}
SAMPLE_ADDON = {
    "id": ADDON_ID, "name": "Extra Sauce", "price": 200.0, "is_available": True, "is_archived": False,
}


# ── Mock DB builder ────────────────────────────────────────────────────────
class MockTableQuery:
    """Chainable mock that returns configured data at .execute()."""
    def __init__(self, data=None):
        self._data = data if data is not None else []
    def select(self, *a, **kw):   return self
    def insert(self, *a, **kw):   return self
    def update(self, *a, **kw):   return self
    def delete(self, *a, **kw):   return self
    def eq(self, *a, **kw):       return self
    def neq(self, *a, **kw):      return self
    def in_(self, *a, **kw):      return self
    def gte(self, *a, **kw):      return self
    def lte(self, *a, **kw):      return self
    def ilike(self, *a, **kw):    return self
    def order(self, *a, **kw):    return self
    def limit(self, *a, **kw):    return self
    def offset(self, *a, **kw):   return self
    def single(self):
        if isinstance(self._data, list):
            return _SingleWrapper(self._data[0] if self._data else None)
        return _SingleWrapper(self._data)
    def execute(self):
        if isinstance(self._data, list):
            return self._data
        return self._data


class _SingleWrapper:
    def __init__(self, data): self._data = data
    def execute(self): return self._data


def make_mock_db(table_data: dict | None = None):
    """Returns a mock DB client. table_data maps table name → list of rows."""
    td = table_data or {}
    db = MagicMock()
    def _table(name):
        rows = td.get(name, [])
        return MockTableQuery(rows)
    db.table.side_effect = _table
    db.rpc.return_value  = {}
    return db


# ── App + Client fixture ───────────────────────────────────────────────────
@pytest.fixture(scope="session")
def fastapi_app():
    from fastapi_app.main import create_fastapi_app
    return create_fastapi_app()


@pytest.fixture
def mock_db_student():
    return make_mock_db({
        "profiles": [SAMPLE_PROFILE],
        "menu_items": [SAMPLE_MENU_ITEM],
        "orders": [SAMPLE_ORDER],
        "order_items": [],
        "rewards": [SAMPLE_REWARD],
        "wallets": [SAMPLE_WALLET],
        "menu_addons": [SAMPLE_ADDON],
        "kitchen_settings": [],
        "hp_transactions": [],
        "pending_hp_transactions": [],
        "reward_redemptions": [],
        "notifications": [],
        "referrals": [],
        "tiers": [{"id": "tier-1", "name": "Ember", "sort_order": 1, "min_hp_threshold": 0, "earn_multiplier": 1.0}],
        "user_tiers": [{"id": "ut-1", "user_id": STUDENT_ID, "tier_id": "tier-1", "is_current": True, "is_in_grace_period": False}],
    })


@pytest.fixture
def mock_db_admin():
    return make_mock_db({
        "profiles": [ADMIN_PROFILE, SAMPLE_PROFILE],
        "menu_items": [SAMPLE_MENU_ITEM],
        "orders": [SAMPLE_ORDER],
        "order_items": [],
        "rewards": [SAMPLE_REWARD],
        "wallets": [SAMPLE_WALLET],
        "menu_addons": [SAMPLE_ADDON],
        "kitchen_settings": [],
        "hp_transactions": [],
        "tiers": [],
        "user_tiers": [],
    })


@pytest.fixture
def client(fastapi_app, mock_db_student):
    # Patching app.db.get_db is sufficient:
    # - FastAPI routers call fastapi_app.deps.get_db()
    # - fastapi_app.deps.get_db() calls _appdb.get_db() via module ref
    # - _appdb IS app.db, so the patch propagates through the full chain.
    with patch("app.db.get_db", return_value=mock_db_student):
        with TestClient(fastapi_app, raise_server_exceptions=True) as c:
            yield c


@pytest.fixture
def admin_client(fastapi_app, mock_db_admin):
    with patch("app.db.get_db", return_value=mock_db_admin):
        with TestClient(fastapi_app, raise_server_exceptions=True) as c:
            yield c


@pytest.fixture
def auth_headers():
    return {"Authorization": f"Bearer {student_token()}"}


@pytest.fixture
def admin_headers():
    return {"Authorization": f"Bearer {admin_token()}"}


@pytest.fixture
def kitchen_headers():
    return {"Authorization": f"Bearer {kitchen_token()}"}


@pytest.fixture
def rider_headers():
    return {"Authorization": f"Bearer {rider_token()}"}
