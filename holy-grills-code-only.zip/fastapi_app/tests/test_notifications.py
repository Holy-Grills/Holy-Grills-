"""FastAPI notifications endpoint tests."""

import pytest
from unittest.mock import patch
from fastapi.testclient import TestClient

from fastapi_app.tests.conftest import (
    STUDENT_ID, SAMPLE_PROFILE, ADMIN_PROFILE, make_mock_db,
    student_token, admin_token,
)

SAMPLE_NOTIFICATION = {
    "id": "notif-001", "user_id": STUDENT_ID,
    "title": "Test", "message": "Hello", "type": "system", "is_read": False,
    "created_at": "2026-01-01T00:00:00Z",
}


class TestListNotifications:
    def test_requires_auth(self, client):
        resp = client.get("/api/notifications")
        assert resp.status_code == 401

    def test_returns_inbox(self, fastapi_app):
        db = make_mock_db({"profiles": [SAMPLE_PROFILE], "notifications": [SAMPLE_NOTIFICATION]})
        with patch("app.db.get_db", return_value=db), \
             patch("fastapi_app.deps.get_db", return_value=db):
            with TestClient(fastapi_app) as c:
                resp = c.get("/api/notifications", headers={"Authorization": f"Bearer {student_token()}"})
                assert resp.status_code == 200
                body = resp.json()
                assert "notifications" in body
                assert "unread_count" in body

    def test_unread_only_filter(self, fastapi_app):
        db = make_mock_db({"profiles": [SAMPLE_PROFILE], "notifications": [SAMPLE_NOTIFICATION]})
        with patch("app.db.get_db", return_value=db), \
             patch("fastapi_app.deps.get_db", return_value=db):
            with TestClient(fastapi_app) as c:
                resp = c.get("/api/notifications?unread_only=true",
                             headers={"Authorization": f"Bearer {student_token()}"})
                assert resp.status_code == 200


class TestMarkRead:
    def test_requires_auth(self, client):
        resp = client.post("/api/notifications/notif-001/read")
        assert resp.status_code == 401

    def test_marks_notification_read(self, fastapi_app):
        db = make_mock_db({"profiles": [SAMPLE_PROFILE], "notifications": [SAMPLE_NOTIFICATION]})
        with patch("app.db.get_db", return_value=db), \
             patch("fastapi_app.deps.get_db", return_value=db):
            with TestClient(fastapi_app) as c:
                resp = c.post("/api/notifications/notif-001/read",
                              headers={"Authorization": f"Bearer {student_token()}"})
                assert resp.status_code == 200

    def test_wrong_user_returns_403(self, fastapi_app):
        other_user_notif = {**SAMPLE_NOTIFICATION, "user_id": "other-user-id"}
        db = make_mock_db({"profiles": [SAMPLE_PROFILE], "notifications": [other_user_notif]})
        with patch("app.db.get_db", return_value=db), \
             patch("fastapi_app.deps.get_db", return_value=db):
            with TestClient(fastapi_app) as c:
                resp = c.post("/api/notifications/notif-001/read",
                              headers={"Authorization": f"Bearer {student_token()}"})
                assert resp.status_code == 403


class TestMarkAllRead:
    def test_requires_auth(self, client):
        resp = client.post("/api/notifications/read-all")
        assert resp.status_code == 401

    def test_marks_all_read(self, client, auth_headers):
        resp = client.post("/api/notifications/read-all", headers=auth_headers)
        assert resp.status_code == 200


class TestAdminBlast:
    def test_requires_admin(self, client, auth_headers):
        resp = client.post("/api/notifications/blast", json={"title": "Hi", "message": "All"}, headers=auth_headers)
        assert resp.status_code == 403

    def test_admin_can_blast(self, fastapi_app, mock_db_admin):
        with patch("app.db.get_db", return_value=mock_db_admin), \
             patch("fastapi_app.deps.get_db", return_value=mock_db_admin):
            with TestClient(fastapi_app) as c:
                resp = c.post(
                    "/api/notifications/blast",
                    json={"title": "Promo!", "message": "50% off today"},
                    headers={"Authorization": f"Bearer {admin_token()}"},
                )
                assert resp.status_code == 201
