"""FastAPI referral endpoint tests."""

import pytest
from unittest.mock import patch
from fastapi.testclient import TestClient

from fastapi_app.tests.conftest import (
    STUDENT_ID, SAMPLE_PROFILE, make_mock_db, student_token,
)

FRIEND_ID = "ffffffff-0000-0000-0000-000000000099"

SAMPLE_REFERRAL_PENDING = {
    "id": "ref-001", "referrer_id": STUDENT_ID,
    "referred_user_id": FRIEND_ID, "status": "pending",
}
SAMPLE_REFERRAL_COMPLETED = {
    "id": "ref-002", "referrer_id": STUDENT_ID,
    "referred_user_id": "friend-002", "status": "completed",
}

# Patch earn_pending_hp at the router import site (not the service module)
_EARN_HP = "fastapi_app.routers.referrals.earn_pending_hp"


class TestMyReferrals:
    def test_requires_auth(self, client):
        resp = client.get("/api/referrals")
        assert resp.status_code == 401

    def test_returns_referral_info(self, client, auth_headers):
        resp = client.get("/api/referrals", headers=auth_headers)
        assert resp.status_code == 200
        body = resp.json()
        assert "referral_code" in body
        assert "referral_link" in body
        assert "completed_referrals" in body
        assert "total_referrals" in body

    def test_referral_link_format(self, client, auth_headers):
        resp = client.get("/api/referrals", headers=auth_headers)
        body = resp.json()
        assert "holygrill.app" in body["referral_link"]


class TestCompleteReferral:
    def test_requires_auth(self, client):
        resp = client.post("/api/referrals/complete", json={"referred_user_id": FRIEND_ID})
        assert resp.status_code == 401

    def test_completes_pending_referral(self, fastapi_app):
        # Mock DB contains only the one pending referral being targeted
        db = make_mock_db({
            "profiles":  [SAMPLE_PROFILE],
            "referrals": [SAMPLE_REFERRAL_PENDING],
        })
        with patch("app.db.get_db", return_value=db), \
             patch(_EARN_HP, return_value={"added_to_pending": 75, "added_to_overflow": 0}):
            with TestClient(fastapi_app) as c:
                resp = c.post(
                    "/api/referrals/complete",
                    json={"referred_user_id": FRIEND_ID},
                    headers={"Authorization": f"Bearer {student_token()}"},
                )
                assert resp.status_code == 201
                body = resp.json()
                assert body["hp_awarded"] == 75

    def test_already_completed_referral_returns_400(self, fastapi_app):
        # Mock DB contains a completed referral for this friend
        db = make_mock_db({
            "profiles":  [SAMPLE_PROFILE],
            "referrals": [SAMPLE_REFERRAL_COMPLETED],
        })
        with patch("app.db.get_db", return_value=db):
            with TestClient(fastapi_app) as c:
                resp = c.post(
                    "/api/referrals/complete",
                    json={"referred_user_id": "friend-002"},
                    headers={"Authorization": f"Bearer {student_token()}"},
                )
                assert resp.status_code == 400

    def test_nonexistent_referral_returns_404(self, fastapi_app):
        db = make_mock_db({"profiles": [SAMPLE_PROFILE], "referrals": []})
        with patch("app.db.get_db", return_value=db):
            with TestClient(fastapi_app) as c:
                resp = c.post(
                    "/api/referrals/complete",
                    json={"referred_user_id": "nobody"},
                    headers={"Authorization": f"Bearer {student_token()}"},
                )
                assert resp.status_code == 404

    def test_no_monthly_cap_on_referrals(self, fastapi_app):
        """Confirm unlimited referrals — no monthly cap applied."""
        # Only the pending referral for the targeted friend is in the mock DB
        pending = {"id": "ref-new", "referrer_id": STUDENT_ID, "referred_user_id": "friend-new", "status": "pending"}
        db = make_mock_db({"profiles": [SAMPLE_PROFILE], "referrals": [pending]})
        with patch("app.db.get_db", return_value=db), \
             patch(_EARN_HP, return_value={"added_to_pending": 75, "added_to_overflow": 0}):
            with TestClient(fastapi_app) as c:
                resp = c.post(
                    "/api/referrals/complete",
                    json={"referred_user_id": "friend-new"},
                    headers={"Authorization": f"Bearer {student_token()}"},
                )
                assert resp.status_code == 201
                assert "cap" not in resp.json().get("message", "").lower()


class TestReferralMilestones:
    def test_milestones_public(self, client):
        resp = client.get("/api/referrals/milestones")
        assert resp.status_code == 200
        body = resp.json()
        assert "milestones" in body
        assert len(body["milestones"]) >= 2
