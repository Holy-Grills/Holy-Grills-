"""FastAPI rewards endpoint tests."""

import pytest
from unittest.mock import patch, MagicMock
from fastapi.testclient import TestClient

from fastapi_app.tests.conftest import (
    STUDENT_ID, REWARD_ID, SAMPLE_PROFILE, SAMPLE_REWARD, make_mock_db,
    student_token, admin_token,
)


class TestListRewards:
    def test_no_auth_required(self, client):
        resp = client.get("/api/rewards")
        assert resp.status_code == 200

    def test_returns_list(self, client):
        resp = client.get("/api/rewards")
        assert isinstance(resp.json(), list)

    def test_category_filter(self, client):
        resp = client.get("/api/rewards?category=food")
        assert resp.status_code == 200


class TestGetReward:
    def test_returns_reward(self, client):
        resp = client.get(f"/api/rewards/{REWARD_ID}")
        assert resp.status_code == 200
        assert resp.json()["id"] == REWARD_ID

    def test_404_on_missing(self, fastapi_app, mock_db_student):
        db = make_mock_db({"profiles": [SAMPLE_PROFILE], "rewards": []})
        with patch("app.db.get_db", return_value=db), \
             patch("fastapi_app.deps.get_db", return_value=db):
            with TestClient(fastapi_app) as c:
                resp = c.get("/api/rewards/nonexistent")
                assert resp.status_code == 404


class TestRedeemReward:
    def test_requires_auth(self, client):
        resp = client.post(f"/api/rewards/{REWARD_ID}/redeem", json={})
        assert resp.status_code == 401

    def test_insufficient_hp_returns_400(self, client, auth_headers):
        with patch("app.services.hp_service.get_hp_balance", return_value={"active": 0}), \
             patch("app.services.hp_service.get_user_tier", return_value=None):
            resp = client.post(f"/api/rewards/{REWARD_ID}/redeem", json={}, headers=auth_headers)
        assert resp.status_code == 400
        assert "insufficient" in resp.json()["detail"].lower()

    def test_sufficient_hp_succeeds(self, client, auth_headers):
        with patch("app.services.hp_service.get_hp_balance", return_value={"active": 1000}), \
             patch("app.services.hp_service.get_user_tier", return_value=None), \
             patch("app.services.hp_service.spend_hp", return_value={"id": "tx-1"}):
            resp = client.post(f"/api/rewards/{REWARD_ID}/redeem", json={}, headers=auth_headers)
        assert resp.status_code in (200, 201)

    def test_out_of_stock_returns_400(self, fastapi_app, mock_db_student):
        db = make_mock_db({
            "profiles": [SAMPLE_PROFILE],
            "rewards": [{**SAMPLE_REWARD, "quantity_available": 5, "quantity_redeemed": 5}],
        })
        with patch("app.db.get_db", return_value=db), \
             patch("fastapi_app.deps.get_db", return_value=db), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 1000}), \
             patch("app.services.hp_service.get_user_tier", return_value=None):
            with TestClient(fastapi_app) as c:
                resp = c.post(
                    f"/api/rewards/{REWARD_ID}/redeem", json={},
                    headers={"Authorization": f"Bearer {student_token()}"},
                )
                assert resp.status_code == 400
                assert "stock" in resp.json()["detail"].lower()


class TestMyRedemptions:
    def test_requires_auth(self, client):
        resp = client.get("/api/rewards/my/redemptions")
        assert resp.status_code == 401

    def test_returns_list(self, client, auth_headers):
        resp = client.get("/api/rewards/my/redemptions", headers=auth_headers)
        assert resp.status_code == 200
        assert isinstance(resp.json(), list)


class TestAdminCreateReward:
    def test_admin_can_create(self, fastapi_app, mock_db_admin):
        with patch("app.db.get_db", return_value=mock_db_admin), \
             patch("fastapi_app.deps.get_db", return_value=mock_db_admin):
            with TestClient(fastapi_app) as c:
                resp = c.post(
                    "/api/rewards",
                    json={"name": "New Reward", "category": "food", "hp_cost": 200},
                    headers={"Authorization": f"Bearer {admin_token()}"},
                )
                assert resp.status_code in (200, 201)

    def test_student_cannot_create(self, client, auth_headers):
        resp = client.post("/api/rewards", json={"name": "X", "category": "food", "hp_cost": 100}, headers=auth_headers)
        assert resp.status_code == 403
