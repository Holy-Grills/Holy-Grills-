"""FastAPI order endpoint tests."""

import pytest
from unittest.mock import patch, MagicMock
from fastapi.testclient import TestClient

from fastapi_app.tests.conftest import (
    STUDENT_ID, ORDER_ID, WINDOW_ID, MENU_ITEM_ID, ADDON_ID,
    SAMPLE_ORDER, SAMPLE_MENU_ITEM, SAMPLE_PROFILE, make_mock_db,
    student_token, admin_token,
)

VALID_ORDER_BODY = {
    "items": [{"menu_item_id": MENU_ITEM_ID, "quantity": 1}],
    "delivery_window_id": WINDOW_ID,
    "payment_method": "wallet",
    "delivery_address": {"address_line": "Room 1, Block A", "zone": "Main Campus"},
}


# ── POST /api/orders ───────────────────────────────────────────────────────

class TestCreateOrder:
    def test_authenticated_order_creation(self, fastapi_app, mock_db_student):
        mock_order_result = {**SAMPLE_ORDER, "id": "new-order-id"}
        with patch("app.db.get_db", return_value=mock_db_student), \
             patch("fastapi_app.deps.get_db", return_value=mock_db_student), \
             patch("app.services.order_service.create_order", return_value=mock_order_result):
            with TestClient(fastapi_app) as c:
                resp = c.post(
                    "/api/orders",
                    json=VALID_ORDER_BODY,
                    headers={"Authorization": f"Bearer {student_token()}"},
                )
                assert resp.status_code == 201

    def test_guest_order_requires_name_and_phone(self, fastapi_app, mock_db_student):
        with patch("app.db.get_db", return_value=mock_db_student), \
             patch("fastapi_app.deps.get_db", return_value=mock_db_student):
            with TestClient(fastapi_app) as c:
                body = {**VALID_ORDER_BODY, "payment_method": "card"}
                resp = c.post("/api/orders", json=body)
                assert resp.status_code == 400
                assert "guest_name" in resp.json()["detail"].lower() or "guest" in resp.json()["detail"].lower()

    def test_guest_cannot_use_wallet(self, fastapi_app, mock_db_student):
        with patch("app.db.get_db", return_value=mock_db_student), \
             patch("fastapi_app.deps.get_db", return_value=mock_db_student):
            with TestClient(fastapi_app) as c:
                body = {**VALID_ORDER_BODY, "payment_method": "wallet", "guest_name": "John", "guest_phone": "08012345678"}
                resp = c.post("/api/orders", json=body)
                assert resp.status_code == 400

    def test_invalid_payment_method_rejected(self, client, auth_headers):
        body = {**VALID_ORDER_BODY, "payment_method": "crypto"}
        resp = client.post("/api/orders", json=body, headers=auth_headers)
        assert resp.status_code == 422

    def test_empty_items_rejected(self, client, auth_headers):
        body = {**VALID_ORDER_BODY, "items": []}
        resp = client.post("/api/orders", json=body, headers=auth_headers)
        assert resp.status_code == 422

    def test_order_with_addons(self, fastapi_app, mock_db_student):
        mock_order_result = {**SAMPLE_ORDER, "id": "addon-order-id"}
        with patch("app.db.get_db", return_value=mock_db_student), \
             patch("fastapi_app.deps.get_db", return_value=mock_db_student), \
             patch("app.services.order_service.create_order", return_value=mock_order_result):
            with TestClient(fastapi_app) as c:
                body = {**VALID_ORDER_BODY, "addons": [{"addon_id": ADDON_ID, "quantity": 2}]}
                resp = c.post(
                    "/api/orders", json=body,
                    headers={"Authorization": f"Bearer {student_token()}"},
                )
                assert resp.status_code == 201


# ── GET /api/orders ────────────────────────────────────────────────────────

class TestListOrders:
    def test_requires_auth(self, client):
        resp = client.get("/api/orders")
        assert resp.status_code == 401

    def test_returns_list(self, client, auth_headers):
        resp = client.get("/api/orders", headers=auth_headers)
        assert resp.status_code == 200
        assert isinstance(resp.json(), list)

    def test_pagination_params(self, client, auth_headers):
        resp = client.get("/api/orders?limit=5&offset=0", headers=auth_headers)
        assert resp.status_code == 200


# ── GET /api/orders/{id} ──────────────────────────────────────────────────

class TestGetOrder:
    def test_owner_can_get_order(self, client, auth_headers):
        resp = client.get(f"/api/orders/{ORDER_ID}", headers=auth_headers)
        assert resp.status_code == 200
        assert resp.json()["id"] == ORDER_ID

    def test_includes_items(self, client, auth_headers):
        resp = client.get(f"/api/orders/{ORDER_ID}", headers=auth_headers)
        assert "items" in resp.json()

    def test_requires_auth(self, client):
        resp = client.get(f"/api/orders/{ORDER_ID}")
        assert resp.status_code == 401


# ── POST /api/orders/{id}/review ──────────────────────────────────────────

class TestSubmitReview:
    def test_review_requires_delivered_status(self, fastapi_app, mock_db_student):
        db = make_mock_db({
            "profiles": [SAMPLE_PROFILE],
            "orders": [{**SAMPLE_ORDER, "status": "confirmed", "review_submitted": False}],
            "order_items": [],
        })
        with patch("app.db.get_db", return_value=db), \
             patch("fastapi_app.deps.get_db", return_value=db):
            with TestClient(fastapi_app) as c:
                resp = c.post(
                    f"/api/orders/{ORDER_ID}/review",
                    json={"rating": 5, "comment": "Great!"},
                    headers={"Authorization": f"Bearer {student_token()}"},
                )
                assert resp.status_code == 400

    def test_rating_must_be_1_to_5(self, client, auth_headers):
        resp = client.post(f"/api/orders/{ORDER_ID}/review", json={"rating": 6}, headers=auth_headers)
        assert resp.status_code == 422
