"""FastAPI menu endpoint tests."""

import pytest
from unittest.mock import patch, MagicMock
from fastapi.testclient import TestClient

from fastapi_app.tests.conftest import (
    MENU_ITEM_ID, SAMPLE_MENU_ITEM, ADMIN_PROFILE, SAMPLE_ADDON, make_mock_db,
    admin_token, student_token,
)


# ── GET /api/menu/categories ───────────────────────────────────────────────

class TestListCategories:
    def test_returns_list(self, client):
        resp = client.get("/api/menu/categories")
        assert resp.status_code == 200
        assert isinstance(resp.json(), list)

    def test_no_auth_required(self, client):
        resp = client.get("/api/menu/categories")
        assert resp.status_code == 200


# ── GET /api/menu/items ────────────────────────────────────────────────────

class TestListItems:
    def test_returns_items_and_kitchen_block(self, client):
        resp = client.get("/api/menu/items")
        assert resp.status_code == 200
        body = resp.json()
        assert "items" in body
        assert "kitchen" in body

    def test_each_item_has_sold_out_field(self, client):
        resp = client.get("/api/menu/items")
        body = resp.json()
        for item in body["items"]:
            assert "is_sold_out" in item

    def test_no_auth_required(self, client):
        resp = client.get("/api/menu/items")
        assert resp.status_code == 200


# ── GET /api/menu/items/{id} ───────────────────────────────────────────────

class TestGetItem:
    def test_returns_item_with_variation_groups(self, client):
        resp = client.get(f"/api/menu/items/{MENU_ITEM_ID}")
        assert resp.status_code == 200
        body = resp.json()
        assert body["id"] == MENU_ITEM_ID
        assert "variation_groups" in body

    def test_404_on_missing_item(self, fastapi_app, mock_db_student):
        mock_db_student._data = {}
        db = make_mock_db({"menu_items": [], "kitchen_settings": [], "orders": [], "order_items": [], "menu_item_variation_groups": []})
        with patch("app.db.get_db", return_value=db), \
             patch("fastapi_app.deps.get_db", return_value=db):
            with TestClient(fastapi_app) as c:
                resp = c.get("/api/menu/items/nonexistent-id")
                assert resp.status_code == 404


# ── GET /api/menu/addons ───────────────────────────────────────────────────

class TestListAddons:
    def test_returns_addons(self, client):
        resp = client.get("/api/menu/addons")
        assert resp.status_code == 200
        assert isinstance(resp.json(), list)

    def test_no_auth_required(self, client):
        resp = client.get("/api/menu/addons")
        assert resp.status_code == 200


# ── POST /api/menu/addons (admin) ──────────────────────────────────────────

class TestCreateAddon:
    def test_admin_can_create_addon(self, fastapi_app, mock_db_admin):
        with patch("app.db.get_db", return_value=mock_db_admin), \
             patch("fastapi_app.deps.get_db", return_value=mock_db_admin):
            with TestClient(fastapi_app) as c:
                resp = c.post(
                    "/api/menu/addons",
                    json={"name": "Bottled Water", "price": 200.0},
                    headers={"Authorization": f"Bearer {admin_token()}"},
                )
                assert resp.status_code in (200, 201)

    def test_student_cannot_create_addon(self, client, auth_headers):
        resp = client.post("/api/menu/addons", json={"name": "X", "price": 100}, headers=auth_headers)
        assert resp.status_code == 403


# ── GET /api/menu/kitchen-capacity ────────────────────────────────────────

class TestKitchenCapacity:
    def test_returns_capacity_fields(self, client):
        resp = client.get("/api/menu/kitchen-capacity")
        assert resp.status_code == 200
        body = resp.json()
        assert "daily_order_capacity" in body
        assert "orders_today" in body
        assert "is_at_capacity" in body


# ── Variation groups ───────────────────────────────────────────────────────

class TestVariationGroups:
    def test_admin_can_create_variation_group(self, fastapi_app, mock_db_admin):
        with patch("app.db.get_db", return_value=mock_db_admin), \
             patch("fastapi_app.deps.get_db", return_value=mock_db_admin):
            with TestClient(fastapi_app) as c:
                resp = c.post(
                    f"/api/menu/items/{MENU_ITEM_ID}/variation-groups",
                    json={"name": "Choose your side", "is_required": True, "max_selections": 1},
                    headers={"Authorization": f"Bearer {admin_token()}"},
                )
                assert resp.status_code in (200, 201)

    def test_student_cannot_create_variation_group(self, client, auth_headers):
        resp = client.post(
            f"/api/menu/items/{MENU_ITEM_ID}/variation-groups",
            json={"name": "Sides", "is_required": False, "max_selections": 1},
            headers=auth_headers,
        )
        assert resp.status_code == 403
