"""FastAPI HP endpoint tests."""

import pytest
from unittest.mock import patch
from fastapi.testclient import TestClient

from fastapi_app.tests.conftest import (
    STUDENT_ID, ADMIN_ID, SAMPLE_PROFILE, ADMIN_PROFILE, make_mock_db,
    student_token, admin_token,
)

MOCK_BALANCE = {"active": 500, "pending": 100, "overflow": 0, "total_visible": 600, "monthly_hp_earned": 200, "hp_earned_120day": 800}
MOCK_TIER    = {"tier": {"name": "Ember", "slug": "ember", "badge_color_hex": "#ccc"}, "is_in_grace_period": False}

# Patch targets: service functions must be patched at the ROUTER import site
# (router does `from app.services.hp_service import X`, creating a local closure)
_HP_BALANCE = "fastapi_app.routers.hp.get_hp_balance"
_USER_TIER  = "fastapi_app.routers.hp.get_user_tier"
_AWARD_HP   = "fastapi_app.routers.hp.award_active_hp"


class TestHPBalance:
    def test_requires_auth(self, client):
        resp = client.get("/api/hp/balance")
        assert resp.status_code == 401

    def test_returns_balance_and_tier(self, client, auth_headers):
        with patch(_HP_BALANCE, return_value=MOCK_BALANCE), \
             patch(_USER_TIER,  return_value=MOCK_TIER):
            resp = client.get("/api/hp/balance", headers=auth_headers)
        assert resp.status_code == 200
        body = resp.json()
        assert "active" in body
        assert "pending" in body
        assert "tier" in body

    def test_balance_fields_present(self, client, auth_headers):
        with patch(_HP_BALANCE, return_value=MOCK_BALANCE), \
             patch(_USER_TIER,  return_value=MOCK_TIER):
            resp = client.get("/api/hp/balance", headers=auth_headers)
        body = resp.json()
        for field in ("active", "pending", "overflow", "total_visible"):
            assert field in body


class TestHPTransactions:
    def test_requires_auth(self, client):
        resp = client.get("/api/hp/transactions")
        assert resp.status_code == 401

    def test_returns_list(self, client, auth_headers):
        resp = client.get("/api/hp/transactions", headers=auth_headers)
        assert resp.status_code == 200
        assert isinstance(resp.json(), list)

    def test_pagination(self, client, auth_headers):
        resp = client.get("/api/hp/transactions?limit=10&offset=0", headers=auth_headers)
        assert resp.status_code == 200

    def test_type_filter(self, client, auth_headers):
        resp = client.get("/api/hp/transactions?type=earn", headers=auth_headers)
        assert resp.status_code == 200


class TestListTiers:
    def test_no_auth_required(self, client):
        resp = client.get("/api/hp/tiers")
        assert resp.status_code == 200

    def test_returns_list(self, client):
        resp = client.get("/api/hp/tiers")
        assert isinstance(resp.json(), list)


class TestAdminGrantHP:
    def test_admin_can_grant_hp(self, fastapi_app, mock_db_admin):
        with patch("app.db.get_db", return_value=mock_db_admin), \
             patch(_AWARD_HP, return_value={"id": "tx-1", "amount": 100}):
            with TestClient(fastapi_app) as c:
                resp = c.post(
                    "/api/hp/admin/grant",
                    json={"user_id": STUDENT_ID, "amount": 100, "reason": "test grant"},
                    headers={"Authorization": f"Bearer {admin_token()}"},
                )
                assert resp.status_code == 200

    def test_student_cannot_grant_hp(self, client, auth_headers):
        resp = client.post("/api/hp/admin/grant", json={"user_id": STUDENT_ID, "amount": 50}, headers=auth_headers)
        assert resp.status_code == 403

    def test_amount_must_be_positive(self, fastapi_app, mock_db_admin):
        with patch("app.db.get_db", return_value=mock_db_admin):
            with TestClient(fastapi_app) as c:
                resp = c.post(
                    "/api/hp/admin/grant",
                    json={"user_id": STUDENT_ID, "amount": 0},
                    headers={"Authorization": f"Bearer {admin_token()}"},
                )
                assert resp.status_code == 422
