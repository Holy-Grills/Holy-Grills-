"""FastAPI auth endpoint tests."""

import pytest
from unittest.mock import patch, MagicMock

from fastapi_app.tests.conftest import SAMPLE_PROFILE, STUDENT_ID, student_token, make_mock_db


REGISTER_BODY = {
    "email":     "newuser@test.com",
    "password":  "password123",
    "full_name": "New User",
}

LOGIN_BODY = {
    "email":    "student@test.com",
    "password": "password123",
}

MOCK_SESSION = {
    "access_token":  "mock.jwt.token",
    "refresh_token": "mock.refresh.token",
    "expires_in":    3600,
    "user":          {"id": STUDENT_ID, "email": "student@test.com"},
}


# ── POST /api/auth/register ────────────────────────────────────────────────

class TestRegister:
    def test_successful_registration(self, client):
        with patch("app.services.auth_service.register", return_value=MOCK_SESSION):
            resp = client.post("/api/auth/register", json=REGISTER_BODY)
        assert resp.status_code == 201

    def test_password_too_short_rejected(self, client):
        body = {**REGISTER_BODY, "password": "short"}
        resp = client.post("/api/auth/register", json=body)
        assert resp.status_code == 422

    def test_missing_email_rejected(self, client):
        body = {k: v for k, v in REGISTER_BODY.items() if k != "email"}
        resp = client.post("/api/auth/register", json=body)
        assert resp.status_code == 422

    def test_missing_full_name_rejected(self, client):
        body = {k: v for k, v in REGISTER_BODY.items() if k != "full_name"}
        resp = client.post("/api/auth/register", json=body)
        assert resp.status_code == 422

    def test_duplicate_email_returns_400(self, client):
        with patch("app.services.auth_service.register", side_effect=ValueError("Email already registered")):
            resp = client.post("/api/auth/register", json=REGISTER_BODY)
        assert resp.status_code == 400

    def test_referred_by_code_accepted(self, client):
        with patch("app.services.auth_service.register", return_value=MOCK_SESSION):
            body = {**REGISTER_BODY, "referred_by_code": "HG-FRIEND01"}
            resp = client.post("/api/auth/register", json=body)
        assert resp.status_code == 201


# ── POST /api/auth/login ───────────────────────────────────────────────────

class TestLogin:
    def test_successful_login(self, client):
        with patch("app.services.auth_service.login", return_value=MOCK_SESSION):
            resp = client.post("/api/auth/login", json=LOGIN_BODY)
        assert resp.status_code == 200

    def test_wrong_password_returns_401(self, client):
        with patch("app.services.auth_service.login", side_effect=ValueError("Invalid credentials")):
            resp = client.post("/api/auth/login", json=LOGIN_BODY)
        assert resp.status_code == 401

    def test_missing_email_rejected(self, client):
        resp = client.post("/api/auth/login", json={"password": "pass"})
        assert resp.status_code == 422


# ── GET /api/auth/profile ─────────────────────────────────────────────────

class TestProfile:
    def test_requires_auth(self, client):
        resp = client.get("/api/auth/profile")
        assert resp.status_code == 401

    def test_returns_profile(self, client, auth_headers):
        resp = client.get("/api/auth/profile", headers=auth_headers)
        assert resp.status_code == 200
        body = resp.json()
        assert body["id"] == STUDENT_ID

    def test_profile_has_expected_fields(self, client, auth_headers):
        resp = client.get("/api/auth/profile", headers=auth_headers)
        body = resp.json()
        for field in ("id", "email", "full_name", "role"):
            assert field in body


# ── PATCH /api/auth/profile ────────────────────────────────────────────────

class TestUpdateProfile:
    def test_can_update_name(self, client, auth_headers):
        resp = client.patch("/api/auth/profile", json={"full_name": "Updated Name"}, headers=auth_headers)
        assert resp.status_code == 200

    def test_empty_update_returns_400(self, client, auth_headers):
        resp = client.patch("/api/auth/profile", json={}, headers=auth_headers)
        assert resp.status_code == 400

    def test_requires_auth(self, client):
        resp = client.patch("/api/auth/profile", json={"full_name": "X"})
        assert resp.status_code == 401
