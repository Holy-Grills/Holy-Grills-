"""
FastAPI entry point.

Run:
    uvicorn fastapi_app.run:app --host 0.0.0.0 --port 8000 --reload

Swagger UI:  http://localhost:8000/api/docs
ReDoc:       http://localhost:8000/api/redoc
OpenAPI JSON: http://localhost:8000/api/openapi.json
"""

from fastapi_app.main import app  # noqa: F401 — imported so uvicorn can find it

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("fastapi_app.run:app", host="0.0.0.0", port=8000, reload=True)
