"""
Phase D: Tier System Tests (28 tests)
D1: Tier Threshold Accuracy
D2: Tier Promotion/Demotion
D3: Tier Bonus Application
D4: Tier Perks Access (policy-level)
"""

import pytest
from unittest.mock import patch
from tests.conftest import (
    make_mock_db, STUDENT_ID, ORDER_ID, SAMPLE_TIERS, SAMPLE_PROFILE,
    TIER_EMBER, TIER_FLAME, TIER_BLAZE, TIER_HOLY
)


@pytest.fixture(autouse=True)
def flask_ctx(app):
    with app.app_context():
        yield


# ── D1: Tier Threshold Accuracy ───────────────────────────────────────────────

class TestD1TierThresholdAccuracy:
    def _tier_at(self, hp_earned_120day):
        profile = {**SAMPLE_PROFILE, "hp_earned_120day": hp_earned_120day}
        db = make_mock_db({"profiles": profile, "tiers": SAMPLE_TIERS, "user_tiers": []})
        with patch("app.services.hp_service.get_db", return_value=db), \
             patch("app.services.hp_service._safe_update_profile"):
            from app.services.hp_service import recalculate_tier
            return recalculate_tier(STUDENT_ID)

    def test_ember_at_zero_hp(self, app):
        """D1-1: Ember tier at 0 HP earned."""
        result = self._tier_at(0)
        assert result["tier"]["slug"] == "ember"

    def test_flame_at_2500_hp(self, app):
        """D1-2: Flame tier at exactly 2,500 HP."""
        result = self._tier_at(2500)
        assert result["tier"]["slug"] == "flame"

    def test_flame_at_2501_hp(self, app):
        """D1-2b: Flame tier at 2,501 HP."""
        result = self._tier_at(2501)
        assert result["tier"]["slug"] == "flame"

    def test_blaze_at_7500_hp(self, app):
        """D1-3: Blaze tier at exactly 7,500 HP."""
        result = self._tier_at(7500)
        assert result["tier"]["slug"] == "blaze"

    def test_holy_at_20000_hp(self, app):
        """D1-4: Holy tier at exactly 20,000 HP."""
        result = self._tier_at(20000)
        assert result["tier"]["slug"] == "holy"

    def test_tier_based_on_earned_not_balance(self, app):
        """D1-5: Tier uses hp_earned_120day, not current active balance."""
        # Even if user spent HP (low balance), tier is based on earned
        profile = {**SAMPLE_PROFILE, "hp_earned_120day": 5000}
        db = make_mock_db({"profiles": profile, "tiers": SAMPLE_TIERS, "user_tiers": []})
        with patch("app.services.hp_service.get_db", return_value=db), \
             patch("app.services.hp_service._safe_update_profile"):
            from app.services.hp_service import recalculate_tier
            result = recalculate_tier(STUDENT_ID)

        assert result["tier"]["slug"] == "flame"

    def test_tier_thresholds_config_correct(self, app):
        """D1-6: Tier threshold config values match Master Brand Document."""
        from flask import current_app
        thresholds = current_app.config["TIER_THRESHOLDS"]
        assert thresholds["ember"] == 0
        assert thresholds["flame"] == 2500
        assert thresholds["blaze"] == 7500
        assert thresholds["holy"] == 20000

    def test_tier_multipliers_config_correct(self, app):
        """D1-7: Tier multiplier config values match Master Brand Document."""
        from flask import current_app
        mults = current_app.config["TIER_MULTIPLIERS"]
        assert mults["ember"] == 1.00
        assert mults["flame"] == 1.08
        assert mults["blaze"] == 1.15
        assert mults["holy"] == 1.25


# ── D2: Tier Promotion/Demotion ───────────────────────────────────────────────

class TestD2TierPromotionDemotion:
    def test_immediate_promotion_on_threshold_cross(self, app):
        """D2-1: Immediate promotion when 120-day earned HP crosses threshold."""
        profile = {**SAMPLE_PROFILE, "hp_earned_120day": 2501}
        db = make_mock_db({"profiles": profile, "tiers": SAMPLE_TIERS,
                           "user_tiers": [{"id": "x", "tier_id": TIER_EMBER, "is_current": True}]})

        with patch("app.services.hp_service.get_db", return_value=db), \
             patch("app.services.hp_service._safe_update_profile"):
            from app.services.hp_service import recalculate_tier
            result = recalculate_tier(STUDENT_ID)

        assert result["changed"] is True
        assert result["tier"]["slug"] == "flame"

    def test_grace_period_flag_readable(self, app):
        """D2-2: Grace period flag is_in_grace_period readable from user_tier."""
        user_tier = {"tier_id": TIER_FLAME, "is_current": True,
                     "is_in_grace_period": True,
                     "grace_period_ends_at": "2026-06-01T00:00:00Z",
                     "achieved_at": "2026-01-01T00:00:00Z"}
        db = make_mock_db({"user_tiers": [user_tier], "tiers": SAMPLE_TIERS})

        with patch("app.services.hp_service.get_db", return_value=db):
            from app.services.hp_service import get_user_tier
            result = get_user_tier(STUDENT_ID)

        assert result["is_in_grace_period"] is True
        assert result["grace_period_ends_at"] is not None

    def test_grace_period_config_7_days(self, app):
        """D2-3: Grace period is 7 days as per config."""
        from flask import current_app
        assert current_app.config["TIER_GRACE_PERIOD_DAYS"] == 7

    def test_no_change_when_tier_matches(self, app):
        """D2-5: No tier change if already on correct tier."""
        profile = {**SAMPLE_PROFILE, "hp_earned_120day": 2600}
        db = make_mock_db({"profiles": profile, "tiers": SAMPLE_TIERS,
                           "user_tiers": [{"id": "x", "tier_id": TIER_FLAME, "is_current": True}]})

        with patch("app.services.hp_service.get_db", return_value=db), \
             patch("app.services.hp_service._safe_update_profile"):
            from app.services.hp_service import recalculate_tier
            result = recalculate_tier(STUDENT_ID)

        assert result["changed"] is False

    def test_demotion_holy_to_blaze(self, app):
        """D2-7: Holy → Blaze demotion when 120-day drops below 20000."""
        profile = {**SAMPLE_PROFILE, "hp_earned_120day": 8000}  # dropped from Holy
        db = make_mock_db({"profiles": profile, "tiers": SAMPLE_TIERS,
                           "user_tiers": [{"id": "x", "tier_id": TIER_HOLY, "is_current": True}]})

        with patch("app.services.hp_service.get_db", return_value=db), \
             patch("app.services.hp_service._safe_update_profile"):
            from app.services.hp_service import recalculate_tier
            result = recalculate_tier(STUDENT_ID)

        assert result["changed"] is True
        assert result["tier"]["slug"] == "blaze"

    def test_demotion_flame_to_ember(self, app):
        """D2-7b: Flame → Ember demotion when 120-day drops below 2500."""
        profile = {**SAMPLE_PROFILE, "hp_earned_120day": 500}
        db = make_mock_db({"profiles": profile, "tiers": SAMPLE_TIERS,
                           "user_tiers": [{"id": "x", "tier_id": TIER_FLAME, "is_current": True}]})

        with patch("app.services.hp_service.get_db", return_value=db), \
             patch("app.services.hp_service._safe_update_profile"):
            from app.services.hp_service import recalculate_tier
            result = recalculate_tier(STUDENT_ID)

        assert result["changed"] is True
        assert result["tier"]["slug"] == "ember"

    def test_tier_change_updates_multiplier_profile(self, app):
        """D2-4: Promotion updates tier_bonus_multiplier in profile."""
        updates = {}

        def capture(user_id, data):
            updates.update(data)

        profile = {**SAMPLE_PROFILE, "hp_earned_120day": 2600}
        db = make_mock_db({"profiles": profile, "tiers": SAMPLE_TIERS,
                           "user_tiers": [{"id": "x", "tier_id": TIER_EMBER, "is_current": True}]})

        with patch("app.services.hp_service.get_db", return_value=db), \
             patch("app.services.hp_service._safe_update_profile", side_effect=capture):
            from app.services.hp_service import recalculate_tier
            recalculate_tier(STUDENT_ID)

        assert "tier_bonus_multiplier" in updates
        assert updates["tier_bonus_multiplier"] == 1.08


# ── D3: Tier Bonus Application ────────────────────────────────────────────────

class TestD3TierBonusApplication:
    def _award(self, total, tier):
        with patch("app.services.hp_service.get_db", return_value=make_mock_db()), \
             patch("app.services.hp_service.unlock_pending_hp", return_value={"unlocked": 0}), \
             patch("app.services.hp_service._update_earned_counters"), \
             patch("app.services.hp_service._record_hp_transaction"):
            from app.services.hp_service import award_food_order_hp
            return award_food_order_hp(STUDENT_ID, ORDER_ID, total, tier)

    def test_flame_8_percent_bonus(self, app):
        """D3-1: Flame adds +8% bonus on all food order HP."""
        result = self._award(1000.0, "flame")
        assert result["tier_bonus_hp"] == 8
        assert result["total_hp"] == 108

    def test_blaze_15_percent_bonus(self, app):
        """D3-2: Blaze adds +15% bonus on all food order HP."""
        result = self._award(1000.0, "blaze")
        assert result["tier_bonus_hp"] == 15
        assert result["total_hp"] == 115

    def test_holy_25_percent_bonus(self, app):
        """D3-3: Holy adds +25% bonus on all food order HP."""
        result = self._award(1000.0, "holy")
        assert result["tier_bonus_hp"] == 25
        assert result["total_hp"] == 125

    def test_bonus_on_base_hp_not_activity(self, app):
        """D3-4: Bonus applies to base order HP only — activity HP unchanged."""
        result = self._award(2000.0, "holy")
        assert result["base_hp"] == 200
        assert result["tier_bonus_hp"] == round(200 * 0.25)

    def test_bonus_not_applied_to_referral(self, app):
        """D3-5: Tier bonus NOT applied to referral HP earn."""
        amounts = []

        def capture(user_id, amount, source_type, **kwargs):
            amounts.append(amount)
            return {"added_to_pending": amount, "added_to_overflow": 0, "ceiling_applied": 350, "source_type": source_type}

        profile = {**SAMPLE_PROFILE, "pending_hp_balance": 0, "hp_overflow": 0,
                   "tier_bonus_multiplier": 1.25}  # Holy tier multiplier
        with patch("app.services.hp_service.get_db", return_value=make_mock_db({"profiles": profile})), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 1000, "pending": 0, "overflow": 0}), \
             patch("app.services.hp_service._record_hp_transaction"), \
             patch("app.services.hp_service._safe_update_profile"), \
             patch("app.services.hp_service._get_profile_hp_fields", return_value=profile):
            from app.services.hp_service import earn_pending_hp
            result = earn_pending_hp(STUDENT_ID, 75, "referral")

        # 75 HP exactly — no multiplier applied
        assert result["added_to_pending"] + result["added_to_overflow"] == 75

    def test_bonus_applied_even_on_zero_total_order(self, app):
        """D3-6: Tier bonus applies even if order total is very small."""
        result = self._award(100.0, "flame")  # small but non-zero order
        assert result["base_hp"] == 10
        assert result["tier_bonus_hp"] == round(10 * 0.08)

    def test_ember_zero_bonus(self, app):
        """D3-extra: Ember tier has exactly 0 bonus."""
        result = self._award(5000.0, "ember")
        assert result["tier_bonus_hp"] == 0
        assert result["total_hp"] == result["base_hp"]


# ── D4: Tier Perks Access (policy tests) ──────────────────────────────────────

class TestD4TierPerksAccess:
    def test_tier_slugs_defined(self, app):
        """D4-1: All four tier slugs defined in SAMPLE_TIERS."""
        slugs = [t["slug"] for t in SAMPLE_TIERS]
        assert "ember" in slugs
        assert "flame" in slugs
        assert "blaze" in slugs
        assert "holy" in slugs

    def test_tier_sort_order_ascending(self, app):
        """D4-2: Tiers have ascending sort_order (ember=1, holy=4)."""
        ember = next(t for t in SAMPLE_TIERS if t["slug"] == "ember")
        holy = next(t for t in SAMPLE_TIERS if t["slug"] == "holy")
        assert ember["sort_order"] < holy["sort_order"]

    def test_all_tiers_have_multiplier(self, app):
        """D4-3: All tiers have earn_multiplier defined."""
        for tier in SAMPLE_TIERS:
            assert "earn_multiplier" in tier
            assert tier["earn_multiplier"] >= 1.0

    def test_flame_multiplier_1_08(self, app):
        """D4-4: Flame tier multiplier is exactly 1.08."""
        flame = next(t for t in SAMPLE_TIERS if t["slug"] == "flame")
        assert flame["earn_multiplier"] == 1.08

    def test_blaze_multiplier_1_15(self, app):
        """D4-5: Blaze tier multiplier is exactly 1.15."""
        blaze = next(t for t in SAMPLE_TIERS if t["slug"] == "blaze")
        assert blaze["earn_multiplier"] == 1.15

    def test_holy_multiplier_1_25(self, app):
        """D4-6: Holy tier multiplier is exactly 1.25."""
        holy = next(t for t in SAMPLE_TIERS if t["slug"] == "holy")
        assert holy["earn_multiplier"] == 1.25

    def test_user_tier_returned_with_is_current(self, app):
        """D4-7: get_user_tier returns is_in_grace_period field."""
        db = make_mock_db({
            "user_tiers": [{"tier_id": TIER_HOLY, "is_current": True,
                            "is_in_grace_period": False, "achieved_at": "2026-01-01T00:00:00Z"}],
            "tiers": SAMPLE_TIERS,
        })
        with patch("app.services.hp_service.get_db", return_value=db):
            from app.services.hp_service import get_user_tier
            result = get_user_tier(STUDENT_ID)

        assert result["tier"]["slug"] == "holy"
        assert result["is_in_grace_period"] is False

    def test_no_tier_falls_back_to_ember(self, app):
        """D4-8: User with no tier record falls back to base (Ember) tier."""
        db = make_mock_db({
            "user_tiers": [],
            "tiers": SAMPLE_TIERS,
        })
        with patch("app.services.hp_service.get_db", return_value=db):
            from app.services.hp_service import get_user_tier
            result = get_user_tier(STUDENT_ID)

        # Falls back to first tier by sort_order
        assert result["tier"] is not None
