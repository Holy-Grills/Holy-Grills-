"""
Phase J: End-to-End User Scenario Tests (20 tests)
J1: New Student Onboarding
J2: Path to Flame Tier
J3: Pending Pool Lifecycle
J4: Reward Redemption Journey
J5: Monthly Leaderboard Competition
J6: Flash Redemption FOMO
J7: Event HP Bundle
"""

import math
import pytest
from unittest.mock import patch, MagicMock, call
from datetime import datetime, timezone
from tests.conftest import (
    make_mock_db, STUDENT_ID, ORDER_ID, SAMPLE_PROFILE, SAMPLE_HP_TXN,
    SAMPLE_ORDER, SAMPLE_DELIVERED_ORDER, SAMPLE_TIERS, SAMPLE_REWARD, REWARD_ID,
    MENU_ITEM_ID, WINDOW_ID, SAMPLE_MENU_ITEM, SAMPLE_WINDOW,
    TIER_EMBER, TIER_FLAME, TIER_BLAZE, TIER_HOLY
)


@pytest.fixture(autouse=True)
def flask_ctx(app):
    with app.app_context():
        yield


# ── J1: New Student Onboarding ────────────────────────────────────────────────

class TestJ1NewStudentOnboarding:
    def test_new_student_starts_with_zero_hp(self, app):
        """J1-1: Student signs up → 0 HP active, 0 HP pending."""
        db = make_mock_db({
            "hp_transactions": [],
            "profiles": {**SAMPLE_PROFILE, "pending_hp_balance": 0, "hp_overflow": 0},
        })
        db.rpc.side_effect = Exception("fallback")

        with patch("app.services.hp_service.get_db", return_value=db):
            from app.services.hp_service import get_hp_balance
            result = get_hp_balance(STUDENT_ID)

        assert result["active"] == 0
        assert result["pending"] == 0
        assert result["overflow"] == 0

    def test_first_order_3500_earns_350_plus_welcome(self, app):
        """J1-2: First ₦3,500 order → 350 active + 50 welcome = 400 active."""
        earned = []

        def capture_active(user_id, amount, **kwargs):
            earned.append(amount)
            return {"awarded": amount}

        db = make_mock_db({"hp_transactions": []})  # no prior transactions

        with patch("app.services.hp_service.get_db", return_value=db), \
             patch("app.services.hp_service.unlock_pending_hp", return_value={"unlocked": 0}), \
             patch("app.services.hp_service._update_earned_counters"), \
             patch("app.services.hp_service._record_hp_transaction"), \
             patch("app.services.hp_service.award_active_hp", side_effect=capture_active):
            from app.services.hp_service import award_food_order_hp
            food_result = award_food_order_hp(STUDENT_ID, ORDER_ID, 3500.0, "ember")

        assert food_result["base_hp"] == 350
        assert food_result["tier_bonus_hp"] == 0

    def test_first_order_welcome_bonus_50hp(self, app):
        """J1-2b: Welcome bonus is 50 HP on first order."""
        db = make_mock_db({"hp_transactions": []})
        awarded = []

        with patch("app.services.hp_service.get_db", return_value=db), \
             patch("app.services.hp_service._update_earned_counters"), \
             patch("app.services.hp_service._record_hp_transaction"):
            from app.services.hp_service import award_welcome_bonus
            result = award_welcome_bonus(STUDENT_ID, ORDER_ID)

        assert result["awarded"] == 50

    def test_referral_earns_75_pending(self, app):
        """J1-3: Referral → +75 pending HP."""
        profile = {**SAMPLE_PROFILE, "pending_hp_balance": 0, "hp_overflow": 0}
        with patch("app.services.hp_service.get_db", return_value=make_mock_db({"profiles": profile})), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 400, "pending": 0, "overflow": 0}), \
             patch("app.services.hp_service._record_hp_transaction"), \
             patch("app.services.hp_service._safe_update_profile"), \
             patch("app.services.hp_service._get_profile_hp_fields", return_value=profile):
            from app.services.hp_service import earn_pending_hp
            result = earn_pending_hp(STUDENT_ID, 75, "referral", "ref-001")

        assert result["added_to_pending"] + result["added_to_overflow"] == 75


# ── J2: Path to Flame Tier ────────────────────────────────────────────────────

class TestJ2PathToFlameTier:
    def test_7_orders_at_3500_equals_2450_hp(self, app):
        """J2-1: 7 orders × ₦3,500 = ₦24,500 → 2,450 HP base (just under Flame)."""
        orders = 7
        total_spend = orders * 3500.0
        hp_earned = int(total_spend * 0.1)
        assert hp_earned == 2450

    def test_8_orders_at_3500_crosses_flame_threshold(self, app):
        """J2-1b: 8 orders × ₦3,500 → 2,800 HP > 2,500 Flame threshold."""
        orders = 8
        total_spend = orders * 3500.0
        hp_earned = int(total_spend * 0.1)
        assert hp_earned > 2500

    def test_promotion_to_flame_at_threshold(self, app):
        """J2-2: Tier promotion to Flame triggers immediately."""
        profile = {**SAMPLE_PROFILE, "hp_earned_120day": 2600}
        db = make_mock_db({"profiles": profile, "tiers": SAMPLE_TIERS,
                           "user_tiers": [{"id": "x", "tier_id": TIER_EMBER, "is_current": True}]})

        with patch("app.services.hp_service.get_db", return_value=db), \
             patch("app.services.hp_service._safe_update_profile"):
            from app.services.hp_service import recalculate_tier
            result = recalculate_tier(STUDENT_ID)

        assert result["changed"] is True
        assert result["tier"]["slug"] == "flame"

    def test_next_order_after_flame_gets_8_percent_bonus(self, app):
        """J2-3: Next order after Flame promotion gets +8% bonus."""
        with patch("app.services.hp_service.get_db", return_value=make_mock_db()), \
             patch("app.services.hp_service.unlock_pending_hp", return_value={"unlocked": 0}), \
             patch("app.services.hp_service._update_earned_counters"), \
             patch("app.services.hp_service._record_hp_transaction"):
            from app.services.hp_service import award_food_order_hp
            result = award_food_order_hp(STUDENT_ID, ORDER_ID, 1000.0, "flame")

        assert result["tier_bonus_hp"] == 8
        assert result["total_hp"] == 108


# ── J3: Pending Pool Lifecycle ────────────────────────────────────────────────

class TestJ3PendingPoolLifecycle:
    def test_pending_builds_to_35_percent_ceiling(self, app):
        """J3-1: Activities build pending to 35% ceiling of active."""
        # With 400 active HP, ceiling = max(140, 200) = 200 HP
        active = 400
        ceiling = max(int(active * 0.35), 200)
        assert ceiling == 200  # floor applies

    def test_excess_goes_to_overflow(self, app):
        """J3-2: Pending at ceiling → next HP goes to overflow vault."""
        profile = {**SAMPLE_PROFILE, "pending_hp_balance": 200, "hp_overflow": 0}
        with patch("app.services.hp_service.get_db", return_value=make_mock_db({"profiles": profile})), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 400, "pending": 200, "overflow": 0}), \
             patch("app.services.hp_service._record_hp_transaction"), \
             patch("app.services.hp_service._safe_update_profile"), \
             patch("app.services.hp_service._get_profile_hp_fields", return_value=profile):
            from app.services.hp_service import earn_pending_hp
            result = earn_pending_hp(STUDENT_ID, 40, "event")

        assert result["added_to_overflow"] == 40
        assert result["added_to_pending"] == 0

    def test_food_order_unlocks_pending(self, app):
        """J3-3: Food order ≥₦1,000 unlocks 100 HP per ₦1,000 from pending."""
        profile = {**SAMPLE_PROFILE, "pending_hp_balance": 200, "hp_overflow": 100}
        with patch("app.services.hp_service.get_db", return_value=make_mock_db({"profiles": profile})), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 400, "pending": 200, "overflow": 100}), \
             patch("app.services.hp_service._record_hp_transaction"), \
             patch("app.services.hp_service._safe_update_profile"):
            from app.services.hp_service import unlock_pending_hp
            result = unlock_pending_hp(STUDENT_ID, ORDER_ID, 2000.0)

        assert result["unlocked"] == 200  # floor(2000/1000)*100 = 200


# ── J4: Reward Redemption Journey ─────────────────────────────────────────────

class TestJ4RewardRedemptionJourney:
    def test_1700_hp_redemption_deducts_active(self, app):
        """J4-1: 1,700 HP (Free Coleslaw) deducted from active balance."""
        with patch("app.services.hp_service.get_db", return_value=make_mock_db()), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 1700}), \
             patch("app.services.hp_service._record_hp_transaction"):
            from app.services.hp_service import spend_hp
            result = spend_hp(STUDENT_ID, 1700, REWARD_ID, "reward_redemption")

        assert result["spent"] == 1700
        assert result["balance_after"] == 0

    def test_redemption_hp_spend_type_is_spend_reward(self, app):
        """J4-2: Reward redemption records spend_reward type."""
        types = []

        def capture(user_id, amount, txn_type, **kwargs):
            types.append(txn_type)

        with patch("app.services.hp_service.get_db", return_value=make_mock_db()), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 2000}), \
             patch("app.services.hp_service._record_hp_transaction", side_effect=capture):
            from app.services.hp_service import spend_hp
            spend_hp(STUDENT_ID, 1700, REWARD_ID, "reward_redemption")

        assert "spend_reward" in types

    def test_hp_earned_on_full_subtotal_after_redemption(self, app):
        """J4-3: HP earned on original subtotal even after reward redemption."""
        # Order HP is based on subtotal (menu prices) not total (after HP discount)
        with patch("app.services.hp_service.get_db", return_value=make_mock_db()), \
             patch("app.services.hp_service.unlock_pending_hp", return_value={"unlocked": 0}), \
             patch("app.services.hp_service._update_earned_counters"), \
             patch("app.services.hp_service._record_hp_transaction"):
            from app.services.hp_service import award_food_order_hp
            # HP earned on full ₦3500 regardless of hp_discount applied at checkout
            result = award_food_order_hp(STUDENT_ID, ORDER_ID, 3500.0, "ember")

        assert result["base_hp"] == 350


# ── J5: Monthly Leaderboard Competition ───────────────────────────────────────

class TestJ5MonthlyLeaderboard:
    def test_10_orders_at_3500_earns_3500_monthly(self, app):
        """J5-1: 10 orders × ₦3,500 = 3,500 HP in January."""
        total_hp = 0
        for _ in range(10):
            total_hp += int(3500.0 * 0.1)
        assert total_hp == 3500

    def test_monthly_hp_increments_with_each_order(self, app):
        """J5-2: monthly_hp_earned increments correctly per order."""
        profile = {**SAMPLE_PROFILE, "monthly_hp_earned": 0, "hp_earned_120day": 0}
        captured = {}

        def capture(user_id, data):
            captured.update(data)

        with patch("app.services.hp_service.get_db", return_value=make_mock_db({"profiles": profile})), \
             patch("app.services.hp_service._get_profile_hp_fields", return_value=profile), \
             patch("app.services.hp_service._safe_update_profile", side_effect=capture):
            from app.services.hp_service import _update_earned_counters
            _update_earned_counters(STUDENT_ID, 350)

        assert captured.get("monthly_hp_earned") == 350

    def test_rank3_prize_free_lap_chips(self, app):
        """J5-3: Rank #3 gets Free Lap & Chips ×4 (policy test)."""
        # Verified via product spec — 16,400 HP value × 4
        lap_hp = 16400
        total_prize_hp = lap_hp * 4
        assert total_prize_hp == 65600


# ── J6: Flash Redemption FOMO ─────────────────────────────────────────────────

class TestJ6FlashRedemptionFomo:
    def test_flash_50_percent_discount_whole_chicken(self, app):
        """J6-1: Admin launches flash: Whole Chicken at 50% = 32,900 HP."""
        original_hp = 65800
        discounted = int(original_hp * 0.5)
        assert discounted == 32900

    def test_6th_user_pays_full_price(self, app):
        """J6-2: 6th user cannot use flash (limit = 5) — raises error."""
        from datetime import datetime, timezone, timedelta
        now = datetime.now(timezone.utc)
        flash = {
            "id": "flash-001", "reward_id": REWARD_ID, "is_active": True,
            "quantity_limit": 5,
            "window_starts_at": (now - timedelta(hours=1)).isoformat(),
            "window_ends_at": (now + timedelta(hours=23)).isoformat(),
        }
        reward = {**SAMPLE_REWARD, "hp_cost": 65800}
        already = [{"id": f"r{i}"} for i in range(5)]
        db = make_mock_db({"flash_redemptions": flash, "rewards": reward,
                           "reward_redemptions": already})

        with patch("app.services.hp_service.get_db", return_value=db), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 70000}):
            from app.services.hp_service import process_flash_redeem
            with pytest.raises(ValueError, match="limit"):
                process_flash_redeem(REWARD_ID, STUDENT_ID)


# ── J7: Event HP Bundle ───────────────────────────────────────────────────────

class TestJ7EventHpBundle:
    def test_20000_hp_bundle_costs_100000_naira(self, app):
        """J7-1: Event host buys 20,000 HP bundle for ₦100,000."""
        hp_amount = 20000
        price_per_hp = 5.0
        total_cost = hp_amount * price_per_hp
        assert total_cost == 100000.0

    def test_hg_nets_96300_on_20k_bundle(self, app):
        """J7-2: HG nets ₦96,300 (20,000 × ₦4.815) on 20,000 HP bundle."""
        hp_amount = 20000
        net_margin_per_hp = 4.815
        total_margin = hp_amount * net_margin_per_hp
        assert abs(total_margin - 96300.0) < 1.0

    def test_event_host_bundle_credited_to_pending(self, app):
        """J7-3: 20,000 HP credited to event host's pending pool."""
        profile = {**SAMPLE_PROFILE, "pending_hp_balance": 0, "hp_overflow": 0}
        with patch("app.services.hp_service.get_db", return_value=make_mock_db({"profiles": profile})), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 0, "pending": 0, "overflow": 0}), \
             patch("app.services.hp_service._record_hp_transaction"), \
             patch("app.services.hp_service._safe_update_profile"), \
             patch("app.services.hp_service._get_profile_hp_fields", return_value=profile):
            from app.services.hp_service import process_hp_bundle_purchase
            result = process_hp_bundle_purchase(STUDENT_ID, 20000, 100000.0)

        # With zero active, ceiling = 200 HP floor; rest goes to overflow
        assert result["hp_credited_to_pending"] + result["hp_to_overflow"] == 20000
