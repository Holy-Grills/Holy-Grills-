"""
Phase I: Financial & Compliance Tests (25 tests)
I1: Internal Liability Cost Tracking
I2: HP Bundle Financial Tests
I3: Reward Redemption Financial Tests
I4: Refund Financial Tests
I5: Compliance & Retention Tests
"""

import math
import pytest
from unittest.mock import patch, MagicMock
from tests.conftest import (
    make_mock_db, STUDENT_ID, ORDER_ID, SAMPLE_PROFILE, SAMPLE_HP_TXN,
    SAMPLE_ORDER, SAMPLE_REWARD, REWARD_ID, TIER_EMBER, TIER_FLAME
)


@pytest.fixture(autouse=True)
def flask_ctx(app):
    with app.app_context():
        yield


def hp_price_formula(food_cost: float, menu_price: float, margin_share: float = 0.40) -> int:
    """HP Price = round_up((food_cost + share × (menu_price - food_cost)) / ₦0.185)"""
    effective_cost = food_cost + margin_share * (menu_price - food_cost)
    raw_hp = effective_cost / 0.185
    return math.ceil(raw_hp / 50) * 50


# ── I1: Internal Liability Cost Tracking ─────────────────────────────────────

class TestI1LiabilityCostTracking:
    def test_hp_liability_value_is_0_185(self, app):
        """I1-1: HP liability = exactly ₦0.185 per HP."""
        from flask import current_app
        assert current_app.config["HP_LIABILITY_VALUE"] == 0.185

    def test_programme_cost_per_hp_from_food_order(self, app):
        """I1-2: Cost % on food order: (1 HP × ₦0.185) / ₦10 = 1.85%."""
        hp_per_naira = 0.1   # 1 HP per ₦10 = 0.1 HP/₦1
        liability_per_hp = 0.185
        cost_pct = hp_per_naira * liability_per_hp
        assert abs(cost_pct - 0.0185) < 0.0001

    def test_ember_tier_programme_cost(self, app):
        """I1-3: Ember tier cost = base 1.85% (no bonus)."""
        order_total = 10000
        hp_earned = int(order_total * 0.1)  # 1000 HP
        liability = hp_earned * 0.185
        cost_pct = liability / order_total
        assert abs(cost_pct - 0.0185) < 0.001

    def test_holy_tier_cost_3_12_percent(self, app):
        """I1-4: Holy tier cost = 1.85% × 1.25 = 2.3125% ≈ 2.31%."""
        order_total = 10000
        base_hp = int(order_total * 0.1)  # 1000 HP
        total_hp = round(base_hp * 1.25)   # 1250 HP
        liability = total_hp * 0.185
        cost_pct = liability / order_total
        assert abs(cost_pct - 0.023125) < 0.001

    def test_breakage_rate_25_percent(self, app):
        """I1-5: Breakage rate = 25% — reduces effective programme cost."""
        from flask import current_app
        assert current_app.config["HP_EXPIRY_BREAKAGE_RATE"] == 0.25

    def test_hp_bundle_markup_2603_percent(self, app):
        """I1-6: HP bundle sale markup = (₦5 - ₦0.185) / ₦0.185 = 2603%."""
        price_per_hp = 5.0
        liability_per_hp = 0.185
        markup_pct = (price_per_hp - liability_per_hp) / liability_per_hp * 100
        assert abs(markup_pct - 2602.7) < 1


# ── I2: HP Bundle Financial Tests ─────────────────────────────────────────────

class TestI2HpBundleFinancial:
    def test_event_host_pays_5_naira_per_hp(self, app):
        """I2-1: Event host pays exactly ₦5 per HP."""
        from flask import current_app
        assert current_app.config["HP_BUNDLE_PRICE_PER_HP"] == 5.0

    def test_hg_net_margin_4_815_per_hp(self, app):
        """I2-2: HG net margin = ₦5.00 − ₦0.185 = ₦4.815."""
        price_per_hp = 5.0
        liability_per_hp = 0.185
        net_margin = price_per_hp - liability_per_hp
        assert abs(net_margin - 4.815) < 0.001

    def test_bundle_1000hp_costs_5000_naira(self, app):
        """I2-3: 1,000 HP bundle = ₦5,000 total."""
        hp_amount = 1000
        price_per_hp = 5.0
        total_cost = hp_amount * price_per_hp
        assert total_cost == 5000.0

    def test_bundle_creates_liability_of_0_185_per_hp(self, app):
        """I2-4: Each HP bundle creates ₦0.185 liability per HP."""
        hp_amount = 1000
        liability_per_hp = 0.185
        total_liability = hp_amount * liability_per_hp
        assert abs(total_liability - 185.0) < 0.001

    def test_bundle_payment_validation(self, app):
        """I2-5: Bundle purchase validates payment amount matches HP × ₦5."""
        profile = {**SAMPLE_PROFILE, "pending_hp_balance": 0, "hp_overflow": 0}
        with patch("app.services.hp_service.get_db", return_value=make_mock_db({"profiles": profile})):
            from app.services.hp_service import process_hp_bundle_purchase
            with pytest.raises(ValueError, match="mismatch"):
                process_hp_bundle_purchase(STUDENT_ID, 1000, 4000.0)  # wrong amount


# ── I3: Reward Redemption Financial Tests ─────────────────────────────────────

class TestI3RedemptionFinancial:
    def test_coleslaw_hp_price_covers_food_cost(self, app):
        """I3-1: Free Coleslaw costs HG exactly ₦180 (food cost)."""
        food_cost = 180
        hp_price = hp_price_formula(180, 500)
        assert hp_price == 1700
        # At ₦0.185/HP: 1700 × 0.185 = ₦314.50 (HG collects above food cost)
        hp_value = hp_price * 0.185
        assert hp_value >= food_cost

    def test_sausage_hp_price_covers_food_cost(self, app):
        """I3-2: Free Sausage costs HG exactly ₦200 (food cost)."""
        food_cost = 200
        hp_price = hp_price_formula(200, 600)
        assert hp_price == 1950
        hp_value = hp_price * 0.185
        assert hp_value >= food_cost

    def test_chicken_lap_hp_price(self, app):
        """I3-3: Chicken Lap (₦1,919 cost) HP price = 16,400."""
        assert hp_price_formula(1919, 4700) == 16400

    def test_merch_redemption_at_cost(self, app):
        """I3-4: Merch HP price calculated from production cost only."""
        cost = 1800   # T-shirt production cost
        perceived = 4000
        merch_hp = hp_price_formula(cost, perceived, margin_share=0.50)
        assert merch_hp == 15700

    def test_hp_liability_value_constant(self, app):
        """I3-5: HP_LIABILITY_VALUE = 0.185 used consistently."""
        from flask import current_app
        assert current_app.config["HP_LIABILITY_VALUE"] == 0.185


# ── I4: Refund Financial Tests ────────────────────────────────────────────────

class TestI4RefundFinancial:
    def test_hp_redemption_recorded_on_order_payment(self, app):
        """I4-1: HP used at checkout is deducted on payment confirmation."""
        spent = []

        def capture_spend(user_id, amount, reference_id, reference_type, notes=""):
            spent.append(amount)
            return {"spent": amount, "balance_after": 500 - amount}

        order = {**SAMPLE_ORDER, "status": "pending_payment",
                 "hp_points_used": 100, "wallet_amount_used": 0.0}
        db = make_mock_db({"orders": order})

        with patch("app.services.order_service.get_db", return_value=db), \
             patch("app.services.order_service.hp_service.spend_hp", side_effect=capture_spend), \
             patch("app.services.order_service.send_notification"):
            from app.services.order_service import confirm_order_payment
            confirm_order_payment(ORDER_ID, "pay_ref_001")

        assert 100 in spent

    def test_wallet_amount_deducted_on_payment(self, app):
        """I4-2: Wallet amount deducted on payment confirmation."""
        debited = []

        def capture_debit(user_id, amount, reference_id, reference_type, notes=""):
            debited.append(amount)

        order = {**SAMPLE_ORDER, "status": "pending_payment",
                 "hp_points_used": 0, "wallet_amount_used": 1000.0}
        db = make_mock_db({"orders": order})

        with patch("app.services.order_service.get_db", return_value=db), \
             patch("app.services.order_service.debit_wallet", side_effect=capture_debit), \
             patch("app.services.order_service.send_notification"):
            from app.services.order_service import confirm_order_payment
            confirm_order_payment(ORDER_ID, "pay_ref_002")

        assert 1000.0 in debited

    def test_hp_discount_reduces_total_not_subtotal(self, app):
        """I4-3: HP discount reduces total paid, not subtotal (HP base)."""
        from tests.conftest import SAMPLE_MENU_ITEM, SAMPLE_WINDOW, MENU_ITEM_ID, WINDOW_ID
        db = make_mock_db({
            "delivery_windows": SAMPLE_WINDOW,
            "menu_items": SAMPLE_MENU_ITEM,
            "orders": SAMPLE_ORDER,
        })
        payload = {
            "items": [{"menu_item_id": MENU_ITEM_ID, "quantity": 1}],
            "delivery_window_id": WINDOW_ID,
            "payment_method": "card",
            "hp_points_to_redeem": 200,
        }
        with patch("app.services.order_service.get_db", return_value=db), \
             patch("app.services.order_service.send_notification"):
            from app.services.order_service import create_order
            result = create_order(STUDENT_ID, payload)

        assert result["subtotal"] == 3500.0
        assert result["hp_discount"] == round(200 * 0.185, 2)
        assert result["total"] == round(3500.0 - result["hp_discount"], 2)

    def test_card_amount_computed_after_discounts(self, app):
        """I4-4: Card amount = total after all discounts."""
        from tests.conftest import SAMPLE_MENU_ITEM, SAMPLE_WINDOW, MENU_ITEM_ID, WINDOW_ID
        db = make_mock_db({
            "delivery_windows": SAMPLE_WINDOW,
            "menu_items": SAMPLE_MENU_ITEM,
            "orders": SAMPLE_ORDER,
        })
        payload = {
            "items": [{"menu_item_id": MENU_ITEM_ID, "quantity": 1}],
            "delivery_window_id": WINDOW_ID,
            "payment_method": "card",
        }
        with patch("app.services.order_service.get_db", return_value=db), \
             patch("app.services.order_service.send_notification"):
            from app.services.order_service import create_order
            result = create_order(STUDENT_ID, payload)

        assert result["card_amount_used"] == result["total"]


# ── I5: Compliance & Retention Tests ──────────────────────────────────────────

class TestI5ComplianceRetention:
    def test_hp_transactions_table_immutable(self, app):
        """I5-1: hp_transactions are insert-only (never updated by service)."""
        # Verified by inspecting all service calls — spend_hp, earn, etc.
        # only call db.table("hp_transactions").insert(...)
        # Never call db.table("hp_transactions").update(...)
        from app.services import hp_service
        import inspect
        source = inspect.getsource(hp_service._record_hp_transaction)
        assert "update" not in source.lower().replace("_update_earned", "X")

    def test_soft_delete_profile_field_not_hard_delete(self, app):
        """I5-2: Profile has is_active flag for soft deletes."""
        assert "is_active" in SAMPLE_PROFILE

    def test_admin_audit_log_table_exists(self, app):
        """I5-3: admin_audit_log table tracked in DB mock."""
        db = make_mock_db()
        tbl = db.table("admin_audit_log")
        assert tbl is not None

    def test_leaderboard_snapshots_table_exists(self, app):
        """I5-4: leaderboard_snapshots table tracked for hall of fame."""
        db = make_mock_db()
        tbl = db.table("leaderboard_snapshots")
        assert tbl is not None

    def test_hp_balance_fallback_does_not_use_external_data(self, app):
        """I5-5: HP balance fallback uses only local DB data — no external calls."""
        db = make_mock_db({
            "hp_transactions": [{"amount": 100, "status": "active"}],
            "profiles": {**SAMPLE_PROFILE, "pending_hp_balance": 0, "hp_overflow": 0},
        })
        db.rpc.side_effect = Exception("RPC unavailable")

        with patch("app.services.hp_service.get_db", return_value=db):
            from app.services.hp_service import get_hp_balance
            result = get_hp_balance(STUDENT_ID)

        assert result["active"] == 100
        assert isinstance(result, dict)
