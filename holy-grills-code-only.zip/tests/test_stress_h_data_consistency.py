"""
Phase H: Data Consistency & Integration Tests (30 tests)
H1: Old Schema + New Schema Coexistence
H2: Cross-Table Foreign Key Integrity
H3: Data Type & Range Checks
H4: Audit Trail Completeness
H5: Rollback & Recovery
"""

import pytest
from unittest.mock import patch, MagicMock
from tests.conftest import (
    make_mock_db, STUDENT_ID, ORDER_ID, SAMPLE_PROFILE, SAMPLE_HP_TXN,
    SAMPLE_TIERS, TIER_EMBER, TIER_FLAME, SAMPLE_ORDER, SAMPLE_REWARD, REWARD_ID
)


@pytest.fixture(autouse=True)
def flask_ctx(app):
    with app.app_context():
        yield


# ── H1: Old Schema + New Schema Coexistence ───────────────────────────────────

class TestH1SchemaCoexistence:
    def test_existing_hp_transactions_still_sum_correctly(self, app):
        """H1-1: Existing hp_transactions (before pending schema) still sum to balance."""
        old_txns = [
            {"amount": 350, "status": "active"},
            {"amount": 200, "status": "active"},
            {"amount": -100, "status": "active"},  # spend
        ]
        profile = {**SAMPLE_PROFILE, "pending_hp_balance": 0, "hp_overflow": 0}
        db = make_mock_db({"hp_transactions": old_txns, "profiles": profile})
        db.rpc.side_effect = Exception("fallback")

        with patch("app.services.hp_service.get_db", return_value=db):
            from app.services.hp_service import get_hp_balance
            result = get_hp_balance(STUDENT_ID)

        assert result["active"] == 450  # 350 + 200 - 100

    def test_users_before_pending_have_zero_pending(self, app):
        """H1-2: Users created before pending pool have pending_hp_balance = 0."""
        profile = {**SAMPLE_PROFILE, "pending_hp_balance": 0}
        assert profile["pending_hp_balance"] == 0

    def test_users_before_pending_have_zero_overflow(self, app):
        """H1-3: Users created before pending pool have hp_overflow = 0."""
        profile = {**SAMPLE_PROFILE, "hp_overflow": 0}
        assert profile["hp_overflow"] == 0

    def test_existing_active_hp_usable_for_redemptions(self, app):
        """H1-4: Existing active HP continues to work for redemptions."""
        with patch("app.services.hp_service.get_db", return_value=make_mock_db()), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 500}), \
             patch("app.services.hp_service._record_hp_transaction"):
            from app.services.hp_service import spend_hp
            result = spend_hp(STUDENT_ID, 100, ORDER_ID, "reward_redemption")

        assert result["spent"] == 100

    def test_new_hp_transactions_have_source_type_field(self, app):
        """H1-5: New hp_transactions include source_type field."""
        recorded = []

        def capture(record):
            recorded.append(record)
            return [record]

        db = make_mock_db()
        original_side = db.table.side_effect

        def guarded(name):
            from tests.conftest import MockTableQuery
            tbl = original_side(name)
            if name == "hp_transactions":
                orig_insert = tbl.insert
                def track(data):
                    recorded.append(data if isinstance(data, dict) else data)
                    return orig_insert(data)
                tbl.insert = track
            return tbl

        db.table.side_effect = guarded

        with patch("app.services.hp_service.get_db", return_value=db), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 500, "pending": 0, "overflow": 0}):
            from app.services.hp_service import _record_hp_transaction
            _record_hp_transaction(
                user_id=STUDENT_ID, amount=100, txn_type="earn_order",
                source_type="food", status="active",
            )

        assert any(isinstance(r, dict) and r.get("source_type") == "food" for r in recorded)

    def test_old_txn_type_earn_still_supported(self, app):
        """H1-6: Old transaction type values fall back gracefully."""
        from app.services.hp_service import TXN_TYPE_MAP
        # Legacy "order" maps to earn_order
        assert TXN_TYPE_MAP.get("order") == "earn_order"

    def test_monthly_hp_earned_field_on_profile(self, app):
        """H1-7: monthly_hp_earned field present on all profiles."""
        assert "monthly_hp_earned" in SAMPLE_PROFILE

    def test_120day_field_on_profile(self, app):
        """H1-8: hp_earned_120day field present on all profiles."""
        assert "hp_earned_120day" in SAMPLE_PROFILE


# ── H2: Cross-Table Foreign Key Integrity ─────────────────────────────────────

class TestH2ForeignKeyIntegrity:
    def test_hp_transaction_user_id_always_set(self, app):
        """H2-1: hp_transactions always receive user_id."""
        recorded = []

        def capture(user_id, amount, txn_type, **kwargs):
            recorded.append(user_id)

        with patch("app.services.hp_service.get_db", return_value=make_mock_db()), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 500}), \
             patch("app.services.hp_service._record_hp_transaction", side_effect=capture):
            from app.services.hp_service import spend_hp
            spend_hp(STUDENT_ID, 100, ORDER_ID, "reward_redemption")

        assert all(uid == STUDENT_ID for uid in recorded)

    def test_reward_redemption_user_id_set(self, client, auth_headers):
        """H2-2: Reward redemptions link to user_id via auth."""
        db = make_mock_db()
        with patch("app.middleware.auth.get_db", return_value=db), \
             patch("app.routes.rewards.get_db", return_value=db), \
             patch("app.routes.rewards.get_hp_balance", return_value={"active": 10000}), \
             patch("app.routes.rewards.spend_hp", return_value={"spent": 150, "balance_after": 9850}):
            resp = client.post(f"/api/rewards/{REWARD_ID}/redeem", headers=auth_headers)

        assert resp.status_code in (200, 201, 400, 404)

    def test_order_items_link_to_order(self, app):
        """H2-3: Order items always receive order_id from created order."""
        inserted_items = []

        original_db = make_mock_db({
            "delivery_windows": {"id": "dddddddd-0000-0000-0000-000000000001", "status": "open"},
            "menu_items": {"id": "cccccccc-0000-0000-0000-000000000001", "name": "Test",
                           "price": 1000.0, "is_available": True, "is_archived": False, "hp_earn_value": 10},
            "orders": SAMPLE_ORDER,
        })
        original_side = original_db.table.side_effect

        def guarded(name):
            tbl = original_side(name)
            if name == "order_items":
                orig_insert = tbl.insert
                def track(data):
                    inserted_items.extend(data if isinstance(data, list) else [data])
                    return orig_insert(data)
                tbl.insert = track
            return tbl

        original_db.table.side_effect = guarded

        with patch("app.services.order_service.get_db", return_value=original_db), \
             patch("app.services.order_service.send_notification"):
            from app.services.order_service import create_order
            create_order(STUDENT_ID, {
                "items": [{"menu_item_id": "cccccccc-0000-0000-0000-000000000001", "quantity": 1}],
                "delivery_window_id": "dddddddd-0000-0000-0000-000000000001",
                "payment_method": "card",
            })

        assert all("order_id" in item for item in inserted_items)

    def test_status_log_links_to_order(self, app):
        """H2-4: Order status log always references order_id."""
        logged = []

        original_db = make_mock_db({"orders": {**SAMPLE_ORDER, "status": "received"}})
        original_side = original_db.table.side_effect

        def guarded(name):
            tbl = original_side(name)
            if name == "order_status_log":
                orig_insert = tbl.insert
                def track(data):
                    logged.append(data)
                    return orig_insert(data)
                tbl.insert = track
            return tbl

        original_db.table.side_effect = guarded

        with patch("app.services.order_service.get_db", return_value=original_db), \
             patch("app.services.order_service.send_notification"):
            from app.services.order_service import update_order_status
            update_order_status(ORDER_ID, "preparing")

        assert any(log.get("order_id") == ORDER_ID for log in logged)

    def test_user_tiers_link_to_tier_id(self, app):
        """H2-5: user_tiers always reference a valid tier_id."""
        inserted = []

        original_db = make_mock_db({
            "profiles": {**SAMPLE_PROFILE, "hp_earned_120day": 3000},
            "tiers": SAMPLE_TIERS,
            "user_tiers": [{"id": "x", "tier_id": TIER_EMBER, "is_current": True}],
        })
        original_side = original_db.table.side_effect

        def guarded(name):
            tbl = original_side(name)
            if name == "user_tiers":
                orig_insert = tbl.insert
                def track(data):
                    inserted.append(data)
                    return orig_insert(data)
                tbl.insert = track
            return tbl

        original_db.table.side_effect = guarded

        with patch("app.services.hp_service.get_db", return_value=original_db), \
             patch("app.services.hp_service._safe_update_profile"):
            from app.services.hp_service import recalculate_tier
            recalculate_tier(STUDENT_ID)

        assert any("tier_id" in row for row in inserted)

    def test_hp_bundle_purchase_links_to_user(self, app):
        """H2-6: hp_bundle_purchases links event_host_id to user."""
        inserted = []
        original_db = make_mock_db()
        original_side = original_db.table.side_effect

        def guarded(name):
            tbl = original_side(name)
            if name == "hp_bundle_purchases":
                orig = tbl.insert
                def track(data):
                    inserted.append(data)
                    return orig(data)
                tbl.insert = track
            return tbl

        original_db.table.side_effect = guarded
        profile = {**SAMPLE_PROFILE, "pending_hp_balance": 0, "hp_overflow": 0}

        with patch("app.services.hp_service.get_db", return_value=original_db), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 0, "pending": 0, "overflow": 0}), \
             patch("app.services.hp_service._record_hp_transaction"), \
             patch("app.services.hp_service._safe_update_profile"), \
             patch("app.services.hp_service._get_profile_hp_fields", return_value=profile):
            from app.services.hp_service import process_hp_bundle_purchase
            process_hp_bundle_purchase(STUDENT_ID, 100, 500.0)

        assert any(row.get("event_host_id") == STUDENT_ID for row in inserted)


# ── H3: Data Type & Range Checks ──────────────────────────────────────────────

class TestH3DataTypeRangeChecks:
    def test_pending_hp_balance_never_negative(self, app):
        """H3-1: pending_hp_balance never goes negative — capped at 0."""
        profile = {**SAMPLE_PROFILE, "pending_hp_balance": 50, "hp_overflow": 0}
        with patch("app.services.hp_service.get_db", return_value=make_mock_db({"profiles": profile})), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 200, "pending": 50, "overflow": 0}), \
             patch("app.services.hp_service._record_hp_transaction"), \
             patch("app.services.hp_service._safe_update_profile"):
            from app.services.hp_service import unlock_pending_hp
            result = unlock_pending_hp(STUDENT_ID, ORDER_ID, 10000.0)  # huge unlock

        assert result["unlocked"] <= 50  # can't unlock more than pending

    def test_hp_earned_120day_matches_earned_sum(self, app):
        """H3-2: hp_earned_120day is a counter that increments with earned HP."""
        profile = {**SAMPLE_PROFILE, "hp_earned_120day": 0, "monthly_hp_earned": 0}
        captured = {}

        def capture(user_id, data):
            captured.update(data)

        with patch("app.services.hp_service.get_db", return_value=make_mock_db({"profiles": profile})), \
             patch("app.services.hp_service._get_profile_hp_fields", return_value=profile), \
             patch("app.services.hp_service._safe_update_profile", side_effect=capture):
            from app.services.hp_service import _update_earned_counters
            _update_earned_counters(STUDENT_ID, 350)

        assert captured.get("hp_earned_120day") == 350

    def test_monthly_hp_resets_to_zero(self, app):
        """H3-3: monthly_hp_earned can be reset to exactly 0."""
        captured = {}

        def capture(user_id, data):
            captured.update(data)

        with patch("app.services.hp_service.get_db", return_value=make_mock_db()), \
             patch("app.services.hp_service._safe_update_profile", side_effect=capture):
            from app.services.hp_service import _safe_update_profile
            _safe_update_profile(STUDENT_ID, {"monthly_hp_earned": 0})

        assert captured.get("monthly_hp_earned") == 0

    def test_tier_multiplier_valid_values(self, app):
        """H3-4: tier_bonus_multiplier only accepts valid tier multipliers."""
        valid_multipliers = {1.0, 1.08, 1.15, 1.25}
        for tier in SAMPLE_TIERS:
            assert tier["earn_multiplier"] in valid_multipliers

    def test_overflow_is_non_negative(self, app):
        """H3-5: hp_overflow never goes below 0."""
        profile = {**SAMPLE_PROFILE, "pending_hp_balance": 100, "hp_overflow": 0}
        with patch("app.services.hp_service.get_db", return_value=make_mock_db({"profiles": profile})), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 1000, "pending": 100, "overflow": 0}), \
             patch("app.services.hp_service._record_hp_transaction"), \
             patch("app.services.hp_service._safe_update_profile"):
            from app.services.hp_service import unlock_pending_hp
            result = unlock_pending_hp(STUDENT_ID, ORDER_ID, 1000.0)

        assert result.get("overflow_restored", 0) >= 0

    def test_unlocked_hp_never_exceeds_pending(self, app):
        """H3-6: Unlocked HP <= original pending balance."""
        pending_balance = 150
        profile = {**SAMPLE_PROFILE, "pending_hp_balance": pending_balance, "hp_overflow": 0}

        with patch("app.services.hp_service.get_db", return_value=make_mock_db({"profiles": profile})), \
             patch("app.services.hp_service.get_hp_balance",
                   return_value={"active": 1000, "pending": pending_balance, "overflow": 0}), \
             patch("app.services.hp_service._record_hp_transaction"), \
             patch("app.services.hp_service._safe_update_profile"):
            from app.services.hp_service import unlock_pending_hp
            result = unlock_pending_hp(STUDENT_ID, ORDER_ID, 5000.0)  # would unlock 500

        assert result["unlocked"] <= pending_balance


# ── H4: Audit Trail Completeness ──────────────────────────────────────────────

class TestH4AuditTrailCompleteness:
    def test_unlock_records_hp_transaction(self, app):
        """H4-1: Every pending → active unlock creates an hp_transaction."""
        recorded_types = []

        def capture(user_id, amount, txn_type, **kwargs):
            recorded_types.append(txn_type)

        profile = {**SAMPLE_PROFILE, "pending_hp_balance": 500, "hp_overflow": 0}
        with patch("app.services.hp_service.get_db", return_value=make_mock_db({"profiles": profile})), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 1000, "pending": 500, "overflow": 0}), \
             patch("app.services.hp_service._record_hp_transaction", side_effect=capture), \
             patch("app.services.hp_service._safe_update_profile"):
            from app.services.hp_service import unlock_pending_hp
            unlock_pending_hp(STUDENT_ID, ORDER_ID, 1000.0)

        assert "unlock" in recorded_types

    def test_admin_grant_includes_admin_id(self, app):
        """H4-3: Admin-issued HP has issued_by_admin_id in record."""
        from tests.conftest import ADMIN_ID
        recorded = []

        def capture(user_id, amount, txn_type, issued_by_admin_id=None, **kwargs):
            recorded.append({"user": user_id, "admin": issued_by_admin_id})

        with patch("app.services.hp_service.get_db", return_value=make_mock_db()), \
             patch("app.services.hp_service._update_earned_counters"), \
             patch("app.services.hp_service._record_hp_transaction", side_effect=capture):
            from app.services.hp_service import award_active_hp
            award_active_hp(STUDENT_ID, 200, source_type="admin_grant", issued_by_admin_id=ADMIN_ID)

        assert any(r["admin"] == ADMIN_ID for r in recorded)

    def test_order_status_log_recorded_on_each_transition(self, app):
        """H4-2: Every order status change logged in order_status_log."""
        logged = []
        original_db = make_mock_db({"orders": {**SAMPLE_ORDER, "status": "received"}})
        original_side = original_db.table.side_effect

        def guarded(name):
            tbl = original_side(name)
            if name == "order_status_log":
                orig = tbl.insert
                def track(data):
                    logged.append(data)
                    return orig(data)
                tbl.insert = track
            return tbl

        original_db.table.side_effect = guarded

        with patch("app.services.order_service.get_db", return_value=original_db), \
             patch("app.services.order_service.send_notification"):
            from app.services.order_service import update_order_status
            update_order_status(ORDER_ID, "preparing")

        assert len(logged) > 0
        assert logged[0]["from_status"] == "received"
        assert logged[0]["to_status"] == "preparing"

    def test_tier_change_records_previous_tier_id(self, app):
        """H4-4: Tier change records previous_tier_id for audit."""
        profile = {**SAMPLE_PROFILE, "hp_earned_120day": 2600}
        db = make_mock_db({"profiles": profile, "tiers": SAMPLE_TIERS,
                           "user_tiers": [{"id": "x", "tier_id": TIER_EMBER, "is_current": True}]})

        with patch("app.services.hp_service.get_db", return_value=db), \
             patch("app.services.hp_service._safe_update_profile"):
            from app.services.hp_service import recalculate_tier
            result = recalculate_tier(STUDENT_ID)

        assert result.get("previous_tier_id") == TIER_EMBER

    def test_flash_redemption_records_hp_transaction(self, app):
        """H4-5: Flash redemption HP spend recorded in hp_transactions."""
        from datetime import datetime, timezone, timedelta
        now = datetime.now(timezone.utc)
        flash = {
            "id": "flash-001", "reward_id": REWARD_ID, "is_active": True,
            "quantity_limit": 5,
            "window_starts_at": (now - timedelta(hours=1)).isoformat(),
            "window_ends_at": (now + timedelta(hours=23)).isoformat(),
        }
        reward = {**SAMPLE_REWARD, "hp_cost": 1000}
        db = make_mock_db({"flash_redemptions": flash, "rewards": reward,
                           "reward_redemptions": []})

        txn_recorded = []
        with patch("app.services.hp_service.get_db", return_value=db), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 5000}), \
             patch("app.services.hp_service.spend_hp", return_value={"spent": 500, "balance_after": 4500}) as mock_spend:
            from app.services.hp_service import process_flash_redeem
            process_flash_redeem(REWARD_ID, STUDENT_ID)

        mock_spend.assert_called_once()


# ── H5: Rollback & Recovery ───────────────────────────────────────────────────

class TestH5RollbackRecovery:
    def test_failed_unlock_does_not_reduce_pending(self, app):
        """H5-1: Zero food spend returns zero unlocked — pending untouched."""
        with patch("app.services.hp_service.get_db", return_value=make_mock_db()), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 1000, "pending": 200, "overflow": 0}):
            from app.services.hp_service import unlock_pending_hp
            result = unlock_pending_hp(STUDENT_ID, ORDER_ID, 0.0)

        assert result["unlocked"] == 0

    def test_sub_1000_spend_no_unlock(self, app):
        """H5-2: ₦900 food spend unlocks 0 HP — pending preserved."""
        profile = {**SAMPLE_PROFILE, "pending_hp_balance": 300, "hp_overflow": 0}
        updates = []

        def capture(user_id, data):
            updates.append(data)

        with patch("app.services.hp_service.get_db", return_value=make_mock_db({"profiles": profile})), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 1000, "pending": 300, "overflow": 0}), \
             patch("app.services.hp_service._record_hp_transaction"), \
             patch("app.services.hp_service._safe_update_profile", side_effect=capture):
            from app.services.hp_service import unlock_pending_hp
            result = unlock_pending_hp(STUDENT_ID, ORDER_ID, 900.0)

        assert result["unlocked"] == 0

    def test_spend_fails_gracefully_on_insufficient_hp(self, app):
        """H5-3: Spend failure raises ValueError — no partial transaction."""
        recorded = []

        def capture(user_id, amount, txn_type, **kwargs):
            recorded.append(amount)

        with patch("app.services.hp_service.get_db", return_value=make_mock_db()), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 50}), \
             patch("app.services.hp_service._record_hp_transaction", side_effect=capture):
            from app.services.hp_service import spend_hp
            try:
                spend_hp(STUDENT_ID, 100, ORDER_ID, "reward_redemption")
            except ValueError:
                pass

        assert recorded == []  # no transaction recorded on failure

    def test_no_hp_earned_on_cancelled_order(self, app):
        """H5-4: Cancelling order → HP never credited."""
        hp_calls = []
        with patch("app.services.order_service.get_db", return_value=make_mock_db(
                {"orders": {"id": ORDER_ID, "status": "received", "user_id": STUDENT_ID}})), \
             patch("app.services.order_service.hp_service.award_food_order_hp",
                   side_effect=lambda *a, **kw: hp_calls.append(True)), \
             patch("app.services.order_service.send_notification"):
            from app.services.order_service import update_order_status
            update_order_status(ORDER_ID, "cancelled")

        assert hp_calls == []

    def test_duplicate_webhook_idempotency(self, app):
        """H5-5: confirm_order_payment is idempotent if already past pending_payment."""
        already_received = {**SAMPLE_ORDER, "status": "received"}
        db = make_mock_db({"orders": already_received})

        with patch("app.services.order_service.get_db", return_value=db), \
             patch("app.services.order_service.send_notification"):
            from app.services.order_service import confirm_order_payment
            result = confirm_order_payment(ORDER_ID, "ref-duplicate")

        # Returns existing order without further processing
        assert result is not None
