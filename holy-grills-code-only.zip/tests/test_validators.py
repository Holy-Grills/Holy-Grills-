"""Unit tests for input validators."""

import pytest


@pytest.fixture(autouse=True)
def flask_ctx(app):
    with app.app_context():
        yield


class TestEmailValidator:
    def test_valid_emails(self):
        from app.utils.validators import validate_email
        assert validate_email("student@futa.edu.ng") is True
        assert validate_email("test.user+tag@gmail.com") is True
        assert validate_email("admin@holygrills.ng") is True

    def test_invalid_emails(self):
        from app.utils.validators import validate_email
        assert validate_email("notanemail") is False
        assert validate_email("@nodomain.com") is False
        assert validate_email("no-at-sign") is False
        assert validate_email("") is False


class TestPhoneValidator:
    def test_valid_nigerian_numbers(self):
        from app.utils.validators import validate_phone
        assert validate_phone("08012345678") is True
        assert validate_phone("07011112222") is True
        assert validate_phone("+2348012345678") is True
        assert validate_phone("09099998888") is True

    def test_invalid_phones(self):
        from app.utils.validators import validate_phone
        assert validate_phone("123") is False
        assert validate_phone("0601234567") is False  # wrong prefix
        assert validate_phone("") is False


class TestPasswordValidator:
    def test_strong_password(self):
        from app.utils.validators import validate_password
        ok, msg = validate_password("Secure1234")
        assert ok is True
        assert msg == ""

    def test_too_short(self):
        from app.utils.validators import validate_password
        ok, msg = validate_password("Ab1")
        assert ok is False
        assert "8" in msg

    def test_no_letter(self):
        from app.utils.validators import validate_password
        ok, msg = validate_password("12345678")
        assert ok is False
        assert "letter" in msg

    def test_no_number(self):
        from app.utils.validators import validate_password
        ok, msg = validate_password("NoNumbersHere")
        assert ok is False
        assert "number" in msg


class TestUuidValidator:
    def test_valid_uuid(self):
        from app.utils.validators import validate_uuid
        assert validate_uuid("00000000-0000-0000-0000-000000000001") is True
        assert validate_uuid("aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee") is True

    def test_invalid_uuid(self):
        from app.utils.validators import validate_uuid
        assert validate_uuid("not-a-uuid") is False
        assert validate_uuid("12345") is False
        assert validate_uuid("") is False


class TestHpAmountValidator:
    def test_valid_amounts(self):
        from app.utils.validators import validate_hp_amount
        ok, _ = validate_hp_amount(50)
        assert ok is True
        ok, _ = validate_hp_amount("150")
        assert ok is True

    def test_zero_invalid(self):
        from app.utils.validators import validate_hp_amount
        ok, msg = validate_hp_amount(0)
        assert ok is False

    def test_too_large(self):
        from app.utils.validators import validate_hp_amount
        ok, msg = validate_hp_amount(200000)
        assert ok is False
        assert "limit" in msg


class TestOrderItemsValidator:
    def test_valid_items(self):
        from app.utils.validators import validate_order_items
        ok, msg = validate_order_items([
            {"menu_item_id": "00000000-0000-0000-0000-000000000001", "quantity": 2}
        ])
        assert ok is True

    def test_empty_list(self):
        from app.utils.validators import validate_order_items
        ok, msg = validate_order_items([])
        assert ok is False

    def test_invalid_uuid(self):
        from app.utils.validators import validate_order_items
        ok, msg = validate_order_items([{"menu_item_id": "not-a-uuid", "quantity": 1}])
        assert ok is False
        assert "UUID" in msg

    def test_quantity_out_of_range(self):
        from app.utils.validators import validate_order_items
        ok, msg = validate_order_items([
            {"menu_item_id": "00000000-0000-0000-0000-000000000001", "quantity": 99}
        ])
        assert ok is False
        assert "50" in msg
