"""
Unit tests for HP Service — the core HP economy logic.
All DB calls are mocked. Tests validate business rules precisely.
"""

import pytest
from unittest.mock import patch, MagicMock
from tests.conftest import (
    make_mock_db, STUDENT_ID, ORDER_ID, TIER_EMBER, TIER_FLAME,
    SAMPLE_TIERS, SAMPLE_PROFILE, SAMPLE_HP_TXN
)


@pytest.fixture(autouse=True)
def flask_ctx(app):
    with app.app_context():
        yield


class TestGetHpBalance:
    def test_returns_active_pending_overflow(self, app):
        db = make_mock_db({"hp_transactions": [
            {"amount": 500, "status": "active"},
            {"amount": 100, "status": "pending"},
        ]})
        db.rpc.side_effect = Exception("force fallback")

        with patch("app.services.hp_service.get_db", return_value=db):
            from app.services.hp_service import get_hp_balance
            result = get_hp_balance(STUDENT_ID)
        assert result["active"] == 500
        assert isinstance(result["pending"], int)

    def test_rpc_used_when_available(self, app):
        db = make_mock_db()
        db.rpc.return_value = {"active": 1000, "pending": 200, "overflow": 50}

        with patch("app.services.hp_service.get_db", return_value=db):
            from app.services.hp_service import get_hp_balance
            result = get_hp_balance(STUDENT_ID)
        assert result["active"] == 1000

    def test_zero_balance_new_user(self, app):
        db = make_mock_db({"hp_transactions": [], "profiles": {**SAMPLE_PROFILE, "pending_hp_balance": 0, "hp_overflow": 0}})
        db.rpc.side_effect = Exception("fallback")

        with patch("app.services.hp_service.get_db", return_value=db):
            from app.services.hp_service import get_hp_balance
            result = get_hp_balance(STUDENT_ID)
        assert result["active"] == 0
        assert result["pending"] == 0
        assert result["overflow"] == 0


class TestAwardFoodOrderHp:
    def test_base_hp_calculation(self, app):
        """1 HP per ₦10 — ₦3,500 order = 350 base HP"""
        db = make_mock_db()
        db.rpc.return_value = {"active": 0, "pending": 0, "overflow": 0}

        with patch("app.services.hp_service.get_db", return_value=db), \
             patch("app.services.hp_service.unlock_pending_hp", return_value={"unlocked": 0}), \
             patch("app.services.hp_service._update_earned_counters"), \
             patch("app.services.hp_service._record_hp_transaction"):
            from app.services.hp_service import award_food_order_hp
            result = award_food_order_hp(STUDENT_ID, ORDER_ID, 3500.0, "ember")

        assert result["base_hp"] == 350
        assert result["tier_bonus_hp"] == 0
        assert result["total_hp"] == 350

    def test_flame_tier_bonus(self, app):
        """Flame tier = 1.08x → 8% bonus on base HP"""
        db = make_mock_db()
        db.rpc.return_value = {"active": 500, "pending": 0, "overflow": 0}

        with patch("app.services.hp_service.get_db", return_value=db), \
             patch("app.services.hp_service.unlock_pending_hp", return_value={"unlocked": 0}), \
             patch("app.services.hp_service._update_earned_counters"), \
             patch("app.services.hp_service._record_hp_transaction"):
            from app.services.hp_service import award_food_order_hp
            result = award_food_order_hp(STUDENT_ID, ORDER_ID, 1000.0, "flame")

        assert result["base_hp"] == 100
        assert result["tier_bonus_hp"] == 8  # int(100 * 0.08)
        assert result["total_hp"] == 108

    def test_blaze_tier_bonus(self, app):
        """Blaze = 1.15x → 15% bonus"""
        with patch("app.services.hp_service.get_db", return_value=make_mock_db()), \
             patch("app.services.hp_service.unlock_pending_hp", return_value={"unlocked": 0}), \
             patch("app.services.hp_service._update_earned_counters"), \
             patch("app.services.hp_service._record_hp_transaction"):
            from app.services.hp_service import award_food_order_hp
            result = award_food_order_hp(STUDENT_ID, ORDER_ID, 1000.0, "blaze")
        assert result["tier_bonus_hp"] == 15
        assert result["total_hp"] == 115

    def test_holy_tier_bonus(self, app):
        """Holy = 1.25x → 25% bonus"""
        with patch("app.services.hp_service.get_db", return_value=make_mock_db()), \
             patch("app.services.hp_service.unlock_pending_hp", return_value={"unlocked": 0}), \
             patch("app.services.hp_service._update_earned_counters"), \
             patch("app.services.hp_service._record_hp_transaction"):
            from app.services.hp_service import award_food_order_hp
            result = award_food_order_hp(STUDENT_ID, ORDER_ID, 1000.0, "holy")
        assert result["tier_bonus_hp"] == 25
        assert result["total_hp"] == 125

    def test_unlock_triggered_on_food_order(self, app):
        """unlock_pending_hp must be called with the correct food spend"""
        with patch("app.services.hp_service.get_db", return_value=make_mock_db()), \
             patch("app.services.hp_service.unlock_pending_hp", return_value={"unlocked": 350}) as mock_unlock, \
             patch("app.services.hp_service._update_earned_counters"), \
             patch("app.services.hp_service._record_hp_transaction"):
            from app.services.hp_service import award_food_order_hp
            result = award_food_order_hp(STUDENT_ID, ORDER_ID, 3500.0, "ember")

        mock_unlock.assert_called_once_with(STUDENT_ID, ORDER_ID, 3500.0)
        assert result["unlocked_pending_hp"] == 350


class TestUnlockPendingHp:
    def test_unlock_rate_100_per_1000(self, app):
        """₦3,500 spend → floor(3500/1000)*100 = 300 HP unlocked (whole ₦1,000 units only)"""
        profile = {**SAMPLE_PROFILE, "pending_hp_balance": 500, "hp_overflow": 0}
        db = make_mock_db({"profiles": profile})
        db.rpc.return_value = {"active": 1000, "pending": 500, "overflow": 0}

        with patch("app.services.hp_service.get_db", return_value=db), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 1000, "pending": 500, "overflow": 0}), \
             patch("app.services.hp_service._record_hp_transaction"), \
             patch("app.services.hp_service._safe_update_profile"):
            from app.services.hp_service import unlock_pending_hp
            result = unlock_pending_hp(STUDENT_ID, ORDER_ID, 3500.0)
        assert result["unlocked"] == 300  # floor(3500/1000)=3 whole units × 100 HP

    def test_cannot_unlock_more_than_pending(self, app):
        """If pending < unlock amount, only unlock what exists"""
        profile = {**SAMPLE_PROFILE, "pending_hp_balance": 100, "hp_overflow": 0}
        db = make_mock_db({"profiles": profile})

        with patch("app.services.hp_service.get_db", return_value=db), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 0, "pending": 100, "overflow": 0}), \
             patch("app.services.hp_service._record_hp_transaction"), \
             patch("app.services.hp_service._safe_update_profile"):
            from app.services.hp_service import unlock_pending_hp
            result = unlock_pending_hp(STUDENT_ID, ORDER_ID, 3500.0)
        assert result["unlocked"] == 100  # capped at pending balance

    def test_overflow_restored_when_ceiling_rises(self, app):
        """After unlocking, if ceiling rises, some overflow → pending"""
        profile = {**SAMPLE_PROFILE, "pending_hp_balance": 200, "hp_overflow": 300}
        db = make_mock_db({"profiles": profile})

        with patch("app.services.hp_service.get_db", return_value=db), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 2000, "pending": 200, "overflow": 300}), \
             patch("app.services.hp_service._record_hp_transaction"), \
             patch("app.services.hp_service._safe_update_profile"):
            from app.services.hp_service import unlock_pending_hp
            result = unlock_pending_hp(STUDENT_ID, ORDER_ID, 2000.0)
        # 200 unlocked. New active ~2200. New ceiling = max(int(2200*0.35),200) = 770
        # space = 770 - (200-200) = 770 → restore min(300,770) = 300
        assert result["overflow_restored"] >= 0  # overflow was partially/fully restored

    def test_zero_spend_returns_zero_unlocked(self, app):
        with patch("app.services.hp_service.get_db", return_value=make_mock_db()), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 1000, "pending": 200, "overflow": 0}):
            from app.services.hp_service import unlock_pending_hp
            result = unlock_pending_hp(STUDENT_ID, ORDER_ID, 0.0)
        assert result["unlocked"] == 0


class TestEarnPendingHp:
    def test_hp_added_to_pending_within_ceiling(self, app):
        """Active=1000 → ceiling=max(350,200)=350. pending=0 → space=350 → all 75 fit"""
        profile = {**SAMPLE_PROFILE, "pending_hp_balance": 0, "hp_overflow": 0}
        db = make_mock_db({"profiles": profile})

        with patch("app.services.hp_service.get_db", return_value=db), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 1000, "pending": 0, "overflow": 0}), \
             patch("app.services.hp_service._record_hp_transaction"), \
             patch("app.services.hp_service._safe_update_profile"), \
             patch("app.services.hp_service._get_profile_hp_fields", return_value=profile):
            from app.services.hp_service import earn_pending_hp
            result = earn_pending_hp(STUDENT_ID, 75, "referral", ORDER_ID)

        assert result["added_to_pending"] == 75
        assert result["added_to_overflow"] == 0

    def test_overflow_applied_when_ceiling_reached(self, app):
        """Active=1000, pending=350 (at ceiling 350) → no space → all goes to overflow"""
        profile = {**SAMPLE_PROFILE, "pending_hp_balance": 350, "hp_overflow": 0}

        with patch("app.services.hp_service.get_db", return_value=make_mock_db({"profiles": profile})), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 1000, "pending": 350, "overflow": 0}), \
             patch("app.services.hp_service._record_hp_transaction"), \
             patch("app.services.hp_service._safe_update_profile"), \
             patch("app.services.hp_service._get_profile_hp_fields", return_value=profile):
            from app.services.hp_service import earn_pending_hp
            result = earn_pending_hp(STUDENT_ID, 75, "referral")

        assert result["added_to_pending"] == 0
        assert result["added_to_overflow"] == 75

    def test_partial_pending_partial_overflow(self, app):
        """Active=1000, pending=300, ceiling=350 → space=50 → 50 pending + 25 overflow"""
        profile = {**SAMPLE_PROFILE, "pending_hp_balance": 300, "hp_overflow": 0}

        with patch("app.services.hp_service.get_db", return_value=make_mock_db({"profiles": profile})), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 1000, "pending": 300, "overflow": 0}), \
             patch("app.services.hp_service._record_hp_transaction"), \
             patch("app.services.hp_service._safe_update_profile"), \
             patch("app.services.hp_service._get_profile_hp_fields", return_value=profile):
            from app.services.hp_service import earn_pending_hp
            result = earn_pending_hp(STUDENT_ID, 75, "referral")

        assert result["added_to_pending"] == 50
        assert result["added_to_overflow"] == 25

    def test_floor_200hp_for_new_accounts(self, app):
        """Active=0 → ceiling=max(0,200)=200 (floor). 100 HP all fit."""
        profile = {**SAMPLE_PROFILE, "pending_hp_balance": 0, "hp_overflow": 0}

        with patch("app.services.hp_service.get_db", return_value=make_mock_db({"profiles": profile})), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 0, "pending": 0, "overflow": 0}), \
             patch("app.services.hp_service._record_hp_transaction"), \
             patch("app.services.hp_service._safe_update_profile"), \
             patch("app.services.hp_service._get_profile_hp_fields", return_value=profile):
            from app.services.hp_service import earn_pending_hp
            result = earn_pending_hp(STUDENT_ID, 100, "event")

        assert result["added_to_pending"] == 100
        assert result["ceiling_applied"] == 200


class TestSpendHp:
    def test_spend_deducts_from_active(self, app):
        with patch("app.services.hp_service.get_db", return_value=make_mock_db()), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 500}), \
             patch("app.services.hp_service._record_hp_transaction"):
            from app.services.hp_service import spend_hp
            result = spend_hp(STUDENT_ID, 150, ORDER_ID, "reward_redemption")
        assert result["spent"] == 150
        assert result["balance_after"] == 350

    def test_insufficient_hp_raises(self, app):
        with patch("app.services.hp_service.get_db", return_value=make_mock_db()), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 50}):
            from app.services.hp_service import spend_hp
            with pytest.raises(ValueError, match="Insufficient HP"):
                spend_hp(STUDENT_ID, 150, ORDER_ID, "reward_redemption")

    def test_exact_balance_spend_succeeds(self, app):
        with patch("app.services.hp_service.get_db", return_value=make_mock_db()), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 150}), \
             patch("app.services.hp_service._record_hp_transaction"):
            from app.services.hp_service import spend_hp
            result = spend_hp(STUDENT_ID, 150, ORDER_ID, "reward_redemption")
        assert result["balance_after"] == 0


class TestWelcomeBonus:
    def test_50hp_on_first_order(self, app):
        db = make_mock_db({"hp_transactions": []})  # no prior transactions

        with patch("app.services.hp_service.get_db", return_value=db), \
             patch("app.services.hp_service.award_active_hp", return_value={"awarded": 50}) as mock_award:
            from app.services.hp_service import award_welcome_bonus
            result = award_welcome_bonus(STUDENT_ID, ORDER_ID)
        mock_award.assert_called_once()
        assert mock_award.call_args.kwargs["amount"] == 50

    def test_not_awarded_twice(self, app):
        welcome_txn = {**SAMPLE_HP_TXN, "source_type": "welcome"}
        db = make_mock_db({"hp_transactions": [welcome_txn]})

        with patch("app.services.hp_service.get_db", return_value=db):
            from app.services.hp_service import award_welcome_bonus
            result = award_welcome_bonus(STUDENT_ID, ORDER_ID)
        assert result["awarded"] == 0


class TestTierRecalculation:
    def test_ember_to_flame_at_2500(self, app):
        profile = {**SAMPLE_PROFILE, "hp_earned_120day": 2600}
        db = make_mock_db({"profiles": profile, "tiers": SAMPLE_TIERS})

        with patch("app.services.hp_service.get_db", return_value=db), \
             patch("app.services.hp_service._safe_update_profile"):
            from app.services.hp_service import recalculate_tier
            result = recalculate_tier(STUDENT_ID)

        assert result["tier"]["slug"] == "flame"
        assert result["changed"] is True

    def test_blaze_at_7500(self, app):
        profile = {**SAMPLE_PROFILE, "hp_earned_120day": 8000}
        db = make_mock_db({"profiles": profile, "tiers": SAMPLE_TIERS})

        with patch("app.services.hp_service.get_db", return_value=db), \
             patch("app.services.hp_service._safe_update_profile"):
            from app.services.hp_service import recalculate_tier
            result = recalculate_tier(STUDENT_ID)
        assert result["tier"]["slug"] == "blaze"

    def test_holy_at_20000(self, app):
        profile = {**SAMPLE_PROFILE, "hp_earned_120day": 25000}
        db = make_mock_db({"profiles": profile, "tiers": SAMPLE_TIERS})

        with patch("app.services.hp_service.get_db", return_value=db), \
             patch("app.services.hp_service._safe_update_profile"):
            from app.services.hp_service import recalculate_tier
            result = recalculate_tier(STUDENT_ID)
        assert result["tier"]["slug"] == "holy"

    def test_no_change_returns_changed_false(self, app):
        profile = {**SAMPLE_PROFILE, "hp_earned_120day": 100}
        db = make_mock_db({
            "profiles": profile,
            "tiers": SAMPLE_TIERS,
            "user_tiers": [{"id": "x", "tier_id": TIER_EMBER, "is_current": True}],
        })

        with patch("app.services.hp_service.get_db", return_value=db), \
             patch("app.services.hp_service._safe_update_profile"):
            from app.services.hp_service import recalculate_tier
            result = recalculate_tier(STUDENT_ID)
        assert result["changed"] is False


class TestBreakageCalculation:
    def test_25_percent_breakage_on_inactive(self, app):
        db = make_mock_db({"hp_transactions": [
            {"amount": 1000, "status": "active", "created_at": "2020-01-01T00:00:00Z"},
        ]})
        with patch("app.services.hp_service.get_db", return_value=db), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 1000}):
            from app.services.hp_service import calculate_breakage
            result = calculate_breakage(STUDENT_ID, 90)
        assert result["eligible"] is True
        assert result["amount_to_expire"] == 250  # 25% of 1000

    def test_recent_activity_not_eligible(self, app):
        from datetime import datetime, timezone
        now_str = datetime.now(timezone.utc).isoformat()
        db = make_mock_db({"hp_transactions": [
            {"amount": 500, "status": "active", "created_at": now_str},
        ]})
        with patch("app.services.hp_service.get_db", return_value=db), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 500}):
            from app.services.hp_service import calculate_breakage
            result = calculate_breakage(STUDENT_ID, 90)
        assert result["eligible"] is False
