"""Tests for webhook handlers — Paystack charge and transfer events."""

import json
import hmac
import hashlib
import pytest
from unittest.mock import patch, MagicMock
from tests.conftest import make_mock_db, STUDENT_ID, ORDER_ID, SAMPLE_WALLET


def make_paystack_signature(payload: bytes, secret: str) -> str:
    return hmac.new(secret.encode(), payload, hashlib.sha512).hexdigest()


@pytest.fixture(autouse=True)
def mock_db_global(app):
    db = make_mock_db()
    with patch("app.routes.webhooks.get_db", return_value=db):
        yield db


WEBHOOK_SECRET = "mock-webhook-secret"


class TestPaystackChargeSuccess:
    def test_order_payment_confirmation(self, client, app):
        payload = {
            "event": "charge.success",
            "data": {
                "reference": "HG-ORD-ABC123",
                "amount": 350000,
                "metadata": {
                    "type": "order_payment",
                    "user_id": STUDENT_ID,
                    "order_id": ORDER_ID,
                },
            }
        }
        body = json.dumps(payload).encode()
        sig = make_paystack_signature(body, WEBHOOK_SECRET)

        with patch("app.routes.webhooks.confirm_order_payment") as mock_confirm, \
             patch("app.routes.webhooks.send_notification"):
            resp = client.post(
                "/api/webhooks/paystack",
                data=body,
                content_type="application/json",
                headers={"x-paystack-signature": sig},
            )
        assert resp.status_code == 200
        mock_confirm.assert_called_once_with(ORDER_ID, "HG-ORD-ABC123", provider_response=payload["data"])

    def test_wallet_topup_credits_wallet(self, client, app):
        payload = {
            "event": "charge.success",
            "data": {
                "reference": "HG-WALLET-XYZ",
                "amount": 500000,  # ₦5,000
                "metadata": {
                    "type": "wallet_topup",
                    "user_id": STUDENT_ID,
                },
            }
        }
        body = json.dumps(payload).encode()
        sig = make_paystack_signature(body, WEBHOOK_SECRET)

        with patch("app.routes.webhooks.credit_wallet") as mock_credit, \
             patch("app.routes.webhooks.send_notification"):
            resp = client.post(
                "/api/webhooks/paystack",
                data=body,
                content_type="application/json",
                headers={"x-paystack-signature": sig},
            )
        assert resp.status_code == 200
        mock_credit.assert_called_once()
        call_kwargs = mock_credit.call_args.kwargs
        assert call_kwargs["user_id"] == STUDENT_ID
        assert call_kwargs["amount"] == 5000.0

    def test_invalid_signature_rejected(self, client, app):
        payload = json.dumps({"event": "charge.success", "data": {}}).encode()
        resp = client.post(
            "/api/webhooks/paystack",
            data=payload,
            content_type="application/json",
            headers={"x-paystack-signature": "bad-sig"},
        )
        assert resp.status_code == 401

    def test_duplicate_webhook_ignored(self, client, app):
        """Idempotency: same reference processed twice should return 200 without re-processing"""
        payload = {
            "event": "charge.success",
            "data": {"reference": "DUPE-REF", "amount": 100000, "metadata": {}}
        }
        body = json.dumps(payload).encode()
        sig = make_paystack_signature(body, WEBHOOK_SECRET)

        # Mock webhook_events to return an existing record (already processed)
        db = make_mock_db({"webhook_events": [{"id": "existing-event"}]})
        with patch("app.routes.webhooks.get_db", return_value=db):
            resp = client.post(
                "/api/webhooks/paystack",
                data=body,
                content_type="application/json",
                headers={"x-paystack-signature": sig},
            )
        assert resp.status_code == 200
        assert "Already processed" in resp.get_json()["message"]

    def test_invalid_json_returns_400(self, client, app):
        body = b"not-json"
        sig = make_paystack_signature(body, WEBHOOK_SECRET)
        resp = client.post(
            "/api/webhooks/paystack",
            data=body,
            content_type="application/json",
            headers={"x-paystack-signature": sig},
        )
        assert resp.status_code == 400


class TestPaystackTransfer:
    def test_bank_transfer_credits_wallet(self, client, app):
        payload = {
            "event": "transfer.success",
            "data": {
                "reference": "TRF-001",
                "amount": 300000,  # ₦3,000
                "recipient": {
                    "details": {"account_number": "0123456789"}
                }
            }
        }
        body = json.dumps(payload).encode()
        sig = make_paystack_signature(body, WEBHOOK_SECRET)

        wallet_db = make_mock_db({"wallets": SAMPLE_WALLET, "webhook_events": []})
        with patch("app.routes.webhooks.get_db", return_value=wallet_db), \
             patch("app.routes.webhooks.credit_wallet") as mock_credit, \
             patch("app.routes.webhooks.send_notification"):
            resp = client.post(
                "/api/webhooks/paystack",
                data=body,
                content_type="application/json",
                headers={"x-paystack-signature": sig},
            )
        assert resp.status_code == 200
        mock_credit.assert_called_once()
        assert mock_credit.call_args.kwargs["amount"] == 3000.0
