"""Unit tests for Order Service — order creation, payment confirmation, status transitions."""

import pytest
from unittest.mock import patch, MagicMock, call
from tests.conftest import (
    make_mock_db, STUDENT_ID, ORDER_ID, MENU_ITEM_ID, WINDOW_ID,
    SAMPLE_ORDER, SAMPLE_MENU_ITEM, SAMPLE_WINDOW
)


@pytest.fixture(autouse=True)
def flask_ctx(app):
    with app.app_context():
        yield


VALID_PAYLOAD = {
    "items": [{"menu_item_id": MENU_ITEM_ID, "quantity": 1}],
    "delivery_window_id": WINDOW_ID,
    "payment_method": "card",
    "delivery_address": {"address_line": "Block A, FUTA Main Campus", "zone": "main"},
}


class TestCreateOrder:
    def test_creates_order_with_correct_subtotal(self, app):
        db = make_mock_db({
            "delivery_windows": SAMPLE_WINDOW,
            "menu_items": SAMPLE_MENU_ITEM,
            "orders": SAMPLE_ORDER,
            "order_items": [],
        })
        with patch("app.services.order_service.get_db", return_value=db), \
             patch("app.services.order_service.send_notification"):
            from app.services.order_service import create_order
            result = create_order(STUDENT_ID, VALID_PAYLOAD)
        assert result["subtotal"] == 3500.0
        assert result["total"] == 3500.0

    def test_status_is_pending_payment(self, app):
        db = make_mock_db({
            "delivery_windows": SAMPLE_WINDOW,
            "menu_items": SAMPLE_MENU_ITEM,
            "orders": SAMPLE_ORDER,
        })
        with patch("app.services.order_service.get_db", return_value=db), \
             patch("app.services.order_service.send_notification"):
            from app.services.order_service import create_order
            result = create_order(STUDENT_ID, VALID_PAYLOAD)
        assert result["status"] == "pending_payment"

    def test_empty_items_raises(self, app):
        db = make_mock_db()
        with patch("app.services.order_service.get_db", return_value=db):
            from app.services.order_service import create_order
            with pytest.raises(ValueError, match="at least one item"):
                create_order(STUDENT_ID, {**VALID_PAYLOAD, "items": []})

    def test_unavailable_item_raises(self, app):
        unavailable = {**SAMPLE_MENU_ITEM, "is_available": False}
        db = make_mock_db({
            "delivery_windows": SAMPLE_WINDOW,
            "menu_items": unavailable,
        })
        with patch("app.services.order_service.get_db", return_value=db):
            from app.services.order_service import create_order
            with pytest.raises(ValueError, match="not currently available"):
                create_order(STUDENT_ID, VALID_PAYLOAD)

    def test_archived_item_raises(self, app):
        archived = {**SAMPLE_MENU_ITEM, "is_archived": True}
        db = make_mock_db({
            "delivery_windows": SAMPLE_WINDOW,
            "menu_items": archived,
        })
        with patch("app.services.order_service.get_db", return_value=db):
            from app.services.order_service import create_order
            with pytest.raises(ValueError, match="not currently available"):
                create_order(STUDENT_ID, VALID_PAYLOAD)

    def test_closed_window_raises(self, app):
        closed_window = {**SAMPLE_WINDOW, "status": "closed"}
        db = make_mock_db({"delivery_windows": closed_window})
        with patch("app.services.order_service.get_db", return_value=db):
            from app.services.order_service import create_order
            with pytest.raises(ValueError, match="not open"):
                create_order(STUDENT_ID, VALID_PAYLOAD)

    def test_hp_discount_applied(self, app):
        """300 HP × ₦0.185 = ₦55.5 discount"""
        db = make_mock_db({
            "delivery_windows": SAMPLE_WINDOW,
            "menu_items": SAMPLE_MENU_ITEM,
            "orders": SAMPLE_ORDER,
        })
        payload = {**VALID_PAYLOAD, "hp_points_to_redeem": 300}
        with patch("app.services.order_service.get_db", return_value=db), \
             patch("app.services.order_service.send_notification"):
            from app.services.order_service import create_order
            result = create_order(STUDENT_ID, payload)
        assert result["hp_discount"] == round(300 * 0.185, 2)
        assert result["hp_points_used"] == 300

    def test_wallet_payment_sets_wallet_amount(self, app):
        db = make_mock_db({
            "delivery_windows": SAMPLE_WINDOW,
            "menu_items": SAMPLE_MENU_ITEM,
            "orders": SAMPLE_ORDER,
        })
        payload = {**VALID_PAYLOAD, "payment_method": "wallet"}
        with patch("app.services.order_service.get_db", return_value=db), \
             patch("app.services.order_service.send_notification"):
            from app.services.order_service import create_order
            result = create_order(STUDENT_ID, payload)
        assert result["wallet_amount_used"] == result["total"]
        assert result["card_amount_used"] == 0.0

    def test_split_payment_splits_correctly(self, app):
        db = make_mock_db({
            "delivery_windows": SAMPLE_WINDOW,
            "menu_items": SAMPLE_MENU_ITEM,
            "orders": SAMPLE_ORDER,
        })
        payload = {**VALID_PAYLOAD, "payment_method": "split", "wallet_amount": 1000.0}
        with patch("app.services.order_service.get_db", return_value=db), \
             patch("app.services.order_service.send_notification"):
            from app.services.order_service import create_order
            result = create_order(STUDENT_ID, payload)
        assert result["wallet_amount_used"] == 1000.0
        assert result["card_amount_used"] == result["total"] - 1000.0

    def test_multiple_items_subtotal_correct(self, app):
        """2x ₦3,500 item = ₦7,000 subtotal"""
        db = make_mock_db({
            "delivery_windows": SAMPLE_WINDOW,
            "menu_items": SAMPLE_MENU_ITEM,
            "orders": {**SAMPLE_ORDER, "subtotal": 7000.0, "total": 7000.0},
        })
        payload = {**VALID_PAYLOAD, "items": [{"menu_item_id": MENU_ITEM_ID, "quantity": 2}]}
        with patch("app.services.order_service.get_db", return_value=db), \
             patch("app.services.order_service.send_notification"):
            from app.services.order_service import create_order
            result = create_order(STUDENT_ID, payload)
        assert result["subtotal"] == 7000.0


class TestConfirmOrderPayment:
    def test_transitions_to_received(self, app):
        order = {**SAMPLE_ORDER, "status": "pending_payment", "hp_points_used": 0, "wallet_amount_used": 0}
        db = make_mock_db({"orders": order})

        with patch("app.services.order_service.get_db", return_value=db), \
             patch("app.services.order_service.send_notification"), \
             patch("app.services.order_service._log_status_change"):
            from app.services.order_service import confirm_order_payment
            result = confirm_order_payment(ORDER_ID, "PAY_REF_001")
        assert result["status"] == "received"

    def test_idempotent_on_already_received(self, app):
        order = {**SAMPLE_ORDER, "status": "received"}
        db = make_mock_db({"orders": order})

        with patch("app.services.order_service.get_db", return_value=db), \
             patch("app.services.order_service.send_notification"):
            from app.services.order_service import confirm_order_payment
            result = confirm_order_payment(ORDER_ID, "PAY_REF_001")
        assert result["status"] == "received"

    def test_hp_deducted_on_confirmation(self, app):
        order = {**SAMPLE_ORDER, "status": "pending_payment", "hp_points_used": 100, "wallet_amount_used": 0}
        db = make_mock_db({"orders": order})

        with patch("app.services.order_service.get_db", return_value=db), \
             patch("app.services.order_service.send_notification"), \
             patch("app.services.order_service._log_status_change"), \
             patch("app.services.order_service.hp_service.spend_hp") as mock_spend:
            from app.services.order_service import confirm_order_payment
            confirm_order_payment(ORDER_ID, "PAY_REF_002")
        mock_spend.assert_called_once()
        assert mock_spend.call_args.kwargs["amount"] == 100

    def test_wallet_debited_on_confirmation(self, app):
        order = {**SAMPLE_ORDER, "status": "pending_payment", "hp_points_used": 0, "wallet_amount_used": 1500.0}
        db = make_mock_db({"orders": order})

        with patch("app.services.order_service.get_db", return_value=db), \
             patch("app.services.order_service.send_notification"), \
             patch("app.services.order_service._log_status_change"), \
             patch("app.services.order_service.debit_wallet") as mock_debit:
            from app.services.order_service import confirm_order_payment
            confirm_order_payment(ORDER_ID, "PAY_REF_003")
        mock_debit.assert_called_once_with(
            user_id=STUDENT_ID,
            amount=1500.0,
            reference_id=ORDER_ID,
            reference_type="order",
            notes=pytest.approx("Wallet payment for order BBBBBBBB", abs=1),
        )


class TestUpdateOrderStatus:
    @pytest.mark.parametrize("from_s,to_s", [
        ("received", "preparing"),
        ("preparing", "ready"),
        ("ready", "dispatched"),
        ("dispatched", "delivered"),
    ])
    def test_valid_transitions(self, app, from_s, to_s):
        order = {**SAMPLE_ORDER, "status": from_s, "user_id": None}
        db = make_mock_db({"orders": order})

        with patch("app.services.order_service.get_db", return_value=db), \
             patch("app.services.order_service._log_status_change"), \
             patch("app.services.order_service.send_notification"), \
             patch("app.services.order_service._handle_delivery_rewards"):
            from app.services.order_service import update_order_status
            result = update_order_status(ORDER_ID, to_s, "actor_id")
        assert result["status"] == to_s

    @pytest.mark.parametrize("from_s,bad_to", [
        ("pending_payment", "delivered"),
        ("received", "dispatched"),
        ("delivered", "cancelled"),
        ("cancelled", "received"),
    ])
    def test_invalid_transitions_raise(self, app, from_s, bad_to):
        order = {**SAMPLE_ORDER, "status": from_s}
        db = make_mock_db({"orders": order})

        with patch("app.services.order_service.get_db", return_value=db):
            from app.services.order_service import update_order_status
            with pytest.raises(ValueError, match="Cannot transition"):
                update_order_status(ORDER_ID, bad_to)

    def test_hp_awarded_on_delivery(self, app):
        order = {**SAMPLE_ORDER, "status": "dispatched", "user_id": STUDENT_ID}
        db = make_mock_db({"orders": order})

        with patch("app.services.order_service.get_db", return_value=db), \
             patch("app.services.order_service._log_status_change"), \
             patch("app.services.order_service.send_notification"), \
             patch("app.services.order_service._handle_delivery_rewards") as mock_hp:
            from app.services.order_service import update_order_status
            update_order_status(ORDER_ID, "delivered", STUDENT_ID)
        mock_hp.assert_called_once()

    def test_order_not_found_raises(self, app):
        db = make_mock_db({"orders": None})

        with patch("app.services.order_service.get_db", return_value=db):
            from app.services.order_service import update_order_status
            with pytest.raises(ValueError, match="not found"):
                update_order_status("nonexistent-id", "received")
