"""API tests for /api/hp endpoints."""

import pytest
from unittest.mock import patch
from tests.conftest import (
    make_mock_db, STUDENT_ID, ORDER_ID, SAMPLE_PROFILE,
    SAMPLE_TIERS, SAMPLE_HP_TXN, admin_token
)


@pytest.fixture(autouse=True)
def mock_db_auth(app):
    db = make_mock_db()
    with patch("app.middleware.auth.get_db", return_value=db):
        yield db


class TestHpBalance:
    def test_balance_returns_breakdown(self, client, auth_headers):
        balance = {"active": 500, "pending": 75, "overflow": 0, "total_visible": 575}
        tier_info = {"tier": {"name": "Ember", "slug": "ember"}, "is_in_grace_period": False}
        with patch("app.routes.hp.get_hp_balance", return_value=balance), \
             patch("app.routes.hp.get_user_tier", return_value=tier_info):
            resp = client.get("/api/hp/balance", headers=auth_headers)
        assert resp.status_code == 200
        data = resp.get_json()
        assert data["active"] == 500
        assert data["pending"] == 75
        assert "tier" in data

    def test_balance_requires_auth(self, client):
        resp = client.get("/api/hp/balance")
        assert resp.status_code == 401


class TestHpTransactions:
    def test_returns_list(self, client, auth_headers):
        db = make_mock_db({"hp_transactions": [SAMPLE_HP_TXN]})
        with patch("app.middleware.auth.get_db", return_value=db), \
             patch("app.routes.hp.get_db", return_value=db):
            resp = client.get("/api/hp/transactions", headers=auth_headers)
        assert resp.status_code == 200
        assert isinstance(resp.get_json(), list)

    def test_pagination_params(self, client, auth_headers):
        db = make_mock_db({"hp_transactions": [SAMPLE_HP_TXN]})
        with patch("app.middleware.auth.get_db", return_value=db), \
             patch("app.routes.hp.get_db", return_value=db):
            resp = client.get("/api/hp/transactions?limit=10&offset=0", headers=auth_headers)
        assert resp.status_code == 200

    def test_type_filter(self, client, auth_headers):
        db = make_mock_db({"hp_transactions": [SAMPLE_HP_TXN]})
        with patch("app.middleware.auth.get_db", return_value=db), \
             patch("app.routes.hp.get_db", return_value=db):
            resp = client.get("/api/hp/transactions?type=earn", headers=auth_headers)
        assert resp.status_code == 200


class TestListTiers:
    def test_tiers_public_endpoint(self, client):
        db = make_mock_db({"tiers": SAMPLE_TIERS})
        with patch("app.routes.hp.get_db", return_value=db):
            resp = client.get("/api/hp/tiers")
        assert resp.status_code == 200
        data = resp.get_json()
        assert len(data) == 4
        slugs = [t["slug"] for t in data]
        assert "ember" in slugs
        assert "flame" in slugs
        assert "blaze" in slugs
        assert "holy" in slugs


class TestAdminGrantHp:
    def test_admin_can_grant_hp(self, client, admin_headers):
        db = make_mock_db({"profiles": {**SAMPLE_PROFILE, "id": "aaaaaaaa-0000-0000-0000-000000000002", "role": "admin"}})
        with patch("app.middleware.auth.get_db", return_value=db), \
             patch("app.routes.hp.award_active_hp", return_value={"awarded": 200}):
            resp = client.post("/api/hp/admin/grant", json={
                "user_id": STUDENT_ID, "amount": 200, "notes": "Compensation"
            }, headers=admin_headers)
        assert resp.status_code == 200
        assert resp.get_json()["awarded"] == 200

    def test_student_cannot_grant_hp(self, client, auth_headers):
        resp = client.post("/api/hp/admin/grant", json={
            "user_id": STUDENT_ID, "amount": 100
        }, headers=auth_headers)
        assert resp.status_code == 403

    def test_missing_fields_returns_400(self, client, admin_headers):
        db = make_mock_db({"profiles": {**SAMPLE_PROFILE, "id": "aaaaaaaa-0000-0000-0000-000000000002", "role": "admin"}})
        with patch("app.middleware.auth.get_db", return_value=db):
            resp = client.post("/api/hp/admin/grant", json={"amount": 100}, headers=admin_headers)
        assert resp.status_code == 400
