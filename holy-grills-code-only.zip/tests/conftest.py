"""
Test fixtures and shared mocks for the Holy Grills backend test suite.
All Supabase calls are mocked — no live network connections required.
"""

import os
import pytest
import jwt
from unittest.mock import MagicMock, patch, PropertyMock
from datetime import datetime, timezone, timedelta

# Set env vars BEFORE importing app
os.environ.update({
    "FLASK_ENV": "testing",
    "SUPABASE_URL": "https://mock.supabase.co",
    "SUPABASE_SERVICE_ROLE_KEY": "mock-service-role-key",
    "SUPABASE_ANON_KEY": "mock-anon-key",
    "JWT_SECRET": "test-jwt-secret-32-chars-minimum-x",
    "SECRET_KEY": "test-secret-key-32-chars-minimum-xx",
    "PAYSTACK_SECRET_KEY": "sk_test_mock",
    "PAYSTACK_WEBHOOK_SECRET": "mock-webhook-secret",
})

from app import create_app
from app.config import DevelopmentConfig


# ---------------------------------------------------------------------------
# Rate-limit isolation: clear the in-memory counter before every test so
# tests that POST to /api/orders don't exhaust the 10-req window for later tests.
# ---------------------------------------------------------------------------
@pytest.fixture(autouse=True)
def _clear_rate_limit_counts():
    from app.middleware.rate_limit import _request_counts
    _request_counts.clear()
    yield
    _request_counts.clear()


# ---------------------------------------------------------------------------
# Fixtures: IDs
# ---------------------------------------------------------------------------
STUDENT_ID   = "aaaaaaaa-0000-0000-0000-000000000001"
ADMIN_ID     = "aaaaaaaa-0000-0000-0000-000000000002"
KITCHEN_ID   = "aaaaaaaa-0000-0000-0000-000000000003"
RIDER_ID     = "aaaaaaaa-0000-0000-0000-000000000004"
ORDER_ID     = "bbbbbbbb-0000-0000-0000-000000000001"
MENU_ITEM_ID = "cccccccc-0000-0000-0000-000000000001"
WINDOW_ID    = "dddddddd-0000-0000-0000-000000000001"
REWARD_ID    = "eeeeeeee-0000-0000-0000-000000000001"
TIER_EMBER   = "00000000-0000-0000-0000-000000000001"
TIER_FLAME   = "00000000-0000-0000-0000-000000000002"
TIER_BLAZE   = "00000000-0000-0000-0000-000000000003"
TIER_HOLY    = "00000000-0000-0000-0000-000000000004"
WALLET_ID    = "ffffffff-0000-0000-0000-000000000001"


def make_jwt(user_id: str, role: str = "student") -> str:
    """Generate a test JWT matching Supabase format."""
    payload = {
        "sub": user_id,
        "role": role,
        "email": f"{role}@test.com",
        "aud": "authenticated",
        "exp": int((datetime.now(timezone.utc) + timedelta(hours=1)).timestamp()),
        "iat": int(datetime.now(timezone.utc).timestamp()),
    }
    return jwt.encode(payload, os.environ["JWT_SECRET"], algorithm="HS256")


def student_token() -> str:
    return make_jwt(STUDENT_ID, "student")


def admin_token() -> str:
    return make_jwt(ADMIN_ID, "admin")


def kitchen_token() -> str:
    return make_jwt(KITCHEN_ID, "kitchen")


def rider_token() -> str:
    return make_jwt(RIDER_ID, "rider")


# ---------------------------------------------------------------------------
# Sample DB objects
# ---------------------------------------------------------------------------
SAMPLE_PROFILE = {
    "id": STUDENT_ID,
    "full_name": "Test Student",
    "phone": "08012345678",
    "role": "student",
    "is_active": True,
    "referral_code": "TES12345",
    "referred_by": None,
    "pending_hp_balance": 0,
    "hp_overflow": 0,
    "monthly_hp_earned": 0,
    "hp_earned_120day": 0,
    "tier_bonus_multiplier": 1.0,
    "date_of_birth": "2000-01-15",
    "email_notifications": True,
    "push_enabled": False,
}

SAMPLE_ADMIN_PROFILE = {**SAMPLE_PROFILE, "id": ADMIN_ID, "role": "admin", "full_name": "Admin User"}
SAMPLE_KITCHEN_PROFILE = {**SAMPLE_PROFILE, "id": KITCHEN_ID, "role": "kitchen", "full_name": "Kitchen Staff"}
SAMPLE_RIDER_PROFILE = {**SAMPLE_PROFILE, "id": RIDER_ID, "role": "rider", "full_name": "Rider One"}

SAMPLE_ORDER = {
    "id": ORDER_ID,
    "user_id": STUDENT_ID,
    "status": "pending_payment",
    "subtotal": 3500.0,
    "delivery_fee": 0.0,
    "promo_discount": 0.0,
    "hp_discount": 0.0,
    "total": 3500.0,
    "payment_method": "card",
    "wallet_amount_used": 0.0,
    "card_amount_used": 3500.0,
    "hp_points_used": 0,
    "hp_earned": 0,
    "tier_bonus_hp": 0,
    "unlocked_pending_hp": 0,
    "delivery_window_id": WINDOW_ID,
    "order_notes": "",
    "review_submitted": False,
    "claim_token": None,
    "version": 1,
    "created_at": "2026-05-01T10:00:00Z",
    "updated_at": "2026-05-01T10:00:00Z",
}

SAMPLE_DELIVERED_ORDER = {**SAMPLE_ORDER, "status": "delivered", "delivered_at": "2026-05-01T12:00:00Z"}

SAMPLE_MENU_ITEM = {
    "id": MENU_ITEM_ID,
    "name": "Holy Grilled Chicken",
    "slug": "holy-grilled-chicken",
    "price": 3500.0,
    "hp_earn_value": 35,
    "is_available": True,
    "is_archived": False,
    "category_id": "10000000-0000-0000-0000-000000000001",
}

SAMPLE_WINDOW = {
    "id": WINDOW_ID,
    "label": "Lunch 12:00–14:00",
    "opens_at": "2026-05-01T09:00:00Z",
    "closes_at": "2026-05-01T14:00:00Z",
    "status": "open",
}

SAMPLE_WALLET = {
    "id": WALLET_ID,
    "user_id": STUDENT_ID,
    "balance": 5000.0,
    "currency": "NGN",
    "virtual_account_number": "0123456789",
    "virtual_account_bank": "Wema Bank",
}

SAMPLE_REWARD = {
    "id": REWARD_ID,
    "name": "Free Puff Puff",
    "slug": "free-puff-puff",
    "hp_cost": 150,
    "category": "food",
    "is_active": True,
    "quantity_available": 100,
    "quantity_redeemed": 0,
    "min_tier_id": None,
    "starts_at": None,
    "ends_at": None,
}

SAMPLE_TIERS = [
    {"id": TIER_EMBER, "name": "Ember", "slug": "ember", "min_hp_threshold": 0,     "sort_order": 1, "earn_multiplier": 1.00, "badge_color_hex": "#F97316"},
    {"id": TIER_FLAME, "name": "Flame", "slug": "flame", "min_hp_threshold": 2500,  "sort_order": 2, "earn_multiplier": 1.08, "badge_color_hex": "#EF4444"},
    {"id": TIER_BLAZE, "name": "Blaze", "slug": "blaze", "min_hp_threshold": 7500,  "sort_order": 3, "earn_multiplier": 1.15, "badge_color_hex": "#7C3AED"},
    {"id": TIER_HOLY,  "name": "Holy",  "slug": "holy",  "min_hp_threshold": 20000, "sort_order": 4, "earn_multiplier": 1.25, "badge_color_hex": "#F59E0B"},
]

SAMPLE_HP_TXN = {
    "id": "hptx0000-0000-0000-0000-000000000001",
    "user_id": STUDENT_ID,
    "amount": 350,
    "type": "earn",
    "source_type": "food",
    "status": "active",
    "reference_type": "order",
    "balance_after": 350,
    "created_at": "2026-05-01T12:00:00Z",
}


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

class MockTableQuery:
    """
    Chainable mock for db.table('x').select(...).eq(...).execute()

    Key design decisions:
    - select() resets _is_single so each new chain starts clean.
    - execute() resets _is_single after returning so the cached instance
      is ready for the next call chain.
    - insert/update/delete are regular methods that can be replaced per-test
      with lambdas on the cached instance returned by make_mock_db.
    """
    def __init__(self, return_value=None):
        self._return = return_value if return_value is not None else []
        self._is_single = False

    def select(self, *a, **kw):
        self._is_single = False  # reset at the start of every new chain
        return self

    def eq(self, *a, **kw): return self
    def neq(self, *a, **kw): return self
    def gte(self, *a, **kw): return self
    def lte(self, *a, **kw): return self
    def gt(self, *a, **kw): return self
    def lt(self, *a, **kw): return self
    def ilike(self, *a, **kw): return self
    def in_(self, *a, **kw): return self
    def is_(self, *a, **kw): return self
    def order(self, *a, **kw): return self
    def limit(self, *a, **kw): return self
    def offset(self, *a, **kw): return self
    def with_jwt(self, *a, **kw): return self

    def update(self, data):
        return [data] if not self._is_single else data

    def insert(self, data):
        import uuid as _uuid
        if isinstance(data, list):
            return [({**d, "id": d.get("id", str(_uuid.uuid4()))} if isinstance(d, dict) else d) for d in data]
        if isinstance(data, dict) and "id" not in data:
            return [{**data, "id": str(_uuid.uuid4())}]
        return [data]

    def delete(self): return []

    def upsert(self, data, **kw): return [data] if isinstance(data, dict) else data

    def single(self):
        self._is_single = True
        return self

    def execute(self):
        if self._is_single:
            if isinstance(self._return, list):
                result = self._return[0] if self._return else None
            else:
                result = self._return
        else:
            result = self._return if isinstance(self._return, list) else [self._return]
        self._is_single = False  # reset so the next chain on this cached instance starts fresh
        return result


def make_mock_db(overrides: dict = None):
    """
    Build a mock SupabaseClient with configurable per-table return values.

    MockTableQuery instances are cached per table name so that per-test
    attribute patches (e.g. db.table("hp_transactions").insert = lambda d: ...)
    persist across all calls to db.table() for the same table within a test.
    """
    overrides = overrides or {}
    defaults = {
        "profiles":         SAMPLE_PROFILE,
        "orders":           SAMPLE_ORDER,
        "order_items":      [],
        "hp_transactions":  [SAMPLE_HP_TXN],
        "wallets":          SAMPLE_WALLET,
        "wallet_transactions": [],
        "menu_items":       SAMPLE_MENU_ITEM,
        "menu_categories":  [],
        "tiers":            SAMPLE_TIERS,
        "user_tiers":       [{"tier_id": TIER_EMBER, "is_current": True, "is_in_grace_period": False, "achieved_at": "2026-01-01T00:00:00Z"}],
        "notifications":    [],
        "rewards":          SAMPLE_REWARD,
        "reward_redemptions": [],
        "delivery_windows": SAMPLE_WINDOW,
        "order_status_log": [],
        "referrals":        [],
        "challenges":       [],
        "challenge_completions": [],
        "events":           [],
        "event_checkins":   [],
        "promo_codes":      [],
        "promo_code_uses":  [],
        "marketplace_listings": [],
        "marketplace_codes": [],
        "marketplace_purchases": [],
        "admin_audit_log":  [],
        "webhook_events":   [],
        "abandoned_carts":  [],
        "leaderboard_snapshots": [],
        "storefront_sections": [],
        "operating_hours":  [],
        "operating_hour_overrides": None,
        "flash_redemptions": [],
        "hp_bundle_purchases": [],
        "pending_hp_transactions": [],
        "hp_unlock_log":    [],
        "delivery_batches": [],
    }
    data = {**defaults, **overrides}

    # Cache instances so per-test .insert/.update/.delete patches persist
    table_cache: dict = {}

    def table_factory(table_name):
        if table_name not in table_cache:
            val = data.get(table_name, [])
            table_cache[table_name] = MockTableQuery(val)
        return table_cache[table_name]

    mock_db = MagicMock()
    mock_db.table.side_effect = table_factory
    mock_db.rpc.return_value = {"active": 350, "pending": 0, "overflow": 0}
    return mock_db


@pytest.fixture
def app():
    app = create_app(DevelopmentConfig)
    app.config["TESTING"] = True
    app.config["JWT_SECRET"] = os.environ["JWT_SECRET"]
    return app


@pytest.fixture
def client(app):
    return app.test_client()


@pytest.fixture
def mock_db():
    return make_mock_db()


@pytest.fixture
def auth_headers():
    return {"Authorization": f"Bearer {student_token()}", "Content-Type": "application/json"}


@pytest.fixture
def admin_headers():
    return {"Authorization": f"Bearer {admin_token()}", "Content-Type": "application/json"}


@pytest.fixture
def kitchen_headers():
    return {"Authorization": f"Bearer {kitchen_token()}", "Content-Type": "application/json"}


@pytest.fixture
def rider_headers():
    return {"Authorization": f"Bearer {rider_token()}", "Content-Type": "application/json"}
