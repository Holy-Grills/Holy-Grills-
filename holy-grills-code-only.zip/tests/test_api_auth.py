"""API tests for /api/auth endpoints."""

import json
import pytest
from unittest.mock import patch
from tests.conftest import (
    make_mock_db, STUDENT_ID, SAMPLE_PROFILE, student_token
)


@pytest.fixture(autouse=True)
def mock_db_globally(app):
    db = make_mock_db()
    with patch("app.middleware.auth.get_db", return_value=db), \
         patch("app.db.get_db", return_value=db):
        yield db


class TestRegister:
    def test_register_success(self, client):
        auth_result = {
            "user": {"id": STUDENT_ID, "email": "student@futa.edu.ng"},
            "access_token": "tok_access",
            "refresh_token": "tok_refresh",
        }
        with patch("app.routes.auth.auth_service.register", return_value=auth_result):
            resp = client.post("/api/auth/register", json={
                "email": "student@futa.edu.ng",
                "password": "Secure1234",
                "full_name": "Test Student",
            })
        assert resp.status_code == 201
        data = resp.get_json()
        assert "access_token" in data or "user" in data

    def test_register_missing_fields(self, client):
        resp = client.post("/api/auth/register", json={"email": "x@y.com"})
        assert resp.status_code == 400
        assert "error" in resp.get_json()

    def test_register_short_password(self, client):
        resp = client.post("/api/auth/register", json={
            "email": "x@y.com", "password": "abc", "full_name": "X Y"
        })
        assert resp.status_code == 400
        assert "8 characters" in resp.get_json()["error"]

    def test_register_with_referral_code(self, client):
        auth_result = {"user": {"id": STUDENT_ID}, "access_token": "tok"}
        with patch("app.routes.auth.auth_service.register", return_value=auth_result) as mock_reg:
            client.post("/api/auth/register", json={
                "email": "new@test.com",
                "password": "Password1",
                "full_name": "New User",
                "referred_by_code": "TES12345",
            })
        mock_reg.assert_called_once()
        assert mock_reg.call_args.kwargs["referred_by_code"] == "TES12345"


class TestLogin:
    def test_login_success(self, client):
        login_result = {"access_token": "tok_access", "refresh_token": "tok_refresh"}
        with patch("app.routes.auth.auth_service.login", return_value=login_result):
            resp = client.post("/api/auth/login", json={
                "email": "student@futa.edu.ng",
                "password": "Secure1234",
            })
        assert resp.status_code == 200
        assert "access_token" in resp.get_json()

    def test_login_invalid_credentials(self, client):
        with patch("app.routes.auth.auth_service.login", side_effect=ValueError("Invalid credentials")):
            resp = client.post("/api/auth/login", json={
                "email": "bad@test.com", "password": "wrong"
            })
        assert resp.status_code == 401

    def test_login_missing_fields(self, client):
        resp = client.post("/api/auth/login", json={"email": "x@y.com"})
        assert resp.status_code == 400


class TestMe:
    def test_me_returns_profile(self, client, auth_headers):
        user_data = {
            "id": STUDENT_ID,
            "email": "student@test.com",
            "profile": SAMPLE_PROFILE,
            "wallet_balance": 5000.0,
            "tier": {"tier": {"name": "Ember", "slug": "ember"}, "is_in_grace_period": False},
        }
        db = make_mock_db()
        with patch("app.middleware.auth.get_db", return_value=db), \
             patch("app.routes.auth.auth_service.get_current_user", return_value=user_data):
            resp = client.get("/api/auth/me", headers=auth_headers)
        assert resp.status_code == 200
        data = resp.get_json()
        assert data["id"] == STUDENT_ID

    def test_me_requires_auth(self, client):
        resp = client.get("/api/auth/me")
        assert resp.status_code == 401

    def test_me_with_expired_token(self, client):
        import jwt, os
        from datetime import datetime, timezone, timedelta
        expired = jwt.encode(
            {"sub": STUDENT_ID, "exp": int((datetime.now(timezone.utc) - timedelta(hours=1)).timestamp())},
            os.environ["JWT_SECRET"], algorithm="HS256"
        )
        resp = client.get("/api/auth/me", headers={"Authorization": f"Bearer {expired}"})
        assert resp.status_code == 401


class TestUpdateProfile:
    def test_update_full_name(self, client, auth_headers):
        updated = {**SAMPLE_PROFILE, "full_name": "Updated Name"}
        db = make_mock_db()
        with patch("app.middleware.auth.get_db", return_value=db), \
             patch("app.routes.auth.auth_service.update_profile", return_value=updated):
            resp = client.patch("/api/auth/profile", json={"full_name": "Updated Name"}, headers=auth_headers)
        assert resp.status_code == 200

    def test_update_push_enabled(self, client, auth_headers):
        db = make_mock_db()
        with patch("app.middleware.auth.get_db", return_value=db), \
             patch("app.routes.auth.auth_service.update_profile", return_value=SAMPLE_PROFILE):
            resp = client.patch("/api/auth/profile", json={"push_enabled": True}, headers=auth_headers)
        assert resp.status_code == 200


class TestRefreshToken:
    def test_refresh_returns_new_token(self, client):
        with patch("app.routes.auth.auth_service.refresh_token", return_value={"access_token": "new_tok"}):
            resp = client.post("/api/auth/refresh", json={"refresh_token": "old_refresh"})
        assert resp.status_code == 200
        assert "access_token" in resp.get_json()

    def test_refresh_missing_token(self, client):
        resp = client.post("/api/auth/refresh", json={})
        assert resp.status_code == 400


class TestLogout:
    def test_logout_success(self, client, auth_headers):
        db = make_mock_db()
        with patch("app.middleware.auth.get_db", return_value=db), \
             patch("app.routes.auth.auth_service.logout"):
            resp = client.post("/api/auth/logout", headers=auth_headers)
        assert resp.status_code == 200

    def test_logout_requires_auth(self, client):
        resp = client.post("/api/auth/logout")
        assert resp.status_code == 401


class TestResetPassword:
    def test_reset_password_any_email(self, client):
        with patch("app.routes.auth.auth_service.reset_password_request",
                   return_value={"message": "Password reset email sent if account exists"}):
            resp = client.post("/api/auth/reset-password", json={"email": "any@test.com"})
        assert resp.status_code == 200

    def test_reset_password_missing_email(self, client):
        resp = client.post("/api/auth/reset-password", json={})
        assert resp.status_code == 400
