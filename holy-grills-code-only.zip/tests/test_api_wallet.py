"""API tests for /api/wallet endpoints."""

import pytest
from unittest.mock import patch
from tests.conftest import make_mock_db, STUDENT_ID, SAMPLE_PROFILE, SAMPLE_WALLET


@pytest.fixture(autouse=True)
def mock_db_auth(app):
    db = make_mock_db()
    with patch("app.middleware.auth.get_db", return_value=db):
        yield db


class TestWalletBalance:
    def test_returns_balance(self, client, auth_headers):
        with patch("app.routes.wallet.get_wallet", return_value=SAMPLE_WALLET):
            resp = client.get("/api/wallet", headers=auth_headers)
        assert resp.status_code == 200
        data = resp.get_json()
        assert data["balance"] == 5000.0
        assert data["currency"] == "NGN"
        assert "virtual_account_number" in data

    def test_requires_auth(self, client):
        resp = client.get("/api/wallet")
        assert resp.status_code == 401

    def test_missing_wallet_returns_404(self, client, auth_headers):
        with patch("app.routes.wallet.get_wallet", return_value=None):
            resp = client.get("/api/wallet", headers=auth_headers)
        assert resp.status_code == 404


class TestFundViaCard:
    def test_initialize_card_payment(self, client, auth_headers):
        paystack_result = {
            "authorization_url": "https://paystack.com/pay/abc123",
            "access_code": "abc123",
            "reference": "HG-WALLET-ABCD1234",
        }
        db = make_mock_db()
        with patch("app.middleware.auth.get_db", return_value=db), \
             patch("app.routes.wallet.get_db", return_value=db), \
             patch("app.routes.wallet.initialize_payment", return_value=paystack_result):
            resp = client.post("/api/wallet/fund/card", json={"amount": 5000}, headers=auth_headers)
        assert resp.status_code == 200
        data = resp.get_json()
        assert "authorization_url" in data
        assert "reference" in data

    def test_minimum_topup_enforced(self, client, auth_headers):
        resp = client.post("/api/wallet/fund/card", json={"amount": 50}, headers=auth_headers)
        assert resp.status_code == 400
        assert "100" in resp.get_json()["error"]

    def test_requires_auth(self, client):
        resp = client.post("/api/wallet/fund/card", json={"amount": 5000})
        assert resp.status_code == 401


class TestWalletTransactions:
    def test_returns_transaction_list(self, client, auth_headers):
        with patch("app.routes.wallet.get_wallet_transactions", return_value=[]):
            resp = client.get("/api/wallet/transactions", headers=auth_headers)
        assert resp.status_code == 200
        assert isinstance(resp.get_json(), list)

    def test_pagination(self, client, auth_headers):
        with patch("app.routes.wallet.get_wallet_transactions", return_value=[]) as mock_txns:
            resp = client.get("/api/wallet/transactions?limit=10&offset=20", headers=auth_headers)
        assert resp.status_code == 200
        mock_txns.assert_called_with(STUDENT_ID, limit=10, offset=20)
