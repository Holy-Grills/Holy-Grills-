"""
Phase A: HP Ledger Integrity Tests (42 tests)
A1: Active vs Pending Balance Consistency
A2: HP Earn Rate Accuracy
A3: Tier Bonus Multiplier
A4: Pending to Active Unlock Rate
A5: 120-Day Rolling Window
A6: HP Transaction Immutability
A7: HP Expiry & Breakage
"""

import pytest
import math
from unittest.mock import patch, MagicMock, call
from datetime import datetime, timezone, timedelta
from tests.conftest import (
    make_mock_db, STUDENT_ID, ORDER_ID, TIER_EMBER, TIER_FLAME,
    TIER_BLAZE, TIER_HOLY, SAMPLE_TIERS, SAMPLE_PROFILE, SAMPLE_HP_TXN
)


@pytest.fixture(autouse=True)
def flask_ctx(app):
    with app.app_context():
        yield


# ── A1: Active vs Pending Balance Consistency ─────────────────────────────────

class TestA1ActivePendingConsistency:
    def test_only_food_orders_zero_pending(self, app):
        """A1-1: User with only food orders has zero pending HP."""
        # Food HP always goes to ACTIVE, never pending
        db = make_mock_db({"hp_transactions": [
            {"amount": 350, "status": "active"},
            {"amount": 200, "status": "active"},
        ], "profiles": {**SAMPLE_PROFILE, "pending_hp_balance": 0, "hp_overflow": 0}})
        db.rpc.side_effect = Exception("fallback")

        with patch("app.services.hp_service.get_db", return_value=db):
            from app.services.hp_service import get_hp_balance
            result = get_hp_balance(STUDENT_ID)

        assert result["active"] == 550
        assert result["pending"] == 0

    def test_only_activities_all_pending(self, app):
        """A1-2: User with only activities has all HP in pending (zero active)."""
        db = make_mock_db({
            "hp_transactions": [],
            "profiles": {**SAMPLE_PROFILE, "pending_hp_balance": 175, "hp_overflow": 0},
        })
        db.rpc.side_effect = Exception("fallback")

        with patch("app.services.hp_service.get_db", return_value=db):
            from app.services.hp_service import get_hp_balance
            result = get_hp_balance(STUDENT_ID)

        assert result["active"] == 0
        assert result["pending"] == 175

    def test_both_active_and_pending_sum_correct(self, app):
        """A1-3: active + pending = sum of all HP earned."""
        db = make_mock_db({
            "hp_transactions": [{"amount": 500, "status": "active"}],
            "profiles": {**SAMPLE_PROFILE, "pending_hp_balance": 75, "hp_overflow": 0},
        })
        db.rpc.side_effect = Exception("fallback")

        with patch("app.services.hp_service.get_db", return_value=db):
            from app.services.hp_service import get_hp_balance
            result = get_hp_balance(STUDENT_ID)

        assert result["active"] == 500
        assert result["pending"] == 75
        assert result["active"] + result["pending"] == 575

    def test_pending_ceiling_35_percent_of_active(self, app):
        """A1-4: Pending balance never exceeds 35% of active (or 200 HP floor)."""
        active = 1000
        ceiling = max(int(active * 0.35), 200)
        profile = {**SAMPLE_PROFILE, "pending_hp_balance": 0, "hp_overflow": 0}

        with patch("app.services.hp_service.get_db", return_value=make_mock_db({"profiles": profile})), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": active, "pending": 0, "overflow": 0}), \
             patch("app.services.hp_service._record_hp_transaction"), \
             patch("app.services.hp_service._safe_update_profile"), \
             patch("app.services.hp_service._get_profile_hp_fields", return_value=profile):
            from app.services.hp_service import earn_pending_hp
            result = earn_pending_hp(STUDENT_ID, 500, "referral")

        assert result["ceiling_applied"] == ceiling
        assert result["added_to_pending"] + result["added_to_overflow"] == 500
        assert result["added_to_pending"] <= ceiling

    def test_overflow_holds_excess_beyond_ceiling(self, app):
        """A1-5: Overflow vault correctly holds excess beyond ceiling."""
        profile = {**SAMPLE_PROFILE, "pending_hp_balance": 350, "hp_overflow": 0}

        with patch("app.services.hp_service.get_db", return_value=make_mock_db({"profiles": profile})), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 1000, "pending": 350, "overflow": 0}), \
             patch("app.services.hp_service._record_hp_transaction"), \
             patch("app.services.hp_service._safe_update_profile"), \
             patch("app.services.hp_service._get_profile_hp_fields", return_value=profile):
            from app.services.hp_service import earn_pending_hp
            result = earn_pending_hp(STUDENT_ID, 100, "referral")

        assert result["added_to_overflow"] == 100
        assert result["added_to_pending"] == 0

    def test_overflow_restores_when_ceiling_rises(self, app):
        """A1-6: When active balance increases, ceiling rises and overflow moves to pending."""
        profile = {**SAMPLE_PROFILE, "pending_hp_balance": 200, "hp_overflow": 300}

        with patch("app.services.hp_service.get_db", return_value=make_mock_db({"profiles": profile})), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 2000, "pending": 200, "overflow": 300}), \
             patch("app.services.hp_service._record_hp_transaction"), \
             patch("app.services.hp_service._safe_update_profile"):
            from app.services.hp_service import unlock_pending_hp
            result = unlock_pending_hp(STUDENT_ID, ORDER_ID, 2000.0)

        assert result["overflow_restored"] >= 0

    def test_pending_cannot_exceed_ceiling_after_unlock(self, app):
        """A1-7: After unlock, pending recalculates and stays under new ceiling."""
        profile = {**SAMPLE_PROFILE, "pending_hp_balance": 350, "hp_overflow": 0}

        with patch("app.services.hp_service.get_db", return_value=make_mock_db({"profiles": profile})), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 1000, "pending": 350, "overflow": 0}), \
             patch("app.services.hp_service._record_hp_transaction"), \
             patch("app.services.hp_service._safe_update_profile"):
            from app.services.hp_service import unlock_pending_hp
            result = unlock_pending_hp(STUDENT_ID, ORDER_ID, 1000.0)

        assert result["unlocked"] == 100

    def test_zero_active_no_pending_except_floor(self, app):
        """A1-8: No pending HP for zero active balance except floor (200 HP)."""
        profile = {**SAMPLE_PROFILE, "pending_hp_balance": 0, "hp_overflow": 0}

        with patch("app.services.hp_service.get_db", return_value=make_mock_db({"profiles": profile})), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 0, "pending": 0, "overflow": 0}), \
             patch("app.services.hp_service._record_hp_transaction"), \
             patch("app.services.hp_service._safe_update_profile"), \
             patch("app.services.hp_service._get_profile_hp_fields", return_value=profile):
            from app.services.hp_service import earn_pending_hp
            result = earn_pending_hp(STUDENT_ID, 100, "referral")

        assert result["ceiling_applied"] == 200
        assert result["added_to_pending"] == 100


# ── A2: HP Earn Rate Accuracy ─────────────────────────────────────────────────

class TestA2EarnRateAccuracy:
    def _award_hp(self, total, tier="ember"):
        with patch("app.services.hp_service.get_db", return_value=make_mock_db()), \
             patch("app.services.hp_service.unlock_pending_hp", return_value={"unlocked": 0}), \
             patch("app.services.hp_service._update_earned_counters"), \
             patch("app.services.hp_service._record_hp_transaction"):
            from app.services.hp_service import award_food_order_hp
            return award_food_order_hp(STUDENT_ID, ORDER_ID, total, tier)

    def test_3500_order_earns_350_base_hp(self, app):
        """A2-1: ₦3,500 order earns exactly 350 base HP."""
        result = self._award_hp(3500.0)
        assert result["base_hp"] == 350

    def test_2000_order_earns_200_base_hp(self, app):
        """A2-2: ₦2,000 order earns exactly 200 base HP."""
        result = self._award_hp(2000.0)
        assert result["base_hp"] == 200

    def test_4500_order_earns_450_base_hp(self, app):
        """A2-3: ₦4,500 order earns exactly 450 base HP."""
        result = self._award_hp(4500.0)
        assert result["base_hp"] == 450

    def test_hp_on_discounted_amount_not_original(self, app):
        """A2-4: HP earned on discounted amount (after promo), not original subtotal."""
        # If original is ₦5000 but discount ₦1000, HP earned on ₦4000
        result = self._award_hp(4000.0)
        assert result["base_hp"] == 400

    def test_delivery_fee_absorbed_no_extra_hp(self, app):
        """A2-5: Delivery fee is absorbed into pricing — does not earn extra HP."""
        # HP is calculated only on the order_total parameter passed to award_food_order_hp
        # The caller (order_service) passes subtotal (excl. delivery fee) — delivery=0
        result = self._award_hp(3500.0)
        assert result["base_hp"] == 350  # delivery already excluded by caller

    def test_wallet_topup_earns_50_bonus_hp(self, app):
        """A2-6: Wallet top-up of ≥₦3,000 earns exactly 50 bonus HP."""
        with patch("app.services.hp_service.get_db", return_value=make_mock_db()), \
             patch("app.services.hp_service._update_earned_counters"), \
             patch("app.services.hp_service._record_hp_transaction"):
            from app.services.hp_service import award_active_hp
            result = award_active_hp(
                user_id=STUDENT_ID,
                amount=50,
                txn_type="earn_admin_grant",
                source_type="wallet_topup",
                notes="Wallet top-up bonus",
            )
        assert result["awarded"] == 50


# ── A3: Tier Bonus Multiplier ─────────────────────────────────────────────────

class TestA3TierBonusMultiplier:
    def _award(self, total, tier):
        with patch("app.services.hp_service.get_db", return_value=make_mock_db()), \
             patch("app.services.hp_service.unlock_pending_hp", return_value={"unlocked": 0}), \
             patch("app.services.hp_service._update_earned_counters"), \
             patch("app.services.hp_service._record_hp_transaction"):
            from app.services.hp_service import award_food_order_hp
            return award_food_order_hp(STUDENT_ID, ORDER_ID, total, tier)

    def test_ember_zero_percent_bonus(self, app):
        """A3-1: Ember tier adds 0% bonus."""
        result = self._award(1000.0, "ember")
        assert result["tier_bonus_hp"] == 0
        assert result["total_hp"] == 100

    def test_flame_eight_percent_bonus(self, app):
        """A3-2: Flame tier adds exactly 8% bonus."""
        result = self._award(1000.0, "flame")
        assert result["tier_bonus_hp"] == 8
        assert result["total_hp"] == 108

    def test_blaze_fifteen_percent_bonus(self, app):
        """A3-3: Blaze tier adds exactly 15% bonus."""
        result = self._award(1000.0, "blaze")
        assert result["tier_bonus_hp"] == 15
        assert result["total_hp"] == 115

    def test_holy_twenty_five_percent_bonus(self, app):
        """A3-4: Holy tier adds exactly 25% bonus."""
        result = self._award(1000.0, "holy")
        assert result["tier_bonus_hp"] == 25
        assert result["total_hp"] == 125

    def test_tier_bonus_only_on_food_not_activity(self, app):
        """A3-5: Tier bonus applies ONLY to food order HP, not activity HP."""
        with patch("app.services.hp_service.get_db", return_value=make_mock_db()), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 1000, "pending": 0, "overflow": 0}), \
             patch("app.services.hp_service._record_hp_transaction"), \
             patch("app.services.hp_service._safe_update_profile"), \
             patch("app.services.hp_service._get_profile_hp_fields",
                   return_value={**SAMPLE_PROFILE, "pending_hp_balance": 0, "hp_overflow": 0}):
            from app.services.hp_service import earn_pending_hp
            result = earn_pending_hp(STUDENT_ID, 75, "referral")

        # earn_pending_hp returns the raw amount — no tier multiplier applied
        assert result["added_to_pending"] + result["added_to_overflow"] == 75

    def test_tier_bonus_calculated_on_base_hp_before_rounding(self, app):
        """A3-6: Bonus computed on base HP; round() avoids floating-point truncation."""
        # ₦1000 → 100 base HP, blaze 1.15 → bonus = round(100 * 0.15) = 15
        result = self._award(1000.0, "blaze")
        expected_bonus = round(100 * (1.15 - 1.0))
        assert result["tier_bonus_hp"] == expected_bonus


# ── A4: Pending to Active Unlock Rate ────────────────────────────────────────

class TestA4UnlockRate:
    def _unlock(self, food_spend, pending=500, active=1000):
        profile = {**SAMPLE_PROFILE, "pending_hp_balance": pending, "hp_overflow": 0}
        with patch("app.services.hp_service.get_db", return_value=make_mock_db({"profiles": profile})), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": active, "pending": pending, "overflow": 0}), \
             patch("app.services.hp_service._record_hp_transaction"), \
             patch("app.services.hp_service._safe_update_profile"):
            from app.services.hp_service import unlock_pending_hp
            return unlock_pending_hp(STUDENT_ID, ORDER_ID, food_spend)

    def test_1000_spend_unlocks_100_hp(self, app):
        """A4-1: ₦1,000 food spend unlocks exactly 100 pending HP."""
        result = self._unlock(1000.0)
        assert result["unlocked"] == 100

    def test_2500_spend_unlocks_200_hp(self, app):
        """A4-2: ₦2,500 food spend unlocks floor(2500/1000)*100 = 200 HP."""
        result = self._unlock(2500.0)
        assert result["unlocked"] == 200

    def test_unlock_capped_at_pending_balance(self, app):
        """A4-3: Unlock cannot exceed available pending balance."""
        result = self._unlock(5000.0, pending=150)
        assert result["unlocked"] == 150

    def test_no_unlock_for_sub_1000_spend(self, app):
        """A4-4: ₦900 spend → floor(900/1000)*100 = 0 HP unlocked."""
        result = self._unlock(900.0)
        assert result["unlocked"] == 0

    def test_multiple_orders_stack_unlock(self, app):
        """A4-5: Second order unlock adds to what first order unlocked."""
        # ₦1000 twice = 2 unlocks of 100 each (tested individually since service is stateless)
        r1 = self._unlock(1000.0, pending=300)
        r2 = self._unlock(1000.0, pending=200)  # after first unlock
        assert r1["unlocked"] == 100
        assert r2["unlocked"] == 100
        assert r1["unlocked"] + r2["unlocked"] == 200

    def test_unlocked_hp_removed_from_pending(self, app):
        """A4-6: Unlock reduces pending (does not affect ceiling calc; ceiling uses active)."""
        profile = {**SAMPLE_PROFILE, "pending_hp_balance": 300, "hp_overflow": 0}
        update_calls = []

        def capture_update(user_id, updates):
            update_calls.append(updates)

        with patch("app.services.hp_service.get_db", return_value=make_mock_db({"profiles": profile})), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 1000, "pending": 300, "overflow": 0}), \
             patch("app.services.hp_service._record_hp_transaction"), \
             patch("app.services.hp_service._safe_update_profile", side_effect=capture_update):
            from app.services.hp_service import unlock_pending_hp
            unlock_pending_hp(STUDENT_ID, ORDER_ID, 1000.0)

        assert any("pending_hp_balance" in u for u in update_calls)
        new_pending = next(u["pending_hp_balance"] for u in update_calls if "pending_hp_balance" in u)
        assert new_pending < 300

    def test_unlock_records_txn_of_type_unlock(self, app):
        """A4-7: Unlock transaction recorded with type 'unlock'."""
        recorded_calls = []

        def capture(user_id, amount, txn_type, **kwargs):
            recorded_calls.append(txn_type)

        profile = {**SAMPLE_PROFILE, "pending_hp_balance": 500, "hp_overflow": 0}
        with patch("app.services.hp_service.get_db", return_value=make_mock_db({"profiles": profile})), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 1000, "pending": 500, "overflow": 0}), \
             patch("app.services.hp_service._record_hp_transaction", side_effect=capture), \
             patch("app.services.hp_service._safe_update_profile"):
            from app.services.hp_service import unlock_pending_hp
            unlock_pending_hp(STUDENT_ID, ORDER_ID, 1000.0)

        assert "unlock" in recorded_calls


# ── A5: 120-Day Rolling Window ────────────────────────────────────────────────

class TestA5RollingWindow:
    def test_hp_earned_today_counted(self, app):
        """A5-1: HP earned today is within 120-day window."""
        profile = {**SAMPLE_PROFILE, "hp_earned_120day": 350, "tier_bonus_multiplier": 1.0}
        db = make_mock_db({"profiles": profile, "tiers": SAMPLE_TIERS})

        with patch("app.services.hp_service.get_db", return_value=db), \
             patch("app.services.hp_service._safe_update_profile"):
            from app.services.hp_service import recalculate_tier
            result = recalculate_tier(STUDENT_ID)

        assert result["tier"]["slug"] == "ember"

    def test_hp_earned_121_days_ago_excluded(self, app):
        """A5-2: hp_earned_120day only reflects last 120 days — old HP excluded."""
        # Service reads hp_earned_120day from profile directly
        # We test that recalculate_tier uses hp_earned_120day (not total HP)
        profile = {**SAMPLE_PROFILE, "hp_earned_120day": 0}  # 121-day-old HP excluded
        db = make_mock_db({"profiles": profile, "tiers": SAMPLE_TIERS,
                           "hp_transactions": [{"amount": 5000, "status": "active",
                                                "created_at": "2025-01-01T00:00:00Z"}]})
        with patch("app.services.hp_service.get_db", return_value=db), \
             patch("app.services.hp_service._safe_update_profile"):
            from app.services.hp_service import recalculate_tier
            result = recalculate_tier(STUDENT_ID)

        assert result["tier"]["slug"] == "ember"  # not promoted, old HP excluded

    def test_tier_promotion_when_threshold_crossed(self, app):
        """A5-3: Tier promotion triggers immediately when threshold crossed."""
        profile = {**SAMPLE_PROFILE, "hp_earned_120day": 2600}
        db = make_mock_db({"profiles": profile, "tiers": SAMPLE_TIERS,
                           "user_tiers": [{"id": "x", "tier_id": TIER_EMBER, "is_current": True}]})

        with patch("app.services.hp_service.get_db", return_value=db), \
             patch("app.services.hp_service._safe_update_profile"):
            from app.services.hp_service import recalculate_tier
            result = recalculate_tier(STUDENT_ID)

        assert result["changed"] is True
        assert result["tier"]["slug"] == "flame"

    def test_grace_period_in_user_tier_data(self, app):
        """A5-4: Grace period flag exists on user_tiers row."""
        user_tier = {"tier_id": TIER_FLAME, "is_current": True,
                     "is_in_grace_period": True, "grace_period_ends_at": "2026-06-01T00:00:00Z"}
        db = make_mock_db({"user_tiers": [user_tier], "tiers": SAMPLE_TIERS})

        with patch("app.services.hp_service.get_db", return_value=db):
            from app.services.hp_service import get_user_tier
            result = get_user_tier(STUDENT_ID)

        assert result["is_in_grace_period"] is True
        assert result["grace_period_ends_at"] is not None

    def test_grace_period_resets_if_restored(self, app):
        """A5-5: If HP restored within grace period, tier stays."""
        profile = {**SAMPLE_PROFILE, "hp_earned_120day": 2600}  # back above threshold
        db = make_mock_db({"profiles": profile, "tiers": SAMPLE_TIERS,
                           "user_tiers": [{"id": "x", "tier_id": TIER_FLAME, "is_current": True}]})

        with patch("app.services.hp_service.get_db", return_value=db), \
             patch("app.services.hp_service._safe_update_profile"):
            from app.services.hp_service import recalculate_tier
            result = recalculate_tier(STUDENT_ID)

        assert result["tier"]["slug"] == "flame"
        assert result["changed"] is False  # still on flame, no change

    def test_hp_spend_does_not_reduce_120day_earned(self, app):
        """A5-6: HP spent on rewards does NOT reduce hp_earned_120day."""
        counters_called_with = []

        def mock_record(user_id, amount, txn_type, **kwargs):
            pass  # spend_hp records but _update_earned_counters is NOT called by spend_hp

        with patch("app.services.hp_service.get_db", return_value=make_mock_db()), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 500}), \
             patch("app.services.hp_service._record_hp_transaction", side_effect=mock_record), \
             patch("app.services.hp_service._update_earned_counters") as mock_counters:
            from app.services.hp_service import spend_hp
            spend_hp(STUDENT_ID, 100, ORDER_ID, "reward_redemption")

        mock_counters.assert_not_called()


# ── A6: HP Transaction Immutability ──────────────────────────────────────────

class TestA6TransactionImmutability:
    def test_hp_service_never_updates_hp_transactions(self, app):
        """A6-1: Service only inserts to hp_transactions, never updates."""
        db = make_mock_db()
        update_calls_on_hp_txn = []

        original_table = db.table.side_effect
        def guarded_table(name):
            tbl = original_table(name)
            if name == "hp_transactions":
                original_update = tbl.update
                def blocked_update(*args, **kwargs):
                    update_calls_on_hp_txn.append(args)
                    return original_update(*args, **kwargs)
                tbl.update = blocked_update
            return tbl
        db.table.side_effect = guarded_table

        with patch("app.services.hp_service.get_db", return_value=db), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 500}), \
             patch("app.services.hp_service._record_hp_transaction"):
            from app.services.hp_service import spend_hp
            spend_hp(STUDENT_ID, 100, ORDER_ID, "reward_redemption")

        assert update_calls_on_hp_txn == []

    def test_balance_after_reflects_running_sum(self, app):
        """A6-2: balance_after column matches running sum — verified via _record_hp_transaction logic."""
        recorded = []

        def capture(user_id, amount, txn_type, **kwargs):
            recorded.append({"amount": amount, "txn_type": txn_type})

        with patch("app.services.hp_service.get_db", return_value=make_mock_db()), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 500}), \
             patch("app.services.hp_service._record_hp_transaction", side_effect=capture), \
             patch("app.services.hp_service._update_earned_counters"):
            from app.services.hp_service import award_active_hp
            award_active_hp(STUDENT_ID, 100, source_type="birthday")

        assert any(r["amount"] == 100 for r in recorded)

    def test_spend_records_negative_amount(self, app):
        """A6-3: Negative amount transactions (spend) always recorded with -amount."""
        recorded = []

        def capture(user_id, amount, txn_type, **kwargs):
            recorded.append(amount)

        with patch("app.services.hp_service.get_db", return_value=make_mock_db()), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 500}), \
             patch("app.services.hp_service._record_hp_transaction", side_effect=capture):
            from app.services.hp_service import spend_hp
            spend_hp(STUDENT_ID, 100, ORDER_ID, "reward_redemption")

        assert any(a < 0 for a in recorded)

    def test_earn_records_reference_id_and_type(self, app):
        """A6-4: reference_id + reference_type always included in HP transactions."""
        recorded = []

        def capture(user_id, amount, txn_type, reference_id=None, reference_type=None, **kwargs):
            recorded.append({"ref_id": reference_id, "ref_type": reference_type})

        with patch("app.services.hp_service.get_db", return_value=make_mock_db()), \
             patch("app.services.hp_service.unlock_pending_hp", return_value={"unlocked": 0}), \
             patch("app.services.hp_service._update_earned_counters"), \
             patch("app.services.hp_service._record_hp_transaction", side_effect=capture):
            from app.services.hp_service import award_food_order_hp
            award_food_order_hp(STUDENT_ID, ORDER_ID, 1000.0, "ember")

        food_txn = next((r for r in recorded if r["ref_type"] == "order"), None)
        assert food_txn is not None
        assert food_txn["ref_id"] == ORDER_ID

    def test_admin_grant_includes_issued_by(self, app):
        """A6-5: Admin-issued HP has issued_by_admin_id populated."""
        recorded = []

        def capture(user_id, amount, txn_type, issued_by_admin_id=None, **kwargs):
            recorded.append(issued_by_admin_id)

        from tests.conftest import ADMIN_ID
        with patch("app.services.hp_service.get_db", return_value=make_mock_db()), \
             patch("app.services.hp_service._update_earned_counters"), \
             patch("app.services.hp_service._record_hp_transaction", side_effect=capture):
            from app.services.hp_service import award_active_hp
            award_active_hp(STUDENT_ID, 200, source_type="admin_grant", issued_by_admin_id=ADMIN_ID)

        assert any(a == ADMIN_ID for a in recorded)


# ── A7: HP Expiry & Breakage ─────────────────────────────────────────────────

class TestA7ExpiryBreakage:
    def test_inactive_90_days_flagged_eligible(self, app):
        """A7-1: Inactive HP (no orders in 90 days) flagged for expiry."""
        db = make_mock_db({"hp_transactions": [
            {"amount": 500, "status": "active", "created_at": "2020-01-01T00:00:00Z"},
        ]})
        with patch("app.services.hp_service.get_db", return_value=db), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 500}):
            from app.services.hp_service import calculate_breakage
            result = calculate_breakage(STUDENT_ID, 90)

        assert result["eligible"] is True

    def test_breakage_calculation_is_25_percent(self, app):
        """A7-2: 25% of active balance flagged for expiry on inactive account."""
        db = make_mock_db({"hp_transactions": [
            {"amount": 1000, "status": "active", "created_at": "2020-01-01T00:00:00Z"},
        ]})
        with patch("app.services.hp_service.get_db", return_value=db), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 1000}):
            from app.services.hp_service import calculate_breakage
            result = calculate_breakage(STUDENT_ID, 90)

        assert result["amount_to_expire"] == 250

    def test_expire_hp_creates_expire_type_txn(self, app):
        """A7-3: Expired HP creates transaction of type 'expire'."""
        recorded = []

        def capture(user_id, amount, txn_type, **kwargs):
            recorded.append(txn_type)

        with patch("app.services.hp_service.get_db", return_value=make_mock_db()), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 1000}), \
             patch("app.services.hp_service._record_hp_transaction", side_effect=capture):
            from app.services.hp_service import expire_hp
            result = expire_hp(STUDENT_ID, 250)

        assert result["expired"] == 250
        assert "expire" in recorded

    def test_breakage_rate_25_percent(self, app):
        """A7-4: Breakage rate stays at 25% as configured."""
        db = make_mock_db({"hp_transactions": [
            {"amount": 800, "status": "active", "created_at": "2020-01-01T00:00:00Z"},
        ]})
        with patch("app.services.hp_service.get_db", return_value=db), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 800}):
            from app.services.hp_service import calculate_breakage
            result = calculate_breakage(STUDENT_ID, 90)

        assert result["breakage_rate"] == 0.25
        assert result["amount_to_expire"] == int(800 * 0.25)
