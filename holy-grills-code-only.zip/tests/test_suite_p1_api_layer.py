"""
Part 1 — API Layer Tests
Covers: Error handling, idempotency, input validation, security, pagination, rate limits.
Maps to spec sections 1.2, 1.3, 1.4, 1.6.
"""

import json
import pytest
import jwt
import os
from unittest.mock import patch, MagicMock
from datetime import datetime, timezone, timedelta
from tests.conftest import (
    make_mock_db, STUDENT_ID, ADMIN_ID, ORDER_ID, REWARD_ID, WINDOW_ID,
    SAMPLE_PROFILE, SAMPLE_ADMIN_PROFILE, SAMPLE_ORDER, SAMPLE_REWARD,
    SAMPLE_WINDOW, SAMPLE_TIERS, SAMPLE_WALLET,
    student_token, admin_token, kitchen_token,
)


@pytest.fixture(autouse=True)
def global_auth_mock(app):
    db = make_mock_db()
    with patch("app.middleware.auth.get_db", return_value=db):
        yield db


# ─────────────────────────────────────────────────────────────────────────────
# 1. Invalid endpoint → 404
# ─────────────────────────────────────────────────────────────────────────────
class TestInvalidEndpoint:
    def test_unknown_route_returns_404(self, client):
        resp = client.get("/api/this-does-not-exist")
        assert resp.status_code == 404

    def test_wrong_method_returns_405(self, client):
        resp = client.delete("/api/auth/login")
        assert resp.status_code == 405

    def test_unknown_nested_route_404(self, client):
        resp = client.get("/api/hp/this-is-fake")
        assert resp.status_code == 404

    def test_health_endpoint_does_not_500(self, client):
        resp = client.get("/api/health")
        assert resp.status_code in (200, 404)

    def test_docs_endpoint_does_not_500(self, client):
        resp = client.get("/api/docs/", follow_redirects=True)
        assert resp.status_code in (200, 404, 308)


# ─────────────────────────────────────────────────────────────────────────────
# 2. Missing required fields → 400
# ─────────────────────────────────────────────────────────────────────────────
class TestMissingRequiredFields:
    def test_register_missing_email(self, client):
        resp = client.post("/api/auth/register", json={"password": "Pass1234", "full_name": "A B"})
        assert resp.status_code == 400
        assert "error" in resp.get_json()

    def test_register_missing_password(self, client):
        resp = client.post("/api/auth/register", json={"email": "a@b.com", "full_name": "A B"})
        assert resp.status_code == 400

    def test_register_missing_full_name(self, client):
        resp = client.post("/api/auth/register", json={"email": "a@b.com", "password": "Pass1234"})
        assert resp.status_code == 400

    def test_login_missing_password(self, client):
        resp = client.post("/api/auth/login", json={"email": "a@b.com"})
        assert resp.status_code == 400

    def test_order_missing_items(self, client, auth_headers):
        with patch("app.routes.orders.rate_limit", lambda *a, **kw: lambda f: f), \
             patch("app.routes.orders.order_service.create_order",
                   side_effect=ValueError("items required")):
            resp = client.post("/api/orders", json={
                "delivery_window_id": WINDOW_ID, "payment_method": "card",
                "delivery_address": {"address_line": "Main St"}
            }, headers=auth_headers)
        assert resp.status_code in (400, 500)

    def test_order_missing_window(self, client, auth_headers):
        with patch("app.routes.orders.rate_limit", lambda *a, **kw: lambda f: f), \
             patch("app.routes.orders.order_service.create_order",
                   side_effect=ValueError("delivery_window_id required")):
            resp = client.post("/api/orders", json={
                "items": [{"menu_item_id": "aaa", "quantity": 1}],
                "payment_method": "card",
                "delivery_address": {"address_line": "Main St"}
            }, headers=auth_headers)
        assert resp.status_code in (400, 500)

    def test_order_missing_payment_method(self, client, auth_headers):
        with patch("app.routes.orders.rate_limit", lambda *a, **kw: lambda f: f), \
             patch("app.routes.orders.order_service.create_order",
                   side_effect=ValueError("payment_method required")):
            resp = client.post("/api/orders", json={
                "items": [{"menu_item_id": "aaa", "quantity": 1}],
                "delivery_window_id": WINDOW_ID,
                "delivery_address": {"address_line": "Main St"}
            }, headers=auth_headers)
        assert resp.status_code in (400, 500)

    def test_hp_topup_missing_amount(self, client, auth_headers):
        db = make_mock_db({"wallets": SAMPLE_WALLET, "profiles": SAMPLE_PROFILE})
        with patch("app.middleware.auth.get_db", return_value=db), \
             patch("app.routes.wallet.get_db", return_value=db), \
             patch("app.services.wallet_service.get_wallet", return_value=SAMPLE_WALLET):
            resp = client.post("/api/wallet/fund/card", json={}, headers=auth_headers)
        assert resp.status_code == 400


# ─────────────────────────────────────────────────────────────────────────────
# 3. Malformed JSON → 400
# ─────────────────────────────────────────────────────────────────────────────
class TestMalformedInput:
    def test_malformed_json_register(self, client):
        resp = client.post("/api/auth/register",
                           data="not-valid-json",
                           content_type="application/json")
        assert resp.status_code in (400, 415, 500)

    def test_empty_body_login(self, client):
        resp = client.post("/api/auth/login", json={})
        assert resp.status_code == 400

    def test_negative_quantity_order(self, client, auth_headers):
        with patch("app.routes.orders.rate_limit", lambda *a, **kw: lambda f: f), \
             patch("app.routes.orders.order_service.create_order",
                   side_effect=ValueError("Quantity must be positive")):
            resp = client.post("/api/orders", json={
                "items": [{"menu_item_id": "aaa", "quantity": -1}],
                "delivery_window_id": WINDOW_ID,
                "payment_method": "card",
                "delivery_address": {"address_line": "Main"}
            }, headers=auth_headers)
        assert resp.status_code in (400, 500)

    def test_zero_quantity_order(self, client, auth_headers):
        with patch("app.routes.orders.rate_limit", lambda *a, **kw: lambda f: f), \
             patch("app.routes.orders.order_service.create_order",
                   side_effect=ValueError("Quantity must be positive")):
            resp = client.post("/api/orders", json={
                "items": [{"menu_item_id": "aaa", "quantity": 0}],
                "delivery_window_id": WINDOW_ID,
                "payment_method": "card",
                "delivery_address": {"address_line": "Main"}
            }, headers=auth_headers)
        assert resp.status_code in (400, 500)

    def test_invalid_payment_method(self, client, auth_headers):
        with patch("app.routes.orders.rate_limit", lambda *a, **kw: lambda f: f), \
             patch("app.routes.orders.order_service.create_order",
                   side_effect=ValueError("Invalid payment method")):
            resp = client.post("/api/orders", json={
                "items": [{"menu_item_id": "aaa", "quantity": 1}],
                "delivery_window_id": WINDOW_ID,
                "payment_method": "bitcoin",
                "delivery_address": {"address_line": "Main"}
            }, headers=auth_headers)
        assert resp.status_code in (400, 500)

    def test_password_too_short(self, client):
        resp = client.post("/api/auth/register", json={
            "email": "x@y.com", "password": "short", "full_name": "X"
        })
        assert resp.status_code == 400

    def test_negative_hp_grant_without_admin(self, client, auth_headers):
        resp = client.post("/api/hp/admin/grant",
                           json={"user_id": STUDENT_ID, "amount": -100},
                           headers=auth_headers)
        assert resp.status_code == 403


# ─────────────────────────────────────────────────────────────────────────────
# 4. Authentication errors
# ─────────────────────────────────────────────────────────────────────────────
class TestAuthErrors:
    def test_missing_auth_header(self, client):
        resp = client.get("/api/hp/balance")
        assert resp.status_code == 401

    def test_malformed_bearer_token(self, client):
        resp = client.get("/api/hp/balance",
                          headers={"Authorization": "NotBearer abc"})
        assert resp.status_code == 401

    def test_expired_token(self, client):
        expired = jwt.encode(
            {"sub": STUDENT_ID, "exp": int((datetime.now(timezone.utc) - timedelta(hours=1)).timestamp())},
            os.environ["JWT_SECRET"], algorithm="HS256"
        )
        resp = client.get("/api/hp/balance",
                          headers={"Authorization": f"Bearer {expired}"})
        assert resp.status_code == 401

    def test_tampered_token(self, client):
        tampered = jwt.encode(
            {"sub": STUDENT_ID, "exp": int((datetime.now(timezone.utc) + timedelta(hours=1)).timestamp())},
            "wrong-secret", algorithm="HS256"
        )
        resp = client.get("/api/hp/balance",
                          headers={"Authorization": f"Bearer {tampered}"})
        assert resp.status_code == 401

    def test_student_accessing_admin_endpoint_returns_403(self, client, auth_headers):
        db = make_mock_db()
        with patch("app.middleware.auth.get_db", return_value=db):
            resp = client.get("/api/admin/users", headers=auth_headers)
        assert resp.status_code == 403

    def test_student_cannot_grant_hp(self, client, auth_headers):
        db = make_mock_db()
        with patch("app.middleware.auth.get_db", return_value=db):
            resp = client.post("/api/hp/admin/grant",
                               json={"user_id": STUDENT_ID, "amount": 100},
                               headers=auth_headers)
        assert resp.status_code == 403

    def test_student_cannot_create_blast(self, client, auth_headers):
        db = make_mock_db()
        with patch("app.middleware.auth.get_db", return_value=db):
            resp = client.post("/api/notifications/blasts",
                               json={"title": "Hi", "body": "World", "channels": ["in_app"]},
                               headers=auth_headers)
        assert resp.status_code == 403

    def test_unauthenticated_wallet_access(self, client):
        resp = client.get("/api/wallet")
        assert resp.status_code == 401

    def test_unauthenticated_notifications_access(self, client):
        resp = client.get("/api/notifications")
        assert resp.status_code == 401

    def test_unauthenticated_redemption(self, client):
        resp = client.post(f"/api/rewards/{REWARD_ID}/redeem", json={})
        assert resp.status_code == 401

    def test_deactivated_user_blocked(self, client):
        inactive = {**SAMPLE_PROFILE, "is_active": False}
        db = make_mock_db({"profiles": inactive})
        with patch("app.middleware.auth.get_db", return_value=db):
            resp = client.get("/api/hp/balance",
                              headers={"Authorization": f"Bearer {student_token()}"})
        assert resp.status_code == 403


# ─────────────────────────────────────────────────────────────────────────────
# 5. Public endpoints work without auth
# ─────────────────────────────────────────────────────────────────────────────
class TestPublicEndpoints:
    def test_menu_categories_public(self, client):
        db = make_mock_db({"menu_categories": []})
        with patch("app.routes.menu.get_db", return_value=db):
            resp = client.get("/api/menu/categories")
        assert resp.status_code == 200

    def test_menu_items_public(self, client):
        db = make_mock_db({"menu_items": []})
        with patch("app.routes.menu.get_db", return_value=db):
            resp = client.get("/api/menu/items")
        assert resp.status_code == 200

    def test_tiers_public(self, client):
        db = make_mock_db({"tiers": SAMPLE_TIERS})
        with patch("app.routes.hp.get_db", return_value=db):
            resp = client.get("/api/hp/tiers")
        assert resp.status_code == 200

    def test_rewards_list_public(self, client):
        db = make_mock_db({"rewards": [SAMPLE_REWARD]})
        with patch("app.routes.rewards.get_db", return_value=db):
            resp = client.get("/api/rewards")
        assert resp.status_code == 200

    def test_leaderboard_public(self, client):
        db = make_mock_db({"leaderboard_snapshots": [], "profiles": []})
        with patch("app.routes.leaderboard.get_db", return_value=db):
            resp = client.get("/api/leaderboard")
        assert resp.status_code == 200


# ─────────────────────────────────────────────────────────────────────────────
# 6. Webhook idempotency
# ─────────────────────────────────────────────────────────────────────────────
class TestWebhookIdempotency:
    def test_duplicate_paystack_webhook_ignored(self, client):
        existing_event = [{"id": "existing-webhook-id"}]
        db = make_mock_db({"webhook_events": existing_event})
        import hashlib, hmac as _hmac
        payload = json.dumps({"event": "charge.success",
                              "data": {"reference": "REF001"}}).encode()
        sig = _hmac.new(b"mock-webhook-secret", payload, hashlib.sha512).hexdigest()
        with patch("app.routes.webhooks.get_db", return_value=db):
            resp = client.post("/api/webhooks/paystack",
                               data=payload,
                               content_type="application/json",
                               headers={"x-paystack-signature": sig})
        assert resp.status_code == 200
        msg = resp.get_json().get("message", "").lower()
        assert "processed" in msg or "already" in msg

    def test_invalid_webhook_signature_rejected(self, client):
        db = make_mock_db({"webhook_events": []})
        payload = json.dumps({"event": "charge.success",
                              "data": {"reference": "REF999"}}).encode()
        with patch("app.routes.webhooks.get_db", return_value=db):
            resp = client.post("/api/webhooks/paystack",
                               data=payload,
                               content_type="application/json",
                               headers={"x-paystack-signature": "bad-sig"})
        assert resp.status_code in (200, 401)

    def test_first_webhook_processed(self, client):
        db = make_mock_db({"webhook_events": []})
        import hashlib, hmac as _hmac
        payload = json.dumps({
            "event": "charge.success",
            "data": {"reference": "NEW_REF",
                     "metadata": {"type": "wallet_topup", "user_id": STUDENT_ID},
                     "amount": 500000},
        }).encode()
        sig = _hmac.new(b"mock-webhook-secret", payload, hashlib.sha512).hexdigest()
        with patch("app.routes.webhooks.get_db", return_value=db), \
             patch("app.routes.webhooks._handle_charge_success"):
            resp = client.post("/api/webhooks/paystack",
                               data=payload,
                               content_type="application/json",
                               headers={"x-paystack-signature": sig})
        assert resp.status_code == 200


# ─────────────────────────────────────────────────────────────────────────────
# 7. Pagination parameters
# ─────────────────────────────────────────────────────────────────────────────
class TestPagination:
    def test_hp_transactions_default_pagination(self, client, auth_headers):
        db = make_mock_db({"hp_transactions": [], "profiles": SAMPLE_PROFILE})
        with patch("app.middleware.auth.get_db", return_value=db), \
             patch("app.routes.hp.get_db", return_value=db):
            resp = client.get("/api/hp/transactions", headers=auth_headers)
        assert resp.status_code == 200

    def test_hp_transactions_custom_limit(self, client, auth_headers):
        db = make_mock_db({"hp_transactions": [], "profiles": SAMPLE_PROFILE})
        with patch("app.middleware.auth.get_db", return_value=db), \
             patch("app.routes.hp.get_db", return_value=db):
            resp = client.get("/api/hp/transactions?limit=5&offset=0", headers=auth_headers)
        assert resp.status_code == 200

    def test_orders_empty_returns_list_not_error(self, client, auth_headers):
        db = make_mock_db({"orders": [], "profiles": SAMPLE_PROFILE})
        with patch("app.middleware.auth.get_db", return_value=db), \
             patch("app.routes.orders.get_db", return_value=db):
            resp = client.get("/api/orders", headers=auth_headers)
        assert resp.status_code == 200
        assert isinstance(resp.get_json(), list)

    def test_notifications_unread_only_filter(self, client, auth_headers):
        db = make_mock_db({"notifications": [], "profiles": SAMPLE_PROFILE})
        with patch("app.middleware.auth.get_db", return_value=db), \
             patch("app.routes.notifications.get_db", return_value=db):
            resp = client.get("/api/notifications?unread_only=true", headers=auth_headers)
        assert resp.status_code == 200

    def test_rewards_category_filter(self, client):
        db = make_mock_db({"rewards": [SAMPLE_REWARD]})
        with patch("app.routes.rewards.get_db", return_value=db):
            resp = client.get("/api/rewards?category=food")
        assert resp.status_code == 200

    def test_leaderboard_limit_param_accepted(self, client):
        db = make_mock_db({"leaderboard_snapshots": [], "profiles": [SAMPLE_PROFILE]})
        with patch("app.routes.leaderboard.get_db", return_value=db):
            resp = client.get("/api/leaderboard?limit=10")
        assert resp.status_code == 200

    def test_notifications_limit_param_accepted(self, client, auth_headers):
        db = make_mock_db({"notifications": [], "profiles": SAMPLE_PROFILE})
        with patch("app.middleware.auth.get_db", return_value=db), \
             patch("app.routes.notifications.get_db", return_value=db):
            resp = client.get("/api/notifications?limit=50", headers=auth_headers)
        assert resp.status_code == 200


# ─────────────────────────────────────────────────────────────────────────────
# 8. Response shape contracts
# ─────────────────────────────────────────────────────────────────────────────
class TestResponseShapes:
    def test_hp_balance_has_required_fields(self, client, auth_headers):
        db = make_mock_db({"profiles": SAMPLE_PROFILE, "hp_transactions": [], "user_tiers": []})
        with patch("app.middleware.auth.get_db", return_value=db), \
             patch("app.routes.hp.get_db", return_value=db), \
             patch("app.routes.hp.get_hp_balance",
                   return_value={"active": 0, "pending": 0, "overflow": 0,
                                 "total_visible": 0, "monthly_hp_earned": 0,
                                 "hp_earned_120day": 0, "tier_bonus_multiplier": 1.0}), \
             patch("app.routes.hp.get_user_tier", return_value=None):
            resp = client.get("/api/hp/balance", headers=auth_headers)
        assert resp.status_code == 200
        data = resp.get_json()
        for field in ("active", "pending", "overflow"):
            assert field in data

    def test_wallet_response_has_balance(self, client, auth_headers):
        with patch("app.middleware.auth.get_db", return_value=make_mock_db({"profiles": SAMPLE_PROFILE})), \
             patch("app.routes.wallet.get_wallet", return_value=SAMPLE_WALLET):
            resp = client.get("/api/wallet", headers=auth_headers)
        assert resp.status_code == 200
        assert "balance" in resp.get_json()

    def test_tiers_list_has_entries(self, client):
        db = make_mock_db({"tiers": SAMPLE_TIERS})
        with patch("app.routes.hp.get_db", return_value=db):
            resp = client.get("/api/hp/tiers")
        assert resp.status_code == 200
        tiers = resp.get_json()
        assert len(tiers) >= 1

    def test_notifications_response_has_unread_count(self, client, auth_headers):
        db = make_mock_db({"notifications": [], "profiles": SAMPLE_PROFILE})
        with patch("app.middleware.auth.get_db", return_value=db), \
             patch("app.routes.notifications.get_db", return_value=db):
            resp = client.get("/api/notifications", headers=auth_headers)
        assert resp.status_code == 200
        data = resp.get_json()
        assert "unread_count" in data
        assert "notifications" in data

    def test_leaderboard_response_has_rankings(self, client):
        db = make_mock_db({"leaderboard_snapshots": [], "profiles": [SAMPLE_PROFILE]})
        with patch("app.routes.leaderboard.get_db", return_value=db):
            resp = client.get("/api/leaderboard")
        assert resp.status_code == 200
        data = resp.get_json()
        assert "rankings" in data
        assert "period_type" in data

    def test_error_response_has_error_key(self, client):
        resp = client.post("/api/auth/login", json={})
        assert resp.status_code == 400
        data = resp.get_json()
        assert "error" in data

    def test_rewards_list_is_array(self, client):
        db = make_mock_db({"rewards": [SAMPLE_REWARD]})
        with patch("app.routes.rewards.get_db", return_value=db):
            resp = client.get("/api/rewards")
        assert resp.status_code == 200
        data = resp.get_json()
        assert isinstance(data, list)


# ─────────────────────────────────────────────────────────────────────────────
# 9. Cross-user data isolation
# ─────────────────────────────────────────────────────────────────────────────
class TestDataIsolation:
    def _other_token(self):
        other_id = "aaaaaaaa-0000-0000-0000-000000000099"
        tok = jwt.encode(
            {"sub": other_id, "exp": int((datetime.now(timezone.utc) + timedelta(hours=1)).timestamp())},
            os.environ["JWT_SECRET"], algorithm="HS256"
        )
        return tok, other_id

    def test_cannot_view_another_users_order(self, client):
        other_tok, other_id = self._other_token()
        other_profile = {**SAMPLE_PROFILE, "id": other_id}
        db = make_mock_db({"profiles": other_profile, "orders": SAMPLE_ORDER})
        with patch("app.middleware.auth.get_db", return_value=db), \
             patch("app.routes.orders.get_db", return_value=db):
            resp = client.get(f"/api/orders/{ORDER_ID}",
                              headers={"Authorization": f"Bearer {other_tok}"})
        assert resp.status_code == 403

    def test_notifications_only_return_for_authenticated_user(self, client, auth_headers):
        notifs = [{"id": "n1", "user_id": STUDENT_ID, "title": "Yours",
                   "is_read": False, "channel": "in_app", "type": "hp_earned",
                   "body": "body", "created_at": "2026-01-01"}]
        db = make_mock_db({"notifications": notifs, "profiles": SAMPLE_PROFILE})
        with patch("app.middleware.auth.get_db", return_value=db), \
             patch("app.routes.notifications.get_db", return_value=db):
            resp = client.get("/api/notifications", headers=auth_headers)
        assert resp.status_code == 200

    def test_referrals_isolated_to_owner(self, client, auth_headers):
        db = make_mock_db({"referrals": [], "profiles": SAMPLE_PROFILE})
        with patch("app.middleware.auth.get_db", return_value=db), \
             patch("app.routes.referrals.get_db", return_value=db):
            resp = client.get("/api/referrals", headers=auth_headers)
        assert resp.status_code == 200

    def test_guest_order_requires_correct_claim_token(self, client):
        guest_order = {**SAMPLE_ORDER, "user_id": None, "claim_token": "correct-tok"}
        db = make_mock_db({"orders": guest_order})
        with patch("app.routes.orders.get_db", return_value=db):
            resp = client.get(f"/api/orders/{ORDER_ID}?claim_token=wrong-tok")
        assert resp.status_code == 403
