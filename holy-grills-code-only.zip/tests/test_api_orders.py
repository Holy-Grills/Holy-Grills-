"""API tests for /api/orders endpoints."""

import json
import pytest
from unittest.mock import patch
from tests.conftest import (
    make_mock_db, STUDENT_ID, ORDER_ID, MENU_ITEM_ID, WINDOW_ID,
    KITCHEN_ID, RIDER_ID, SAMPLE_ORDER, SAMPLE_MENU_ITEM, SAMPLE_WINDOW,
    SAMPLE_PROFILE, SAMPLE_KITCHEN_PROFILE,
    student_token, admin_token, kitchen_token, rider_token
)


@pytest.fixture(autouse=True)
def mock_db_auth(app):
    db = make_mock_db()
    with patch("app.middleware.auth.get_db", return_value=db):
        yield db


VALID_ORDER_PAYLOAD = {
    "items": [{"menu_item_id": MENU_ITEM_ID, "quantity": 1}],
    "delivery_window_id": WINDOW_ID,
    "payment_method": "card",
    "delivery_address": {"address_line": "FUTA Main Gate", "zone": "main"},
}


class TestCreateOrder:
    def test_authenticated_order_creation(self, client, auth_headers):
        db = make_mock_db({"orders": SAMPLE_ORDER})
        with patch("app.routes.orders.order_service.create_order", return_value=SAMPLE_ORDER):
            resp = client.post("/api/orders", json=VALID_ORDER_PAYLOAD, headers=auth_headers)
        assert resp.status_code == 201
        data = resp.get_json()
        assert data["status"] == "pending_payment"

    def test_guest_order_requires_name_phone(self, client):
        resp = client.post("/api/orders", json=VALID_ORDER_PAYLOAD)
        assert resp.status_code == 400
        assert "guest_name" in resp.get_json()["error"]

    def test_guest_order_succeeds_with_required_fields(self, client):
        payload = {
            **VALID_ORDER_PAYLOAD,
            "guest_name": "Guest User",
            "guest_phone": "08011112222",
        }
        with patch("app.routes.orders.order_service.create_order",
                   return_value={**SAMPLE_ORDER, "user_id": None}):
            resp = client.post("/api/orders", json=payload)
        assert resp.status_code == 201

    def test_guest_cannot_use_wallet(self, client):
        payload = {
            **VALID_ORDER_PAYLOAD,
            "guest_name": "Guest",
            "guest_phone": "08011112222",
            "payment_method": "wallet",
        }
        resp = client.post("/api/orders", json=payload)
        assert resp.status_code == 400
        assert "wallet" in resp.get_json()["error"].lower()

    def test_guest_cannot_redeem_hp(self, client):
        payload = {
            **VALID_ORDER_PAYLOAD,
            "guest_name": "Guest",
            "guest_phone": "08011112222",
            "hp_points_to_redeem": 100,
        }
        resp = client.post("/api/orders", json=payload)
        assert resp.status_code == 400


class TestListOrders:
    def test_lists_user_orders(self, client, auth_headers):
        db = make_mock_db({"orders": [SAMPLE_ORDER]})
        with patch("app.middleware.auth.get_db", return_value=db), \
             patch("app.routes.orders.get_db", return_value=db):
            resp = client.get("/api/orders", headers=auth_headers)
        assert resp.status_code == 200
        assert isinstance(resp.get_json(), list)

    def test_requires_auth(self, client):
        resp = client.get("/api/orders")
        assert resp.status_code == 401

    def test_status_filter(self, client, auth_headers):
        db = make_mock_db({"orders": [SAMPLE_ORDER]})
        with patch("app.middleware.auth.get_db", return_value=db), \
             patch("app.routes.orders.get_db", return_value=db):
            resp = client.get("/api/orders?status=pending_payment", headers=auth_headers)
        assert resp.status_code == 200


class TestGetOrder:
    def test_owner_can_view_order(self, client, auth_headers):
        db = make_mock_db({"orders": SAMPLE_ORDER})
        with patch("app.middleware.auth.get_db", return_value=db), \
             patch("app.routes.orders.get_db", return_value=db):
            resp = client.get(f"/api/orders/{ORDER_ID}", headers=auth_headers)
        assert resp.status_code == 200
        assert resp.get_json()["id"] == ORDER_ID

    def test_other_user_denied(self, client):
        import jwt, os
        from datetime import datetime, timezone, timedelta
        other_id = "aaaaaaaa-0000-0000-0000-000000000099"
        other_token = jwt.encode(
            {"sub": other_id, "exp": int((datetime.now(timezone.utc) + timedelta(hours=1)).timestamp())},
            os.environ["JWT_SECRET"], algorithm="HS256"
        )
        other_profile = {**SAMPLE_PROFILE, "id": other_id}
        db = make_mock_db({"profiles": other_profile, "orders": SAMPLE_ORDER})
        with patch("app.middleware.auth.get_db", return_value=db), \
             patch("app.routes.orders.get_db", return_value=db):
            resp = client.get(
                f"/api/orders/{ORDER_ID}",
                headers={"Authorization": f"Bearer {other_token}"}
            )
        assert resp.status_code == 403

    def test_guest_with_valid_claim_token(self, client):
        order_with_token = {**SAMPLE_ORDER, "user_id": None, "claim_token": "abc123"}
        db = make_mock_db({"orders": order_with_token})
        with patch("app.routes.orders.get_db", return_value=db):
            resp = client.get(f"/api/orders/{ORDER_ID}?claim_token=abc123")
        assert resp.status_code == 200

    def test_guest_with_wrong_claim_token(self, client):
        order_with_token = {**SAMPLE_ORDER, "user_id": None, "claim_token": "abc123"}
        db = make_mock_db({"orders": order_with_token})
        with patch("app.routes.orders.get_db", return_value=db):
            resp = client.get(f"/api/orders/{ORDER_ID}?claim_token=wrong")
        assert resp.status_code == 403


class TestUpdateOrderStatus:
    def test_kitchen_can_set_preparing(self, client, kitchen_headers):
        order = {**SAMPLE_ORDER, "status": "received"}
        db = make_mock_db({"profiles": {**SAMPLE_PROFILE, "id": KITCHEN_ID, "role": "kitchen"}, "orders": order})
        with patch("app.middleware.auth.get_db", return_value=db), \
             patch("app.routes.orders.order_service.update_order_status",
                   return_value={**order, "status": "preparing"}):
            resp = client.patch(
                f"/api/orders/{ORDER_ID}/status",
                json={"status": "preparing"},
                headers=kitchen_headers,
            )
        assert resp.status_code == 200

    def test_student_cannot_update_status(self, client, auth_headers):
        db = make_mock_db()
        with patch("app.middleware.auth.get_db", return_value=db):
            resp = client.patch(
                f"/api/orders/{ORDER_ID}/status",
                json={"status": "preparing"},
                headers=auth_headers,
            )
        assert resp.status_code == 403

    def test_missing_status_returns_400(self, client, kitchen_headers):
        db = make_mock_db({"profiles": {**SAMPLE_PROFILE, "id": KITCHEN_ID, "role": "kitchen"}})
        with patch("app.middleware.auth.get_db", return_value=db):
            resp = client.patch(
                f"/api/orders/{ORDER_ID}/status",
                json={},
                headers=kitchen_headers,
            )
        assert resp.status_code == 400


class TestSubmitReview:
    def test_review_on_delivered_order(self, client, auth_headers):
        delivered = {**SAMPLE_ORDER, "status": "delivered", "review_submitted": False}
        db = make_mock_db({
            "orders": delivered,
            "order_reviews": [],
        })
        with patch("app.middleware.auth.get_db", return_value=db), \
             patch("app.routes.orders.get_db", return_value=db), \
             patch("app.routes.orders.earn_pending_hp", return_value={"added_to_pending": 20}):
            resp = client.post(
                f"/api/orders/{ORDER_ID}/review",
                json={"rating": "5", "comment": "Great food!"},
                headers=auth_headers,
            )
        assert resp.status_code == 201
        data = resp.get_json()
        assert "review" in data

    def test_cannot_review_non_delivered(self, client, auth_headers):
        db = make_mock_db({"orders": SAMPLE_ORDER})
        with patch("app.middleware.auth.get_db", return_value=db), \
             patch("app.routes.orders.get_db", return_value=db):
            resp = client.post(
                f"/api/orders/{ORDER_ID}/review",
                json={"rating": "4"},
                headers=auth_headers,
            )
        assert resp.status_code == 400

    def test_cannot_review_twice(self, client, auth_headers):
        already_reviewed = {**SAMPLE_ORDER, "status": "delivered", "review_submitted": True}
        db = make_mock_db({"orders": already_reviewed})
        with patch("app.middleware.auth.get_db", return_value=db), \
             patch("app.routes.orders.get_db", return_value=db):
            resp = client.post(
                f"/api/orders/{ORDER_ID}/review",
                json={"rating": "3"},
                headers=auth_headers,
            )
        assert resp.status_code == 400
        assert "already reviewed" in resp.get_json()["error"]
