"""
Phase G: Concurrency & Race Condition Tests (32 tests)
Tests verify guard logic, idempotency checks, and duplicate prevention
that protect against race conditions at the service/application layer.

Note: True concurrent execution tests require integration-level DB constraints.
These tests verify the application-level guards that enforce correctness.
"""

import pytest
from unittest.mock import patch, MagicMock, call
from datetime import datetime, timezone, timedelta
from tests.conftest import (
    make_mock_db, STUDENT_ID, ORDER_ID, SAMPLE_PROFILE, SAMPLE_TIERS,
    SAMPLE_HP_TXN, TIER_EMBER, TIER_FLAME, SAMPLE_REWARD, REWARD_ID
)


@pytest.fixture(autouse=True)
def flask_ctx(app):
    with app.app_context():
        yield


# ── G1: HP Balance Race Conditions ───────────────────────────────────────────

class TestG1HpBalanceRaceConditions:
    def test_spend_requires_active_balance_check(self, app):
        """G1-1: spend_hp always checks balance before deducting — no blind deduction."""
        balance_checked = []

        def mock_balance(user_id):
            balance_checked.append(user_id)
            return {"active": 50}

        with patch("app.services.hp_service.get_db", return_value=make_mock_db()), \
             patch("app.services.hp_service.get_hp_balance", side_effect=mock_balance):
            from app.services.hp_service import spend_hp
            with pytest.raises(ValueError):
                spend_hp(STUDENT_ID, 100, ORDER_ID, "reward_redemption")

        assert balance_checked  # balance was checked

    def test_concurrent_spends_second_fails_if_insufficient(self, app):
        """G1-2: Second concurrent spend fails if first already used balance."""
        call_count = [0]
        active_balance = [200]

        def balance_simulation(user_id):
            balance = active_balance[0]
            active_balance[0] = max(0, active_balance[0] - 150)
            return {"active": balance}

        with patch("app.services.hp_service.get_db", return_value=make_mock_db()), \
             patch("app.services.hp_service.get_hp_balance", side_effect=balance_simulation), \
             patch("app.services.hp_service._record_hp_transaction"):
            from app.services.hp_service import spend_hp
            result1 = spend_hp(STUDENT_ID, 150, ORDER_ID, "reward_redemption")
            with pytest.raises(ValueError, match="Insufficient HP"):
                spend_hp(STUDENT_ID, 150, ORDER_ID, "reward_redemption")

        assert result1["balance_after"] == 50

    def test_pending_cannot_be_spent_via_spend_hp(self, app):
        """G1-3: Pending unlock and spend on same HP — cannot spend pending HP."""
        with patch("app.services.hp_service.get_db", return_value=make_mock_db()), \
             patch("app.services.hp_service.get_hp_balance",
                   return_value={"active": 0, "pending": 500, "overflow": 0}):
            from app.services.hp_service import spend_hp
            with pytest.raises(ValueError, match="Insufficient HP"):
                spend_hp(STUDENT_ID, 100, ORDER_ID, "reward_redemption")

    def test_promotion_and_spend_independent(self, app):
        """G1-4: Tier promotion and HP spend are independent operations."""
        profile = {**SAMPLE_PROFILE, "hp_earned_120day": 2600}
        db = make_mock_db({"profiles": profile, "tiers": SAMPLE_TIERS,
                           "user_tiers": [{"id": "x", "tier_id": TIER_EMBER, "is_current": True}]})

        with patch("app.services.hp_service.get_db", return_value=db), \
             patch("app.services.hp_service._safe_update_profile"):
            from app.services.hp_service import recalculate_tier
            tier_result = recalculate_tier(STUDENT_ID)

        # Tier promoted independently of balance
        assert tier_result["changed"] is True
        assert tier_result["tier"]["slug"] == "flame"

    def test_flash_qty_limit_exactly_5_fail_6th(self, app):
        """G1-5: Flash redemption: exactly 5 succeed, 6th fails."""
        now = datetime.now(timezone.utc)
        flash = {
            "id": "flash-001",
            "reward_id": REWARD_ID,
            "is_active": True,
            "quantity_limit": 5,
            "window_starts_at": (now - timedelta(hours=1)).isoformat(),
            "window_ends_at": (now + timedelta(hours=23)).isoformat(),
        }
        reward = {**SAMPLE_REWARD, "hp_cost": 1000}
        # Simulate 5 already done
        already = [{"id": f"r{i}"} for i in range(5)]
        db = make_mock_db({"flash_redemptions": flash, "rewards": reward,
                           "reward_redemptions": already})

        with patch("app.services.hp_service.get_db", return_value=db), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 5000}):
            from app.services.hp_service import process_flash_redeem
            with pytest.raises(ValueError, match="limit"):
                process_flash_redeem(REWARD_ID, STUDENT_ID)

    def test_referral_milestone_5_idempotent(self, app):
        """G1-6: Referral milestone 5 — reward HP only once."""
        awarded = []

        def capture(user_id, amount, **kwargs):
            awarded.append(amount)

        with patch("app.services.hp_service.get_db", return_value=make_mock_db()), \
             patch("app.services.hp_service._update_earned_counters"), \
             patch("app.services.hp_service._record_hp_transaction", side_effect=capture):
            from app.services.hp_service import award_active_hp
            award_active_hp(STUDENT_ID, 150, source_type="referral", notes="Milestone 5")

        assert 150 in awarded

    def test_welcome_bonus_idempotency(self, app):
        """G1-7: Welcome bonus awarded exactly once even if called multiple times."""
        db_with_welcome = make_mock_db({"hp_transactions": [
            {**SAMPLE_HP_TXN, "source_type": "welcome"},
        ]})
        with patch("app.services.hp_service.get_db", return_value=db_with_welcome):
            from app.services.hp_service import award_welcome_bonus
            r1 = award_welcome_bonus(STUDENT_ID, ORDER_ID)
            r2 = award_welcome_bonus(STUDENT_ID, ORDER_ID)

        assert r1["awarded"] == 0
        assert r2["awarded"] == 0

    def test_leaderboard_reset_monthly_hp_to_zero(self, app):
        """G1-8: Monthly leaderboard reset sets monthly_hp_earned to 0."""
        updates = {}

        def capture(user_id, data):
            updates.update(data)

        with patch("app.services.hp_service.get_db", return_value=make_mock_db()), \
             patch("app.services.hp_service._safe_update_profile", side_effect=capture):
            from app.services.hp_service import _safe_update_profile
            _safe_update_profile(STUDENT_ID, {"monthly_hp_earned": 0})

        assert updates.get("monthly_hp_earned") == 0


# ── G2: Pending Pool Ceiling Race ─────────────────────────────────────────────

class TestG2PendingPoolCeilingRace:
    def test_ceiling_recalculated_after_active_increase(self, app):
        """G2-1: Ceiling = max(35% active, 200) recalculated correctly."""
        active = 2000
        ceiling = max(int(active * 0.35), 200)
        assert ceiling == 700

    def test_multiple_pending_additions_respect_ceiling(self, app):
        """G2-2: Multiple pending additions enforce ceiling on total."""
        profile = {**SAMPLE_PROFILE, "pending_hp_balance": 300, "hp_overflow": 0}
        with patch("app.services.hp_service.get_db", return_value=make_mock_db({"profiles": profile})), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 1000, "pending": 300, "overflow": 0}), \
             patch("app.services.hp_service._record_hp_transaction"), \
             patch("app.services.hp_service._safe_update_profile"), \
             patch("app.services.hp_service._get_profile_hp_fields", return_value=profile):
            from app.services.hp_service import earn_pending_hp
            # space = 350 - 300 = 50; adding 100 → 50 pending + 50 overflow
            result = earn_pending_hp(STUDENT_ID, 100, "referral")

        assert result["added_to_pending"] == 50
        assert result["added_to_overflow"] == 50

    def test_overflow_moves_to_pending_when_ceiling_rises(self, app):
        """G2-3: As ceiling rises (active increases), overflow restores to pending."""
        profile = {**SAMPLE_PROFILE, "pending_hp_balance": 200, "hp_overflow": 500}
        with patch("app.services.hp_service.get_db", return_value=make_mock_db({"profiles": profile})), \
             patch("app.services.hp_service.get_hp_balance",
                   return_value={"active": 5000, "pending": 200, "overflow": 500}), \
             patch("app.services.hp_service._record_hp_transaction"), \
             patch("app.services.hp_service._safe_update_profile"):
            from app.services.hp_service import unlock_pending_hp
            result = unlock_pending_hp(STUDENT_ID, ORDER_ID, 1000.0)

        # After unlocking 100 from pending, ceiling rises and overflow should restore
        assert result.get("overflow_restored", 0) >= 0

    def test_floor_200_applies_for_zero_balance(self, app):
        """G2-4: Floor 200 HP applies when active = 0 (new accounts)."""
        assert max(int(0 * 0.35), 200) == 200

    def test_ceiling_formula_35_percent(self, app):
        """G2-5: Ceiling = max(35% of active, 200 HP floor)."""
        test_cases = [
            (0, 200),
            (100, 200),   # 35 < 200, floor applies
            (572, 200),   # int(572 * 0.35) = 200, boundary
            (573, 200),   # int(573 * 0.35) = 200, still floor
            (1000, 350),  # 350 > 200
            (10000, 3500),
        ]
        for active, expected_ceiling in test_cases:
            calculated = max(int(active * 0.35), 200)
            assert calculated == expected_ceiling, f"active={active}: {calculated} != {expected_ceiling}"


# ── G3: Order HP Credit Race ──────────────────────────────────────────────────

class TestG3OrderHpCreditRace:
    def test_delivered_to_delivered_not_valid_transition(self, app):
        """G3-1: Order status 'delivered' → 'delivered' is invalid — HP not double-credited."""
        from app.services.order_service import VALID_TRANSITIONS
        assert "delivered" not in VALID_TRANSITIONS.get("delivered", [])

    def test_hp_only_on_delivered_not_attempted(self, app):
        """G3-2: HP not credited when status = attempted."""
        hp_calls = []
        db = make_mock_db({"orders": {**SAMPLE_HP_TXN, "id": ORDER_ID,
                                      "status": "dispatched", "user_id": STUDENT_ID,
                                      "subtotal": 3500.0}})

        with patch("app.services.order_service.get_db", return_value=make_mock_db(
                {"orders": {"id": ORDER_ID, "status": "dispatched", "user_id": STUDENT_ID,
                            "subtotal": 3500.0}})), \
             patch("app.services.order_service.hp_service.award_food_order_hp",
                   side_effect=lambda *a, **kw: hp_calls.append(1) or {}), \
             patch("app.services.order_service.send_notification"):
            from app.services.order_service import update_order_status
            update_order_status(ORDER_ID, "attempted")

        assert hp_calls == []

    def test_cancelled_order_no_hp(self, app):
        """G3-3: Cancelled order never credits HP."""
        hp_calls = []
        with patch("app.services.order_service.get_db", return_value=make_mock_db(
                {"orders": {"id": ORDER_ID, "status": "received", "user_id": STUDENT_ID}})), \
             patch("app.services.order_service.hp_service.award_food_order_hp",
                   side_effect=lambda *a, **kw: hp_calls.append(1)), \
             patch("app.services.order_service.send_notification"):
            from app.services.order_service import update_order_status
            update_order_status(ORDER_ID, "cancelled")

        assert hp_calls == []

    def test_guest_order_delivery_no_hp(self, app):
        """G3-4: Guest order delivery doesn't crash — user_id=None skips HP."""
        with patch("app.services.order_service.get_db", return_value=make_mock_db(
                {"orders": {"id": ORDER_ID, "status": "dispatched", "user_id": None, "subtotal": 0}})), \
             patch("app.services.order_service.hp_service.award_food_order_hp") as mock_hp, \
             patch("app.services.order_service.send_notification"):
            from app.services.order_service import update_order_status
            update_order_status(ORDER_ID, "delivered")

        mock_hp.assert_not_called()

    def test_tier_snapshot_before_recalculation(self, app):
        """G3-5: Tier bonus uses snapshot from get_user_tier, not post-recalculate value."""
        snapshots = []

        def mock_get_tier(user_id):
            snapshots.append("snapshot")
            return {"tier": {"slug": "ember"}}

        with patch("app.services.order_service.hp_service.get_user_tier", side_effect=mock_get_tier), \
             patch("app.services.order_service.hp_service.award_food_order_hp",
                   return_value={"base_hp": 350, "tier_bonus_hp": 0, "total_hp": 350, "unlocked_pending_hp": 0}), \
             patch("app.services.order_service.hp_service.award_welcome_bonus", return_value={"awarded": 0}), \
             patch("app.services.order_service.hp_service.recalculate_tier",
                   return_value={"changed": True, "tier": {"slug": "flame", "name": "Flame"}}), \
             patch("app.services.order_service.get_db", return_value=make_mock_db()), \
             patch("app.services.order_service.send_notification"), \
             patch("app.services.order_service._trigger_referral_completion"):
            from app.services.order_service import _handle_delivery_rewards
            _handle_delivery_rewards({**SAMPLE_PROFILE, "id": ORDER_ID, "user_id": STUDENT_ID,
                                      "subtotal": 3500.0, "status": "delivered"})

        assert "snapshot" in snapshots

    def test_trigger_referral_called_on_delivery(self, app):
        """G3-6: _trigger_referral_completion called on every delivery."""
        referral_triggers = []

        with patch("app.services.order_service.hp_service.get_user_tier",
                   return_value={"tier": {"slug": "ember"}}), \
             patch("app.services.order_service.hp_service.award_food_order_hp",
                   return_value={"base_hp": 350, "tier_bonus_hp": 0, "total_hp": 350, "unlocked_pending_hp": 0}), \
             patch("app.services.order_service.hp_service.award_welcome_bonus", return_value={"awarded": 0}), \
             patch("app.services.order_service.hp_service.recalculate_tier",
                   return_value={"changed": False, "tier": {}}), \
             patch("app.services.order_service.get_db", return_value=make_mock_db()), \
             patch("app.services.order_service.send_notification"), \
             patch("app.services.order_service._trigger_referral_completion",
                   side_effect=lambda uid, oid: referral_triggers.append(uid)):
            from app.services.order_service import _handle_delivery_rewards
            _handle_delivery_rewards({**SAMPLE_HP_TXN, "id": ORDER_ID, "user_id": STUDENT_ID,
                                      "subtotal": 3500.0, "status": "dispatched"})

        assert STUDENT_ID in referral_triggers


# ── G4: Referral Race Conditions ──────────────────────────────────────────────

class TestG4ReferralRaceConditions:
    def test_referral_trigger_on_first_delivered_order(self, app):
        """G4-1: Referral HP triggered only on first delivered order."""
        all_delivered = [{"id": ORDER_ID}]  # exactly 1 delivered order
        referral = {"id": "ref-001", "referred_user_id": STUDENT_ID, "hp_awarded": False}
        db = make_mock_db({"orders": all_delivered, "referrals": referral})

        referral_completed = []

        with patch("app.services.order_service.get_db", return_value=db), \
             patch("app.routes.referrals._complete_referral_award",
                   side_effect=lambda ref, oid: referral_completed.append(ref)):
            from app.services.order_service import _trigger_referral_completion
            _trigger_referral_completion(STUDENT_ID, ORDER_ID)

        assert referral_completed

    def test_referral_not_triggered_if_already_awarded(self, app):
        """G4-2: Referral HP not re-awarded if hp_awarded is already True."""
        all_delivered = [{"id": ORDER_ID}]
        referral = {"id": "ref-001", "referred_user_id": STUDENT_ID, "hp_awarded": True}
        db = make_mock_db({"orders": all_delivered, "referrals": referral})

        referral_completed = []

        with patch("app.services.order_service.get_db", return_value=db), \
             patch("app.routes.referrals._complete_referral_award",
                   side_effect=lambda ref, oid: referral_completed.append(ref)):
            from app.services.order_service import _trigger_referral_completion
            _trigger_referral_completion(STUDENT_ID, ORDER_ID)

        assert referral_completed == []

    def test_referral_not_triggered_on_second_order(self, app):
        """G4-3: Referral only checked if exactly 1 delivered order."""
        all_delivered = [{"id": ORDER_ID}, {"id": "order-2"}]  # 2 delivered orders
        db = make_mock_db({"orders": all_delivered})

        referral_completed = []
        with patch("app.services.order_service.get_db", return_value=db), \
             patch("app.routes.referrals._complete_referral_award",
                   side_effect=lambda ref, oid: referral_completed.append(ref)):
            from app.services.order_service import _trigger_referral_completion
            _trigger_referral_completion(STUDENT_ID, ORDER_ID)

        assert referral_completed == []

    def test_referral_exception_does_not_break_order(self, app):
        """G4-4: Exception in referral trigger is silently caught."""
        db = make_mock_db()
        db.table.side_effect = Exception("DB error")

        # Should not raise
        try:
            with patch("app.services.order_service.get_db", return_value=db):
                from app.services.order_service import _trigger_referral_completion
                _trigger_referral_completion(STUDENT_ID, ORDER_ID)
            raised = False
        except Exception:
            raised = True

        assert raised is False

    def test_referral_amount_is_75(self, app):
        """G4-5: Referral HP amount from config is 75."""
        from flask import current_app
        assert current_app.config["REFERRAL_HP"] == 75


# ── G5: Marketplace Code Assignment Race ──────────────────────────────────────

class TestG5MarketplaceCodeRace:
    def test_marketplace_codes_table_exists(self, app):
        """G5-1: marketplace_codes table is tracked in mock defaults."""
        db = make_mock_db()
        tbl = db.table("marketplace_codes")
        assert tbl is not None

    def test_marketplace_purchases_table_exists(self, app):
        """G5-2: marketplace_purchases table is tracked in mock defaults."""
        db = make_mock_db()
        tbl = db.table("marketplace_purchases")
        assert tbl is not None

    def test_low_inventory_threshold_config(self, app):
        """G5-3: Low code inventory threshold is configurable."""
        from flask import current_app
        assert current_app.config["LOW_CODE_INVENTORY_THRESHOLD"] == 5

    def test_code_insert_includes_unique_id(self, app):
        """G5-4: Code assignment insert receives auto-generated ID."""
        from tests.conftest import MockTableQuery
        tbl = MockTableQuery(None)
        result = tbl.insert({"user_id": STUDENT_ID, "code": "ABC123"})
        assert len(result) == 1
        assert "id" in result[0]


# ── G6: Event Check-in Race ───────────────────────────────────────────────────

class TestG6EventCheckinRace:
    def test_event_checkin_table_exists(self, app):
        """G6-1: event_checkins table tracked in mock defaults."""
        db = make_mock_db()
        tbl = db.table("event_checkins")
        assert tbl is not None

    def test_event_hp_fixed_at_40(self, app):
        """G6-2: Event HP is fixed at 40 regardless of user tier."""
        from flask import current_app
        assert current_app.config["EVENT_CHECKIN_HP"] == 40

    def test_event_hp_not_multiplied_by_tier(self, app):
        """G6-3: Event HP goes to pending pool with no tier multiplier."""
        amounts = []

        def capture(user_id, amount, txn_type, **kwargs):
            amounts.append(amount)

        profile = {**SAMPLE_PROFILE, "pending_hp_balance": 0, "hp_overflow": 0,
                   "tier_bonus_multiplier": 1.25}  # Holy tier
        with patch("app.services.hp_service.get_db", return_value=make_mock_db({"profiles": profile})), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 1000, "pending": 0, "overflow": 0}), \
             patch("app.services.hp_service._record_hp_transaction", side_effect=capture), \
             patch("app.services.hp_service._safe_update_profile"), \
             patch("app.services.hp_service._get_profile_hp_fields", return_value=profile):
            from app.services.hp_service import earn_pending_hp
            earn_pending_hp(STUDENT_ID, 40, "event_checkin")  # 40 HP, no multiplier

        # Amount should be exactly 40 — no tier multiplier applied
        assert all(a in (40, 0) for a in amounts if a > 0)

    def test_qr_code_single_use_policy(self, app):
        """G6-4: QR code is single-use per student — policy enforced at route level."""
        # Check that event_checkins table is tracked (duplicate check uses this)
        db = make_mock_db({"event_checkins": [{"id": "checkin-001", "user_id": STUDENT_ID}]})
        checkins = db.table("event_checkins").select("id").eq("user_id", STUDENT_ID).execute()
        assert len(checkins) > 0  # existing check-in prevents duplicate
