"""
Integration tests — full end-to-end flows through multiple services.
Simulates real user journeys: register → order → pay → HP earned → redeem.
"""

import pytest
from unittest.mock import patch, MagicMock, call
from tests.conftest import (
    make_mock_db, STUDENT_ID, ORDER_ID, MENU_ITEM_ID, WINDOW_ID, REWARD_ID,
    SAMPLE_ORDER, SAMPLE_MENU_ITEM, SAMPLE_WINDOW, SAMPLE_PROFILE,
    SAMPLE_REWARD, SAMPLE_TIERS, SAMPLE_HP_TXN, SAMPLE_WALLET,
    student_token
)


@pytest.fixture(autouse=True)
def flask_ctx(app):
    with app.app_context():
        yield


class TestOrderCompletionHpFlow:
    """
    Simulates the full HP award sequence on order delivery per Master Brand Doc:
    1. Base food HP (1 HP/₦10) → ACTIVE
    2. Tier bonus → ACTIVE
    3. Unlock pending HP (100 HP/₦1,000)
    4. Welcome bonus on first order (50 HP → ACTIVE)
    5. Tier recalculation
    """

    def test_ember_tier_full_delivery_flow(self, app):
        """₦3,500 order, Ember tier: 350 base + 0 bonus + welcome 50 = 400 total active"""
        with patch("app.services.order_service.hp_service.award_food_order_hp",
                   return_value={"base_hp": 350, "tier_bonus_hp": 0, "total_hp": 350, "unlocked_pending_hp": 350}) as mock_food, \
             patch("app.services.order_service.hp_service.award_welcome_bonus",
                   return_value={"awarded": 50}) as mock_welcome, \
             patch("app.services.order_service.hp_service.recalculate_tier",
                   return_value={"tier": {"slug": "ember", "name": "Ember"}, "changed": False}) as mock_tier, \
             patch("app.services.order_service.hp_service.get_user_tier",
                   return_value={"tier": {"slug": "ember"}}), \
             patch("app.services.order_service.get_db", return_value=make_mock_db()), \
             patch("app.services.order_service.send_notification"), \
             patch("app.services.order_service._trigger_referral_completion"):
            from app.services.order_service import _handle_delivery_rewards
            _handle_delivery_rewards({**SAMPLE_ORDER, "user_id": STUDENT_ID, "subtotal": 3500.0, "status": "delivered"})

        mock_food.assert_called_once_with(user_id=STUDENT_ID, order_id=ORDER_ID, order_total=3500.0, tier_slug="ember")
        mock_welcome.assert_called_once_with(STUDENT_ID, ORDER_ID)
        mock_tier.assert_called_once_with(STUDENT_ID)

    def test_flame_tier_bonus_applied(self, app):
        """Flame (1.08x): ₦1,000 → 100 base + 8 bonus = 108 HP"""
        with patch("app.services.hp_service.unlock_pending_hp", return_value={"unlocked": 0}), \
             patch("app.services.hp_service._update_earned_counters"), \
             patch("app.services.hp_service._record_hp_transaction"), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 0}):
            from app.services.hp_service import award_food_order_hp
            result = award_food_order_hp(STUDENT_ID, ORDER_ID, 1000.0, "flame")
        assert result["total_hp"] == 108
        assert result["tier_bonus_hp"] == 8

    def test_pending_unlock_100_per_1000(self, app):
        """₦3,500 food spend → unlock floor(3500/1000)*100 = 300 HP from pending"""
        profile = {**SAMPLE_PROFILE, "pending_hp_balance": 500, "hp_overflow": 0}
        with patch("app.services.hp_service.get_db", return_value=make_mock_db({"profiles": profile})), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 1000, "pending": 500, "overflow": 0}), \
             patch("app.services.hp_service._record_hp_transaction"), \
             patch("app.services.hp_service._safe_update_profile"):
            from app.services.hp_service import unlock_pending_hp
            result = unlock_pending_hp(STUDENT_ID, ORDER_ID, 3500.0)
        assert result["unlocked"] == 300


class TestPendingPoolFlow:
    """Tests the pending pool ceiling, overflow, and restore mechanics."""

    def test_referral_goes_to_pending(self, app):
        """75 HP referral reward → pending (not active)"""
        profile = {**SAMPLE_PROFILE, "pending_hp_balance": 0, "hp_overflow": 0}
        with patch("app.services.hp_service.get_db", return_value=make_mock_db({"profiles": profile})), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 1000, "pending": 0, "overflow": 0}), \
             patch("app.services.hp_service._record_hp_transaction") as mock_record, \
             patch("app.services.hp_service._safe_update_profile"), \
             patch("app.services.hp_service._get_profile_hp_fields", return_value=profile):
            from app.services.hp_service import earn_pending_hp
            result = earn_pending_hp(STUDENT_ID, 75, "referral", ORDER_ID)

        assert result["added_to_pending"] == 75
        # Verify the transaction was recorded with status='pending'
        mock_record.assert_called_once()
        assert mock_record.call_args.kwargs["status"] == "pending"

    def test_event_hp_goes_to_pending(self, app):
        """40 HP event check-in → pending"""
        profile = {**SAMPLE_PROFILE, "pending_hp_balance": 0, "hp_overflow": 0}
        with patch("app.services.hp_service.get_db", return_value=make_mock_db({"profiles": profile})), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 0, "pending": 0, "overflow": 0}), \
             patch("app.services.hp_service._record_hp_transaction"), \
             patch("app.services.hp_service._safe_update_profile"), \
             patch("app.services.hp_service._get_profile_hp_fields", return_value=profile):
            from app.services.hp_service import earn_pending_hp
            result = earn_pending_hp(STUDENT_ID, 40, "event")
        assert result["added_to_pending"] == 40

    def test_35_percent_ceiling_enforced(self, app):
        """Active=1000. Ceiling=350. Pending=300. Space=50. 75 HP → 50 pending + 25 overflow."""
        profile = {**SAMPLE_PROFILE, "pending_hp_balance": 300, "hp_overflow": 0}
        with patch("app.services.hp_service.get_db", return_value=make_mock_db({"profiles": profile})), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 1000, "pending": 300, "overflow": 0}), \
             patch("app.services.hp_service._record_hp_transaction"), \
             patch("app.services.hp_service._safe_update_profile"), \
             patch("app.services.hp_service._get_profile_hp_fields", return_value=profile):
            from app.services.hp_service import earn_pending_hp
            result = earn_pending_hp(STUDENT_ID, 75, "challenge")
        assert result["added_to_pending"] == 50
        assert result["added_to_overflow"] == 25

    def test_floor_200hp_applies_for_zero_balance(self, app):
        """Active=0. Ceiling=max(0,200)=200 (floor). 200 HP fits, 1 extra → overflow."""
        profile = {**SAMPLE_PROFILE, "pending_hp_balance": 199, "hp_overflow": 0}
        with patch("app.services.hp_service.get_db", return_value=make_mock_db({"profiles": profile})), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 0, "pending": 199, "overflow": 0}), \
             patch("app.services.hp_service._record_hp_transaction"), \
             patch("app.services.hp_service._safe_update_profile"), \
             patch("app.services.hp_service._get_profile_hp_fields", return_value=profile):
            from app.services.hp_service import earn_pending_hp
            result = earn_pending_hp(STUDENT_ID, 40, "event")
        assert result["added_to_pending"] == 1
        assert result["added_to_overflow"] == 39


class TestReferralFlow:
    def test_referral_hp_amount_is_75(self, app):
        """Referral HP must be exactly 75 (not 200 — updated in Master Brand Doc)"""
        from app.config import Config
        assert Config.REFERRAL_HP == 75

    def test_event_hp_amount_is_40(self, app):
        from app.config import Config
        assert Config.EVENT_CHECKIN_HP == 40

    def test_review_hp_amount_is_20(self, app):
        from app.config import Config
        assert Config.REVIEW_HP == 20

    def test_welcome_bonus_is_50(self, app):
        from app.config import Config
        assert Config.WELCOME_BONUS_HP == 50

    def test_birthday_hp_is_150(self, app):
        from app.config import Config
        assert Config.BIRTHDAY_HP == 150


class TestWalletIntegration:
    def test_wallet_debit_called_on_wallet_order(self, app):
        """When payment_method=wallet, wallet must be debited on payment confirmation"""
        order = {
            **SAMPLE_ORDER,
            "status": "pending_payment",
            "payment_method": "wallet",
            "wallet_amount_used": 3500.0,
            "hp_points_used": 0,
        }
        db = make_mock_db({"orders": order})

        with patch("app.services.order_service.get_db", return_value=db), \
             patch("app.services.order_service.send_notification"), \
             patch("app.services.order_service._log_status_change"), \
             patch("app.services.order_service.debit_wallet") as mock_debit, \
             patch("app.services.order_service.hp_service.spend_hp"):
            from app.services.order_service import confirm_order_payment
            confirm_order_payment(ORDER_ID, "WALLET-INTERNAL")
        mock_debit.assert_called_once()
        assert mock_debit.call_args.kwargs["amount"] == 3500.0


class TestStateMachineCompleteness:
    """Verify all 39 possible transitions — valid ones succeed, invalid ones fail."""

    VALID = {
        ("pending_payment", "received"),
        ("pending_payment", "cancelled"),
        ("received", "preparing"),
        ("received", "cancelled"),
        ("preparing", "ready"),
        ("preparing", "cancelled"),
        ("ready", "dispatched"),
        ("ready", "cancelled"),
        ("dispatched", "delivered"),
        ("dispatched", "attempted"),
        ("attempted", "delivered"),
        ("attempted", "unclaimed"),
        ("unclaimed", "cancelled"),
    }

    ALL_STATUSES = ["pending_payment", "received", "preparing", "ready",
                    "dispatched", "delivered", "attempted", "unclaimed", "cancelled"]

    @pytest.mark.parametrize("from_s,to_s", [
        (f, t) for f in ["pending_payment","received","preparing","ready","dispatched","attempted","unclaimed"]
        for t in ["received","preparing","ready","dispatched","delivered","attempted","unclaimed","cancelled"]
    ])
    def test_transitions(self, app, from_s, to_s):
        from app.services.order_service import VALID_TRANSITIONS
        allowed = VALID_TRANSITIONS.get(from_s, [])
        if to_s in allowed:
            assert (from_s, to_s) in self.VALID or to_s in allowed
        else:
            assert (from_s, to_s) not in self.VALID
