"""
Phase K: Edge Case & Stress Tests (20 tests)
K1: Extreme Value Tests
K2: Boundary Condition Tests
K3: Negative & Zero Tests
K4: API Input Validation Tests
"""

import math
import pytest
from unittest.mock import patch, MagicMock
from tests.conftest import (
    make_mock_db, STUDENT_ID, ORDER_ID, SAMPLE_PROFILE, SAMPLE_HP_TXN,
    SAMPLE_ORDER, SAMPLE_TIERS, SAMPLE_REWARD, REWARD_ID, SAMPLE_MENU_ITEM,
    SAMPLE_WINDOW, MENU_ITEM_ID, WINDOW_ID, TIER_EMBER, TIER_FLAME
)


@pytest.fixture(autouse=True)
def flask_ctx(app):
    with app.app_context():
        yield


# ── K1: Extreme Value Tests ───────────────────────────────────────────────────

class TestK1ExtremeValues:
    def test_max_order_100000_earns_10000_hp(self, app):
        """K1-1: Maximum ₦100,000 order earns 10,000 base HP + tier bonus."""
        with patch("app.services.hp_service.get_db", return_value=make_mock_db()), \
             patch("app.services.hp_service.unlock_pending_hp", return_value={"unlocked": 0}), \
             patch("app.services.hp_service._update_earned_counters"), \
             patch("app.services.hp_service._record_hp_transaction"):
            from app.services.hp_service import award_food_order_hp
            result = award_food_order_hp(STUDENT_ID, ORDER_ID, 100000.0, "ember")

        assert result["base_hp"] == 10000
        assert result["tier_bonus_hp"] == 0
        assert result["total_hp"] == 10000

    def test_max_order_holy_tier_bonus(self, app):
        """K1-1b: ₦100,000 order with Holy tier earns 10,000 + 2,500 = 12,500 HP."""
        with patch("app.services.hp_service.get_db", return_value=make_mock_db()), \
             patch("app.services.hp_service.unlock_pending_hp", return_value={"unlocked": 0}), \
             patch("app.services.hp_service._update_earned_counters"), \
             patch("app.services.hp_service._record_hp_transaction"):
            from app.services.hp_service import award_food_order_hp
            result = award_food_order_hp(STUDENT_ID, ORDER_ID, 100000.0, "holy")

        assert result["base_hp"] == 10000
        assert result["tier_bonus_hp"] == 2500
        assert result["total_hp"] == 12500

    def test_1_million_active_hp_balance(self, app):
        """K1-2: User with 1,000,000 active HP balance works correctly."""
        db = make_mock_db()
        db.rpc.return_value = {"active": 1000000, "pending": 350000, "overflow": 500000}

        with patch("app.services.hp_service.get_db", return_value=db):
            from app.services.hp_service import get_hp_balance
            result = get_hp_balance(STUDENT_ID)

        assert result["active"] == 1000000

    def test_pending_ceiling_at_1m_active(self, app):
        """K1-3: Pending pool ceiling at 35% of 1,000,000 = 350,000 HP."""
        ceiling = max(int(1000000 * 0.35), 200)
        assert ceiling == 350000

    def test_overflow_at_500k_hp(self, app):
        """K1-4: Overflow vault at 500,000 HP processes correctly."""
        db = make_mock_db()
        db.rpc.return_value = {"active": 1000000, "pending": 350000, "overflow": 500000}

        with patch("app.services.hp_service.get_db", return_value=db):
            from app.services.hp_service import get_hp_balance
            result = get_hp_balance(STUDENT_ID)

        assert result["overflow"] == 500000

    def test_whole_chicken_redemption_65800_hp(self, app):
        """K1-5: 65,800 HP Whole Chicken redemption processes without error."""
        with patch("app.services.hp_service.get_db", return_value=make_mock_db()), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 70000}), \
             patch("app.services.hp_service._record_hp_transaction"):
            from app.services.hp_service import spend_hp
            result = spend_hp(STUDENT_ID, 65800, REWARD_ID, "reward_redemption")

        assert result["spent"] == 65800
        assert result["balance_after"] == 4200


# ── K2: Boundary Condition Tests ──────────────────────────────────────────────

class TestK2BoundaryConditions:
    def test_exactly_2500_hp_qualifies_for_flame(self, app):
        """K2-1: User at exactly 2,500 HP earned qualifies for Flame tier."""
        profile = {**SAMPLE_PROFILE, "hp_earned_120day": 2500}
        db = make_mock_db({"profiles": profile, "tiers": SAMPLE_TIERS, "user_tiers": []})

        with patch("app.services.hp_service.get_db", return_value=db), \
             patch("app.services.hp_service._safe_update_profile"):
            from app.services.hp_service import recalculate_tier
            result = recalculate_tier(STUDENT_ID)

        assert result["tier"]["slug"] == "flame"

    def test_2499_hp_does_not_qualify_flame(self, app):
        """K2-2: User at 2,499 HP earned stays at Ember tier."""
        profile = {**SAMPLE_PROFILE, "hp_earned_120day": 2499}
        db = make_mock_db({"profiles": profile, "tiers": SAMPLE_TIERS, "user_tiers": []})

        with patch("app.services.hp_service.get_db", return_value=db), \
             patch("app.services.hp_service._safe_update_profile"):
            from app.services.hp_service import recalculate_tier
            result = recalculate_tier(STUDENT_ID)

        assert result["tier"]["slug"] == "ember"

    def test_pending_at_exactly_35_ceiling_overflows(self, app):
        """K2-3: Pending at exactly 35% ceiling → next HP goes to overflow."""
        active = 1000
        ceiling = int(active * 0.35)  # = 350
        profile = {**SAMPLE_PROFILE, "pending_hp_balance": ceiling, "hp_overflow": 0}

        with patch("app.services.hp_service.get_db", return_value=make_mock_db({"profiles": profile})), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": active, "pending": ceiling, "overflow": 0}), \
             patch("app.services.hp_service._record_hp_transaction"), \
             patch("app.services.hp_service._safe_update_profile"), \
             patch("app.services.hp_service._get_profile_hp_fields", return_value=profile):
            from app.services.hp_service import earn_pending_hp
            result = earn_pending_hp(STUDENT_ID, 1, "referral")

        assert result["added_to_overflow"] == 1
        assert result["added_to_pending"] == 0

    def test_floor_200_applies_at_low_active_balance(self, app):
        """K2-4: Active balance 572 → ceiling = max(int(572×0.35),200) = max(200,200) = 200."""
        assert max(int(572 * 0.35), 200) == 200

    def test_floor_no_longer_applies_at_573(self, app):
        """K2-5: Active balance 573 → ceiling = max(200, 200) = 200 (still floor since int(573×0.35)=200)."""
        # int(573 * 0.35) = int(200.55) = 200, so floor still applies
        assert max(int(573 * 0.35), 200) == 200

    def test_floor_exceeds_200_at_higher_balance(self, app):
        """K2-5b: Active balance 600 → ceiling = max(210, 200) = 210."""
        assert max(int(600 * 0.35), 200) == 210


# ── K3: Negative & Zero Tests ─────────────────────────────────────────────────

class TestK3NegativeZeroTests:
    def test_zero_hp_spend_raises_or_returns_zero(self, app):
        """K3-1: Spending 0 HP is handled gracefully."""
        with patch("app.services.hp_service.get_db", return_value=make_mock_db()), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 500}), \
             patch("app.services.hp_service._record_hp_transaction"):
            from app.services.hp_service import spend_hp
            result = spend_hp(STUDENT_ID, 0, ORDER_ID, "reward_redemption")

        assert result["spent"] == 0

    def test_zero_food_spend_no_unlock(self, app):
        """K3-2: Zero food spend returns zero unlocked."""
        with patch("app.services.hp_service.get_db", return_value=make_mock_db()), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 500, "pending": 200, "overflow": 0}):
            from app.services.hp_service import unlock_pending_hp
            result = unlock_pending_hp(STUDENT_ID, ORDER_ID, 0.0)

        assert result["unlocked"] == 0

    def test_zero_order_total_earns_zero_hp(self, app):
        """K3-3: Zero order total earns 0 HP — no division by zero."""
        with patch("app.services.hp_service.get_db", return_value=make_mock_db()), \
             patch("app.services.hp_service.unlock_pending_hp", return_value={"unlocked": 0}), \
             patch("app.services.hp_service._update_earned_counters"), \
             patch("app.services.hp_service._record_hp_transaction"):
            from app.services.hp_service import award_food_order_hp
            result = award_food_order_hp(STUDENT_ID, ORDER_ID, 0.0, "ember")

        assert result["base_hp"] == 0
        assert result["total_hp"] == 0

    def test_negative_pending_impossible_in_unlock(self, app):
        """K3-4: Unlock never produces negative pending balance."""
        profile = {**SAMPLE_PROFILE, "pending_hp_balance": 50, "hp_overflow": 0}
        with patch("app.services.hp_service.get_db", return_value=make_mock_db({"profiles": profile})), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 1000, "pending": 50, "overflow": 0}), \
             patch("app.services.hp_service._record_hp_transaction"), \
             patch("app.services.hp_service._safe_update_profile"):
            from app.services.hp_service import unlock_pending_hp
            result = unlock_pending_hp(STUDENT_ID, ORDER_ID, 5000.0)

        assert result["unlocked"] == 50  # capped at pending balance

    def test_expire_hp_capped_at_active_balance(self, app):
        """K3-5: expire_hp cannot expire more than active balance."""
        with patch("app.services.hp_service.get_db", return_value=make_mock_db()), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 100}), \
             patch("app.services.hp_service._record_hp_transaction"):
            from app.services.hp_service import expire_hp
            result = expire_hp(STUDENT_ID, 99999)  # try to expire more than active

        assert result["expired"] == 100  # capped at 100


# ── K4: API Input Validation Tests ───────────────────────────────────────────

class TestK4ApiInputValidation:
    def test_empty_items_list_raises_value_error(self, app):
        """K4-1: Order with empty items raises ValueError."""
        db = make_mock_db({
            "delivery_windows": SAMPLE_WINDOW,
            "menu_items": SAMPLE_MENU_ITEM,
        })
        with patch("app.services.order_service.get_db", return_value=db):
            from app.services.order_service import create_order
            with pytest.raises(ValueError, match="at least one item"):
                create_order(STUDENT_ID, {
                    "items": [],
                    "delivery_window_id": WINDOW_ID,
                    "payment_method": "card",
                })

    def test_closed_window_raises_value_error(self, app):
        """K4-2: Closed delivery window raises ValueError."""
        closed_window = {**SAMPLE_WINDOW, "status": "closed"}
        db = make_mock_db({"delivery_windows": closed_window})

        with patch("app.services.order_service.get_db", return_value=db):
            from app.services.order_service import create_order
            with pytest.raises(ValueError, match="not open"):
                create_order(STUDENT_ID, {
                    "items": [{"menu_item_id": MENU_ITEM_ID, "quantity": 1}],
                    "delivery_window_id": WINDOW_ID,
                    "payment_method": "card",
                })

    def test_unavailable_item_raises(self, app):
        """K4-3: Unavailable menu item raises ValueError."""
        unavailable = {**SAMPLE_MENU_ITEM, "is_available": False}
        db = make_mock_db({
            "delivery_windows": SAMPLE_WINDOW,
            "menu_items": unavailable,
        })
        with patch("app.services.order_service.get_db", return_value=db):
            from app.services.order_service import create_order
            with pytest.raises(ValueError, match="not currently available"):
                create_order(STUDENT_ID, {
                    "items": [{"menu_item_id": MENU_ITEM_ID, "quantity": 1}],
                    "delivery_window_id": WINDOW_ID,
                    "payment_method": "card",
                })

    def test_invalid_status_transition_raises(self, app):
        """K4-4: Invalid status transition raises ValueError."""
        db = make_mock_db({"orders": {**SAMPLE_ORDER, "status": "delivered"}})

        with patch("app.services.order_service.get_db", return_value=db), \
             patch("app.services.order_service.send_notification"):
            from app.services.order_service import update_order_status
            with pytest.raises(ValueError, match="Cannot transition"):
                update_order_status(ORDER_ID, "received")

    def test_spend_hp_insufficient_raises(self, app):
        """K4-5: Spending more HP than balance raises ValueError."""
        with patch("app.services.hp_service.get_db", return_value=make_mock_db()), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 50}):
            from app.services.hp_service import spend_hp
            with pytest.raises(ValueError, match="Insufficient HP"):
                spend_hp(STUDENT_ID, 100, ORDER_ID, "reward_redemption")
