"""API tests for /api/rewards endpoints."""

import pytest
from unittest.mock import patch
from tests.conftest import (
    make_mock_db, STUDENT_ID, REWARD_ID, SAMPLE_PROFILE, SAMPLE_REWARD, SAMPLE_TIERS
)


@pytest.fixture(autouse=True)
def mock_db_auth(app):
    db = make_mock_db()
    with patch("app.middleware.auth.get_db", return_value=db):
        yield db


class TestListRewards:
    def test_returns_active_rewards(self, client):
        db = make_mock_db({"rewards": [SAMPLE_REWARD]})
        with patch("app.routes.rewards.get_db", return_value=db):
            resp = client.get("/api/rewards")
        assert resp.status_code == 200
        data = resp.get_json()
        assert isinstance(data, list)

    def test_category_filter(self, client):
        db = make_mock_db({"rewards": [SAMPLE_REWARD]})
        with patch("app.routes.rewards.get_db", return_value=db):
            resp = client.get("/api/rewards?category=food")
        assert resp.status_code == 200

    def test_out_of_stock_filtered(self, client):
        """Rewards where quantity_redeemed >= quantity_available should not appear"""
        sold_out = {**SAMPLE_REWARD, "quantity_available": 5, "quantity_redeemed": 5}
        db = make_mock_db({"rewards": [sold_out]})
        with patch("app.routes.rewards.get_db", return_value=db):
            resp = client.get("/api/rewards")
        assert resp.status_code == 200
        assert resp.get_json() == []


class TestGetReward:
    def test_returns_reward(self, client):
        db = make_mock_db({"rewards": SAMPLE_REWARD})
        with patch("app.routes.rewards.get_db", return_value=db):
            resp = client.get(f"/api/rewards/{REWARD_ID}")
        assert resp.status_code == 200
        assert resp.get_json()["id"] == REWARD_ID

    def test_not_found_returns_404(self, client):
        db = make_mock_db({"rewards": None})
        with patch("app.routes.rewards.get_db", return_value=db):
            resp = client.get(f"/api/rewards/nonexistent")
        assert resp.status_code == 404


class TestRedeemReward:
    def test_successful_redemption(self, client, auth_headers):
        redemption = {"id": "rr000001", "user_id": STUDENT_ID, "reward_id": REWARD_ID, "hp_cost_snapshot": 150}
        db = make_mock_db({
            "rewards": SAMPLE_REWARD,
            "user_tiers": [{"tier_id": "00000000-0000-0000-0000-000000000001", "is_current": True, "sort_order": 1}],
            "reward_redemptions": [redemption],
        })
        with patch("app.middleware.auth.get_db", return_value=db), \
             patch("app.routes.rewards.get_db", return_value=db), \
             patch("app.routes.rewards.get_hp_balance", return_value={"active": 500}), \
             patch("app.routes.rewards.spend_hp", return_value={"spent": 150, "balance_after": 350}), \
             patch("app.routes.rewards.get_user_tier", return_value={"tier": {"sort_order": 1}}), \
             patch("app.routes.rewards.send_notification"):
            resp = client.post(f"/api/rewards/{REWARD_ID}/redeem", headers=auth_headers)
        assert resp.status_code == 201
        data = resp.get_json()
        assert data["hp_spent"] == 150

    def test_insufficient_hp_returns_400(self, client, auth_headers):
        db = make_mock_db({"rewards": SAMPLE_REWARD})
        with patch("app.middleware.auth.get_db", return_value=db), \
             patch("app.routes.rewards.get_db", return_value=db), \
             patch("app.routes.rewards.get_hp_balance", return_value={"active": 50}), \
             patch("app.routes.rewards.get_user_tier", return_value={"tier": {"sort_order": 1}}):
            resp = client.post(f"/api/rewards/{REWARD_ID}/redeem", headers=auth_headers)
        assert resp.status_code == 400
        assert "Insufficient HP" in resp.get_json()["error"]

    def test_requires_auth(self, client):
        resp = client.post(f"/api/rewards/{REWARD_ID}/redeem")
        assert resp.status_code == 401

    def test_inactive_reward_returns_404(self, client, auth_headers):
        inactive = {**SAMPLE_REWARD, "is_active": False}
        db = make_mock_db({"rewards": inactive})
        with patch("app.middleware.auth.get_db", return_value=db), \
             patch("app.routes.rewards.get_db", return_value=db):
            resp = client.post(f"/api/rewards/{REWARD_ID}/redeem", headers=auth_headers)
        assert resp.status_code == 404


class TestCreateReward:
    def test_admin_creates_reward(self, client, admin_headers):
        db = make_mock_db({
            "profiles": {**SAMPLE_PROFILE, "id": "aaaaaaaa-0000-0000-0000-000000000002", "role": "admin"},
            "rewards": SAMPLE_REWARD,
        })
        with patch("app.middleware.auth.get_db", return_value=db), \
             patch("app.routes.rewards.get_db", return_value=db):
            resp = client.post("/api/rewards", json={
                "name": "Free Drink",
                "hp_cost": 80,
                "category": "food",
            }, headers=admin_headers)
        assert resp.status_code == 201

    def test_student_cannot_create_reward(self, client, auth_headers):
        resp = client.post("/api/rewards", json={"name": "X", "hp_cost": 50, "category": "food"}, headers=auth_headers)
        assert resp.status_code == 403
