"""
Phase F: Marketplace & Rewards Tests (35 tests)
F1: Reward HP Pricing Formula
F2: Reward Redemption Limits
F3: Flash Redemptions
F4: Merch Reward Pricing
F5: Marketplace Purchase HP Rules
F6: Event Ticket HP Discount
F7: HP Bundle Sales
"""

import math
import pytest
from unittest.mock import patch, MagicMock
from datetime import datetime, timezone, timedelta
from tests.conftest import (
    make_mock_db, STUDENT_ID, ORDER_ID, SAMPLE_PROFILE, SAMPLE_REWARD, REWARD_ID,
    TIER_EMBER, TIER_FLAME, TIER_HOLY, SAMPLE_TIERS, student_token
)


@pytest.fixture(autouse=True)
def flask_ctx(app):
    with app.app_context():
        yield


# ── Pricing formula helper ────────────────────────────────────────────────────

def hp_price_formula(food_cost: float, menu_price: float, margin_share: float = 0.40) -> int:
    """HP Price = round_up_to_50((food_cost + margin_share × (menu_price - food_cost)) / ₦0.185)"""
    effective_cost = food_cost + margin_share * (menu_price - food_cost)
    raw_hp = effective_cost / 0.185
    return math.ceil(raw_hp / 50) * 50


# ── F1: Reward HP Pricing Formula ────────────────────────────────────────────

class TestF1RewardHpPricingFormula:
    def test_pricing_formula_structure(self, app):
        """F1-1: HP Price = (Food Cost + 40% × (Menu Price − Food Cost)) ÷ ₦0.185."""
        # Coleslaw: cost=180, price=500
        food_cost, menu_price = 180, 500
        effective_cost = food_cost + 0.40 * (menu_price - food_cost)
        raw_hp = effective_cost / 0.185
        assert raw_hp > 0

    def test_coleslaw_hp_price(self, app):
        """F1-2: Coleslaw (₦180 cost, ₦500 price) = 1,700 HP."""
        result = hp_price_formula(180, 500)
        assert result == 1700

    def test_sausage_hp_price(self, app):
        """F1-3: Sausage (₦200 cost, ₦600 price) = 1,950 HP."""
        result = hp_price_formula(200, 600)
        assert result == 1950

    def test_chicken_lap_hp_price(self, app):
        """F1-4: Chicken Lap (₦1,919 cost, ₦4,700 price) = 16,400 HP."""
        result = hp_price_formula(1919, 4700)
        assert result == 16400

    def test_whole_chicken_hp_price(self, app):
        """F1-5: Whole Chicken (₦7,965 cost, ₦18,500 price) = 65,850 HP (formula result)."""
        result = hp_price_formula(7965, 18500)
        assert result == 65850

    def test_rewards_round_up_to_nearest_50(self, app):
        """F1-6: Rewards HP always rounded UP to nearest 50."""
        # Test that formula always uses ceil(raw/50)*50
        test_cases = [
            (180, 500, 1700),
            (200, 600, 1950),
        ]
        for food_cost, menu_price, expected in test_cases:
            result = hp_price_formula(food_cost, menu_price)
            assert result == expected
            assert result % 50 == 0


# ── F2: Reward Redemption Limits ──────────────────────────────────────────────

class TestF2RewardRedemptionLimits:
    def test_insufficient_hp_returns_400(self, client, auth_headers):
        """F2-1: User cannot redeem reward without sufficient active HP."""
        db = make_mock_db()
        with patch("app.middleware.auth.get_db", return_value=db), \
             patch("app.routes.rewards.get_db", return_value=db), \
             patch("app.routes.rewards.get_hp_balance", return_value={"active": 10}), \
             patch("app.routes.rewards.spend_hp", side_effect=ValueError("Insufficient HP")):
            resp = client.post(f"/api/rewards/{REWARD_ID}/redeem", headers=auth_headers)

        assert resp.status_code == 400

    def test_pending_hp_cannot_be_used_for_rewards(self, app):
        """F2-2: Pending HP cannot be spent on rewards — only active HP is used."""
        with patch("app.services.hp_service.get_db", return_value=make_mock_db()), \
             patch("app.services.hp_service.get_hp_balance",
                   return_value={"active": 0, "pending": 500, "overflow": 0}):
            from app.services.hp_service import spend_hp
            with pytest.raises(ValueError, match="Insufficient HP"):
                spend_hp(STUDENT_ID, 100, ORDER_ID, "reward_redemption")

    def test_out_of_stock_reward_not_redeemable(self, client, auth_headers):
        """F2-3: Reward with quantity_available = 0 cannot be redeemed."""
        out_of_stock = {**SAMPLE_REWARD, "quantity_available": 5, "quantity_redeemed": 5}
        db = make_mock_db({"rewards": out_of_stock})
        with patch("app.middleware.auth.get_db", return_value=db), \
             patch("app.routes.rewards.get_db", return_value=db), \
             patch("app.routes.rewards.get_hp_balance", return_value={"active": 10000}):
            resp = client.post(f"/api/rewards/{REWARD_ID}/redeem", headers=auth_headers)

        assert resp.status_code == 400

    def test_tier_restricted_reward_blocks_lower_tier(self, client, auth_headers):
        """F2-4: Reward with min_tier_id only redeemable by qualifying tier+."""
        restricted_reward = {**SAMPLE_REWARD, "min_tier_id": TIER_HOLY, "hp_cost": 100}
        user_tier_data = {"is_in_grace_period": False, "tier": {"sort_order": 1, "slug": "ember"}}
        db = make_mock_db({"rewards": restricted_reward, "tiers": SAMPLE_TIERS})

        with patch("app.middleware.auth.get_db", return_value=db), \
             patch("app.routes.rewards.get_db", return_value=db), \
             patch("app.routes.rewards.get_hp_balance", return_value={"active": 10000}), \
             patch("app.routes.rewards.get_user_tier", return_value=user_tier_data):
            resp = client.post(f"/api/rewards/{REWARD_ID}/redeem", headers=auth_headers)

        assert resp.status_code in (400, 403, 404)

    def test_inactive_reward_returns_404(self, client, auth_headers):
        """F2-5: Inactive reward returns 404."""
        inactive = {**SAMPLE_REWARD, "is_active": False}
        db = make_mock_db({"rewards": inactive})
        with patch("app.middleware.auth.get_db", return_value=db), \
             patch("app.routes.rewards.get_db", return_value=db), \
             patch("app.routes.rewards.get_hp_balance", return_value={"active": 10000}):
            resp = client.post(f"/api/rewards/{REWARD_ID}/redeem", headers=auth_headers)

        assert resp.status_code == 404


# ── F3: Flash Redemptions ─────────────────────────────────────────────────────

class TestF3FlashRedemptions:
    def _make_flash(self, redeemed_count=0, qty_limit=5, expired=False):
        now = datetime.now(timezone.utc)
        window_ends = now - timedelta(hours=1) if expired else now + timedelta(hours=23)
        return {
            "id": "flash-001",
            "reward_id": REWARD_ID,
            "is_active": True,
            "quantity_limit": qty_limit,
            "window_starts_at": (now - timedelta(hours=1)).isoformat(),
            "window_ends_at": window_ends.isoformat(),
        }

    def test_flash_discount_50_percent(self, app):
        """F3-1: Flash redemption reduces HP cost by exactly 50%."""
        from flask import current_app
        assert current_app.config["FLASH_DISCOUNT_PCT"] == 0.50

    def test_flash_qty_limit_5(self, app):
        """F3-2: Flash redemption has max 5 redemptions by default."""
        from flask import current_app
        assert current_app.config["FLASH_MAX_QTY"] == 5

    def test_flash_within_24h_window(self, app):
        """F3-3: Flash redemption enforces 24-hour window."""
        flash = self._make_flash(expired=True)
        reward = {**SAMPLE_REWARD, "hp_cost": 1000}
        db = make_mock_db({"flash_redemptions": flash, "rewards": reward})

        with patch("app.services.hp_service.get_db", return_value=db), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 5000}):
            from app.services.hp_service import process_flash_redeem
            with pytest.raises(ValueError, match="window has closed"):
                process_flash_redeem(REWARD_ID, STUDENT_ID)

    def test_flash_qty_limit_enforced(self, app):
        """F3-4: After qty limit reached, flash raises ValueError."""
        flash = self._make_flash()
        reward = {**SAMPLE_REWARD, "hp_cost": 1000}
        # Mock 5 redemptions already done
        already = [{"id": f"r{i}"} for i in range(5)]
        db = make_mock_db({"flash_redemptions": flash, "rewards": reward,
                           "reward_redemptions": already})

        with patch("app.services.hp_service.get_db", return_value=db), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 5000}):
            from app.services.hp_service import process_flash_redeem
            with pytest.raises(ValueError, match="limit"):
                process_flash_redeem(REWARD_ID, STUDENT_ID)

    def test_flash_discounted_cost_is_half(self, app):
        """F3-5: Discounted HP cost is exactly 50% of original."""
        original_cost = 1000
        flash = self._make_flash()
        reward = {**SAMPLE_REWARD, "hp_cost": original_cost}
        db = make_mock_db({"flash_redemptions": flash, "rewards": reward,
                           "reward_redemptions": []})

        with patch("app.services.hp_service.get_db", return_value=db), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 5000}), \
             patch("app.services.hp_service.spend_hp", return_value={"spent": 500, "balance_after": 4500}):
            from app.services.hp_service import process_flash_redeem
            result = process_flash_redeem(REWARD_ID, STUDENT_ID)

        assert result["discounted_hp_cost"] == 500
        assert result["savings_hp"] == 500

    def test_flash_no_active_flash_raises(self, app):
        """F3-6: No active flash sale raises ValueError."""
        db = make_mock_db({"flash_redemptions": None})

        with patch("app.services.hp_service.get_db", return_value=db):
            from app.services.hp_service import process_flash_redeem
            with pytest.raises(ValueError, match="No active flash"):
                process_flash_redeem(REWARD_ID, STUDENT_ID)


# ── F4: Merch Reward Pricing ──────────────────────────────────────────────────

class TestF4MerchRewardPricing:
    def hp_price_merch(self, cost: float, perceived_price: float) -> int:
        """Merch uses 50% margin share (more generous)."""
        return hp_price_formula(cost, perceived_price, margin_share=0.50)

    def test_merch_50_percent_margin_share(self, app):
        """F4-1: Merch uses 50% margin share instead of food's 40%."""
        # Sticker: cost=150, perceived=500
        food_hp = hp_price_formula(150, 500, 0.40)
        merch_hp = hp_price_formula(150, 500, 0.50)
        # merch is cheaper in HP (more generous) because higher share reduces effective cost
        assert merch_hp != food_hp

    def test_sticker_pack_hp_price(self, app):
        """F4-2: Sticker Pack (₦150 cost, ₦500 perceived) = 1,800 HP (formula result)."""
        result = hp_price_formula(150, 500, 0.50)
        assert result == 1800

    def test_tshirt_hp_price(self, app):
        """F4-3: T-Shirt (₦1,800 cost, ₦4,000 perceived) = 15,700 HP."""
        result = hp_price_formula(1800, 4000, 0.50)
        assert result == 15700

    def test_hoodie_hp_price(self, app):
        """F4-4: Hoodie (₦3,500 cost, ₦8,000 perceived) = 31,100 HP."""
        result = hp_price_formula(3500, 8000, 0.50)
        assert result == 31100


# ── F5: Marketplace Purchase HP Rules ─────────────────────────────────────────

class TestF5MarketplacePurchaseHp:
    def test_marketplace_purchase_earns_pending(self, app):
        """F5-1: Marketplace purchase earns flat 50 HP → PENDING."""
        statuses = []

        def capture(user_id, amount, txn_type, status="active", **kwargs):
            statuses.append({"amount": amount, "status": status})

        profile = {**SAMPLE_PROFILE, "pending_hp_balance": 0, "hp_overflow": 0}
        with patch("app.services.hp_service.get_db", return_value=make_mock_db({"profiles": profile})), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 500, "pending": 0, "overflow": 0}), \
             patch("app.services.hp_service._record_hp_transaction", side_effect=capture), \
             patch("app.services.hp_service._safe_update_profile"), \
             patch("app.services.hp_service._get_profile_hp_fields", return_value=profile):
            from app.services.hp_service import earn_pending_hp
            result = earn_pending_hp(STUDENT_ID, 50, "marketplace")

        assert result["added_to_pending"] + result["added_to_overflow"] == 50

    def test_marketplace_spend_type_mapping(self, app):
        """F5-2: Marketplace purchase uses spend_marketplace type."""
        from app.services.hp_service import TXN_TYPE_MAP
        assert TXN_TYPE_MAP["marketplace_purchase"] == "spend_marketplace"

    def test_marketplace_platform_fee_hp(self, app):
        """F5-3: HP platform fee deducted via spend_hp."""
        with patch("app.services.hp_service.get_db", return_value=make_mock_db()), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 100}), \
             patch("app.services.hp_service._record_hp_transaction"):
            from app.services.hp_service import spend_hp
            result = spend_hp(STUDENT_ID, 50, ORDER_ID, "spend_marketplace")

        assert result["spent"] == 50

    def test_marketplace_hp_discount_combined(self, app):
        """F5-4: HP + Wallet combined payment verified at order level."""
        from tests.conftest import SAMPLE_ORDER
        order = {**SAMPLE_ORDER, "payment_method": "split",
                 "wallet_amount_used": 1000.0, "hp_points_used": 100}
        assert order["payment_method"] == "split"
        assert order["wallet_amount_used"] == 1000.0

    def test_escrow_field_in_marketplace_table(self, app):
        """F5-5: Marketplace holds funds until delivery confirmation."""
        # marketplace_purchases table exists in mock defaults
        db = make_mock_db()
        assert "marketplace_purchases" in db.table.side_effect.__closure__[0].cell_contents


# ── F6: Event Ticket HP Discount ──────────────────────────────────────────────

class TestF6EventTicketHpDiscount:
    def test_max_hp_discount_25_percent_of_ticket(self, app):
        """F6-1: Max HP discount is 25% of ticket face value."""
        ticket_price = 2700  # ₦2700
        max_discount_hp = int(ticket_price * 0.25)
        assert max_discount_hp == 675

    def test_1hp_equals_1_naira_discount(self, app):
        """F6-2: 1 HP = ₦1 discount for event tickets."""
        hp_liability = 0.185
        # For event tickets: 1 HP = ₦1, NOT ₦0.185
        # This is more generous than the normal HP redemption rate
        event_hp_rate = 1.0  # ₦1 per HP for events
        assert event_hp_rate > hp_liability

    def test_hp_discount_before_wallet_payment(self, app):
        """F6-3: HP discount applied at checkout before wallet/card payment."""
        # create_order applies hp_discount before computing total
        from tests.conftest import SAMPLE_MENU_ITEM, SAMPLE_WINDOW, SAMPLE_ORDER
        db = make_mock_db({
            "delivery_windows": SAMPLE_WINDOW,
            "menu_items": SAMPLE_MENU_ITEM,
            "orders": SAMPLE_ORDER,
        })
        from tests.conftest import MENU_ITEM_ID, WINDOW_ID
        payload = {
            "items": [{"menu_item_id": MENU_ITEM_ID, "quantity": 1}],
            "delivery_window_id": WINDOW_ID,
            "payment_method": "card",
            "hp_points_to_redeem": 100,
        }
        with patch("app.services.order_service.get_db", return_value=db), \
             patch("app.services.order_service.send_notification"):
            from app.services.order_service import create_order
            result = create_order(STUDENT_ID, payload)

        # hp_discount applied (100 HP × ₦0.185 = ₦18.50)
        assert result["hp_discount"] == round(100 * 0.185, 2)
        assert result["total"] < result["subtotal"]

    def test_hp_discount_formula_correct(self, app):
        """F6-4: HP discount = hp_points × HP_LIABILITY_VALUE."""
        hp_points = 675
        hp_liability = 0.185
        expected_discount = round(hp_points * hp_liability, 2)
        assert expected_discount == round(675 * 0.185, 2)


# ── F7: HP Bundle Sales ───────────────────────────────────────────────────────

class TestF7HpBundleSales:
    def test_bundle_price_5_naira_per_hp(self, app):
        """F7-1: Event host pays exactly ₦5 per HP."""
        from flask import current_app
        assert current_app.config["HP_BUNDLE_PRICE_PER_HP"] == 5.0

    def test_hg_net_margin_per_hp(self, app):
        """F7-2: HG net cash margin = ₦5 - ₦0.185 = ₦4.815 per HP."""
        price_per_hp = 5.0
        liability_per_hp = 0.185
        net_margin = price_per_hp - liability_per_hp
        assert abs(net_margin - 4.815) < 0.001

    def test_markup_percentage(self, app):
        """F7-3: 2,603% markup (₦4.815 / ₦0.185)."""
        price_per_hp = 5.0
        liability_per_hp = 0.185
        markup = (price_per_hp - liability_per_hp) / liability_per_hp * 100
        assert abs(markup - 2602.7) < 1

    def test_bundle_purchase_credits_pending_pool(self, app):
        """F7-4: HP bundle credited to event host's pending pool."""
        profile = {**SAMPLE_PROFILE, "pending_hp_balance": 0, "hp_overflow": 0}
        with patch("app.services.hp_service.get_db", return_value=make_mock_db({"profiles": profile})), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 0, "pending": 0, "overflow": 0}), \
             patch("app.services.hp_service._record_hp_transaction"), \
             patch("app.services.hp_service._safe_update_profile"), \
             patch("app.services.hp_service._get_profile_hp_fields", return_value=profile):
            from app.services.hp_service import process_hp_bundle_purchase
            result = process_hp_bundle_purchase(STUDENT_ID, 1000, 5000.0)

        assert result["hp_credited_to_pending"] + result["hp_to_overflow"] == 1000

    def test_bundle_records_hp_bundle_purchase(self, app):
        """F7-5: Bundle purchase attempts to insert into hp_bundle_purchases."""
        inserts = []

        original_db = make_mock_db()
        original_side = original_db.table.side_effect

        def guarded(name):
            tbl = original_side(name)
            if name == "hp_bundle_purchases":
                orig_insert = tbl.insert
                def track(*args, **kwargs):
                    inserts.append(name)
                    return orig_insert(*args, **kwargs)
                tbl.insert = track
            return tbl

        original_db.table.side_effect = guarded

        profile = {**SAMPLE_PROFILE, "pending_hp_balance": 0, "hp_overflow": 0}
        with patch("app.services.hp_service.get_db", return_value=original_db), \
             patch("app.services.hp_service.get_hp_balance", return_value={"active": 0, "pending": 0, "overflow": 0}), \
             patch("app.services.hp_service._record_hp_transaction"), \
             patch("app.services.hp_service._safe_update_profile"), \
             patch("app.services.hp_service._get_profile_hp_fields", return_value=profile):
            from app.services.hp_service import process_hp_bundle_purchase
            process_hp_bundle_purchase(STUDENT_ID, 500, 2500.0)

        assert "hp_bundle_purchases" in inserts

    def test_bundle_payment_mismatch_raises(self, app):
        """F7-extra: Payment amount mismatch raises ValueError."""
        profile = {**SAMPLE_PROFILE, "pending_hp_balance": 0, "hp_overflow": 0}
        with patch("app.services.hp_service.get_db", return_value=make_mock_db({"profiles": profile})):
            from app.services.hp_service import process_hp_bundle_purchase
            with pytest.raises(ValueError, match="mismatch"):
                process_hp_bundle_purchase(STUDENT_ID, 1000, 3000.0)  # should be 5000
