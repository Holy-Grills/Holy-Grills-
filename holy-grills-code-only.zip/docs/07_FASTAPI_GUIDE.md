# FastAPI Implementation Guide

## Overview

Holy Grills ships **two HTTP servers from one codebase**:

| Server | Port | Framework | Entry point |
|--------|------|-----------|-------------|
| Flask | 5000 | Flask 3 | `flask run` |
| FastAPI | 8000 | FastAPI 0.136 + Uvicorn | `uvicorn fastapi_app.run:app --reload` |

Both servers share **100% of the business logic** in `app/services/*`. Neither contains duplicated logic. The FastAPI layer is a thin HTTP adapter only.

---

## Architecture

```
fastapi_app/
  main.py         ← FastAPI app factory (create_fastapi_app)
  run.py          ← Uvicorn entry point
  deps.py         ← get_db() wrapper + auth deps (get_current_user, require_role)
  schemas/        ← Pydantic v2 request models
  routers/        ← 18 routers, 121 endpoints (HTTP adapters only)
  tests/          ← 87 FastAPI tests

app/
  services/       ← ALL business logic (shared by Flask + FastAPI)
  db.py           ← Supabase client + get_db()
  routes/         ← Flask HTTP adapters (18 blueprints)
```

### Zero-Duplication Rule

FastAPI routers **must not** contain business logic. They:
1. Parse the incoming request body (Pydantic validates it)
2. Validate auth via `Depends(get_current_user)` or `Depends(require_role("admin"))`
3. Call the service function
4. Return the result

```python
# CORRECT — pure HTTP adapter
@router.post("/complete", status_code=201)
def complete_referral(body: CompleteReferralRequest, user: UserContext = Depends(get_current_user)):
    db = get_db()
    # minimal orchestration only — delegate to service
    ref = db.table("referrals").select("id,status").eq("referrer_id", user.user_id).execute()
    ...
    earn_pending_hp(user_id=user.user_id, amount=75, source_type="referral", reference_id=ref["id"])
    return {"hp_awarded": 75}
```

---

## Routers (18 total, 121 endpoints)

| Router | Prefix | Key endpoints |
|--------|--------|---------------|
| auth | `/api/auth` | register, login, profile, update |
| menu | `/api/menu` | categories, items, addons, variations, kitchen-capacity |
| orders | `/api/orders` | create, list, detail, review, claim |
| hp | `/api/hp` | balance, transactions, tiers, admin/grant |
| wallet | `/api/wallet` | balance, topup, transactions |
| referrals | `/api/referrals` | get, complete, milestones |
| rewards | `/api/rewards` | list, redeem, flash |
| marketplace | `/api/marketplace` | listings, purchase, vendor-request |
| leaderboard | `/api/leaderboard` | global, monthly, hall-of-fame |
| events | `/api/events` | list, detail, checkin, catering-request |
| challenges | `/api/challenges` | list, detail |
| notifications | `/api/notifications` | list, mark-read |
| kitchen | `/api/kitchen` | queue, order status, capacity |
| riders | `/api/riders` | batch, delivered, attempted, contact |
| storefront | `/api/storefront` | sections, delivery-windows, operating-hours |
| analytics | `/api/analytics` | revenue, hp, orders, users |
| admin | `/api/admin` | users, deactivate, role, promo-codes, batches |
| webhooks | `/api/webhooks` | paystack |

---

## Auth Dependencies

```python
from fastapi_app.deps import get_current_user, require_role, UserContext

@router.get("/balance")
def balance(user: UserContext = Depends(get_current_user)):
    # user.user_id  → str UUID
    # user.role     → "student" | "kitchen" | "rider" | "admin" | "super_admin"
    # user.email    → str
    ...

@router.post("/admin/grant")
def admin_grant(body: AdminGrantHPRequest, user: UserContext = Depends(require_role("admin"))):
    # Returns 403 if user.role not in ("admin", "super_admin")
    ...
```

`get_current_user` decodes the Bearer JWT and validates against the `profiles` table. It returns a `UserContext` dataclass with `user_id`, `role`, and `email`.

---

## DB Injection & Mock Pattern

All routers call `get_db()` from `fastapi_app.deps`:

```python
from fastapi_app.deps import get_db

def my_endpoint(...):
    db = get_db()
    result = db.table("orders").select("*").eq("user_id", user.user_id).execute()
```

`fastapi_app/deps.py` wraps `app.db.get_db` via a module reference:

```python
import app.db as _appdb

def get_db():
    return _appdb.get_db()
```

This means **patching `app.db.get_db`** in tests propagates through the full call chain — one patch point for the entire server.

Service functions imported directly into routers (e.g. `from app.services.hp_service import get_hp_balance`) must be patched at **the router import site** for tests:

```python
# ✅ CORRECT — patches the router's local closure
with patch("fastapi_app.routers.hp.get_hp_balance", return_value=MOCK):
    resp = client.get("/api/hp/balance", ...)

# ❌ WRONG — patches the service module, not the router's local closure
with patch("app.services.hp_service.get_hp_balance", return_value=MOCK):
    resp = client.get("/api/hp/balance", ...)
```

---

## Pydantic Schemas

All request bodies are validated by Pydantic v2 schemas in `fastapi_app/schemas/__init__.py`.

Common schemas:

```python
class OrderCreateRequest(BaseModel):
    items: list[OrderItemInput]
    addons: list[AddonInput] = []
    payment_method: str
    hp_points_to_redeem: int = 0
    promo_code: str | None = None
    delivery_window_id: str
    delivery_address: dict

class AdminGrantHPRequest(BaseModel):
    user_id: str
    amount: int = Field(..., gt=0)
    reason: str | None = None

class CompleteReferralRequest(BaseModel):
    referred_user_id: str
```

FastAPI automatically returns 422 with field-level error details for invalid payloads.

---

## Running

```bash
# Development (auto-reload)
uvicorn fastapi_app.run:app --host 0.0.0.0 --port 8000 --reload

# Production (multi-worker)
gunicorn fastapi_app.run:app -k uvicorn.workers.UvicornWorker -w 4 -b 0.0.0.0:8000
```

Interactive docs: `http://localhost:8000/api/docs` (Swagger UI)
OpenAPI JSON: `http://localhost:8000/api/openapi.json`

---

## Test Suite (87 tests)

```bash
python -m pytest fastapi_app/tests/ -q
```

| Test file | Tests | Coverage |
|-----------|-------|---------|
| test_auth.py | 15 | Register, login, profile, update |
| test_menu.py | 12 | Categories, items, addons, capacity |
| test_orders.py | 10 | Create, list, detail, review |
| test_hp.py | 12 | Balance, transactions, tiers, admin grant |
| test_rewards.py | 10 | List, redeem, insufficient HP |
| test_referrals.py | 15 | Get, complete, milestones, no-cap |
| test_notifications.py | 13 | List, mark read, unread filter |

### Conftest Pattern

```python
# fastapi_app/tests/conftest.py

@pytest.fixture
def mock_db_student():
    return make_mock_db({
        "profiles": [SAMPLE_PROFILE],
        "wallets": [SAMPLE_WALLET],
        "hp_transactions": [],
        ...
    })

@pytest.fixture
def client(fastapi_app, mock_db_student):
    with patch("app.db.get_db", return_value=mock_db_student):
        with TestClient(fastapi_app) as c:
            yield c
```

The `make_mock_db(tables)` helper returns a `MockDB` object that intercepts `.table()` calls and returns in-memory data without hitting Supabase.

---

## Service Function Signature Reference

Critical signatures to be aware of:

```python
# hp_service.py
earn_pending_hp(user_id, amount, source_type, reference_id=None, notes='')
# ↑ NO reference_type parameter

award_active_hp(user_id, amount, txn_type=None, reference_id=None,
                reference_type=None, source_type=None, notes='',
                issued_by_admin_id=None)

spend_hp(user_id, amount, source_type, reference_id=None, reference_type=None, notes='')

get_hp_balance(user_id) → {"active": int, "pending": int, "overflow": int, ...}
get_user_tier(user_id)  → {"tier": {...}, "is_in_grace_period": bool}
```

---

## Differences from Flask

| Aspect | Flask | FastAPI |
|--------|-------|---------|
| Request parsing | Marshmallow / `request.json` | Pydantic v2 auto-validates |
| Auth middleware | `@require_auth` decorator | `Depends(get_current_user)` |
| Error responses | `jsonify({"error": "..."})` | `HTTPException(status_code=..., detail="...")` |
| Route definition | `@blueprint.route(...)` | `@router.get/post/patch/delete(...)` |
| Docs | Flasgger YAML | Auto-generated Swagger/ReDoc |
| Validation error | 400 with custom message | 422 with Pydantic field errors |

Both servers call identical service functions — the only difference is the HTTP adapter layer.
