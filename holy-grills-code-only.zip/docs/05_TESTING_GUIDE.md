# Holy Grills — Testing Guide
## Unit Tests · Integration Tests · API Tests

> Current status: **886 / 886 tests passing** (799 Flask + 87 FastAPI)
> Test framework: pytest + unittest.mock
> Coverage: 63% overall (85%+ on core HP service and order service)

---

## Running Tests

### Full combined suite (both Flask + FastAPI)
```bash
python -m pytest tests/ fastapi_app/tests/ -q
```

### Flask suite only (799 tests)
```bash
python -m pytest tests/ -q --tb=short
```

### FastAPI suite only (87 tests)
```bash
python -m pytest fastapi_app/tests/ -q --tb=short
```

### Single test file
```bash
python -m pytest tests/test_stress_b_hp_earn.py -v
```

### Single test class
```bash
python -m pytest tests/test_stress_d_tier_system.py::TestD4TierLookup -v
```

### Single test
```bash
python -m pytest tests/test_stress_b_hp_earn.py::TestB1FoodOrderHP::test_food_order_base_hp -v
```

### With coverage report
```bash
python -m pytest tests/ fastapi_app/tests/ --cov=app --cov-report=html
# Open coverage_html/index.html in browser
```

### Quiet pass/fail only
```bash
python -m pytest tests/ fastapi_app/tests/ -q --no-header -p no:warnings
```

---

## Flask Test File Structure (799 tests)

Tests are organized into 8 stress test groups (A through H), each covering a domain:

```
tests/
├── conftest.py                          ← Fixtures, mock DB, sample data
├── test_stress_a_hp_balance.py          ← HP balance calculation, pool mechanics
├── test_stress_b_hp_earn.py             ← All HP earn scenarios
├── test_stress_c_orders.py              ← Order creation, payment, delivery
├── test_stress_d_tier_system.py         ← Tier state machine, grace period
├── test_stress_e_leaderboard.py         ← Leaderboard, monthly reset, hall of fame
├── test_stress_f_marketplace_rewards.py ← Rewards store, HP pricing formula
├── test_stress_g_concurrency.py         ← Idempotency, race conditions
└── test_stress_h_data_consistency.py    ← Data integrity, audit trail
```

### What each group tests

| Group | Tests | Focus |
|-------|-------|-------|
| A | ~65 | HP balance pools, pending ceiling, overflow mechanics, pool drain |
| B | ~90 | Food order HP, referral HP, birthday, wallet, welcome, admin grant/reversal |
| C | ~80 | Order creation, promo codes, payment confirmation, guest checkout, add-ons |
| D | ~60 | Tier thresholds, grace period, multipliers, tier lookup, recalculation |
| E | ~55 | Leaderboard rankings, monthly reset, spin & win, hall of fame |
| F | ~70 | Marketplace HP pricing formula, tier-gated rewards, flash sales |
| G | ~65 | Concurrent HP awards, idempotency, referral race conditions |
| H | ~71 | Audit logs, data consistency, snapshot correctness, order items |

---

## FastAPI Test File Structure (87 tests)

```
fastapi_app/tests/
├── conftest.py           ← FastAPI app fixture, mock DB, auth tokens
├── test_auth.py          ← Register, login, profile read/update (15 tests)
├── test_menu.py          ← Categories, items, addons, capacity (12 tests)
├── test_orders.py        ← Create order, list, detail, review (10 tests)
├── test_hp.py            ← Balance, transactions, tiers, admin grant (12 tests)
├── test_rewards.py       ← List rewards, redeem, insufficient HP (10 tests)
├── test_referrals.py     ← Get code, complete referral, milestones (15 tests)
└── test_notifications.py ← List, mark read, unread count filter (13 tests)
```

---

## conftest.py (Flask) — The Mock System

All Flask tests use a mock database rather than hitting the live Supabase. Tests are fast, deterministic, and work offline.

### Sample Data Constants
```python
STUDENT_ID = "aaaaaaaa-0000-0000-0000-000000000001"
ADMIN_ID   = "bbbbbbbb-0000-0000-0000-000000000002"
ORDER_ID   = "cccccccc-0000-0000-0000-000000000003"
REWARD_ID  = "dddddddd-0000-0000-0000-000000000004"

TIER_EMBER = "11111111-0000-0000-0000-000000000001"
TIER_FLAME = "22222222-0000-0000-0000-000000000002"
TIER_BLAZE = "33333333-0000-0000-0000-000000000003"
TIER_HOLY  = "44444444-0000-0000-0000-000000000004"

SAMPLE_TIERS = [
    {"id": TIER_EMBER, "slug": "ember", "sort_order": 1, "min_hp_threshold": 0,     "earn_multiplier": 1.00},
    {"id": TIER_FLAME, "slug": "flame", "sort_order": 2, "min_hp_threshold": 2500,  "earn_multiplier": 1.08},
    {"id": TIER_BLAZE, "slug": "blaze", "sort_order": 3, "min_hp_threshold": 7500,  "earn_multiplier": 1.15},
    {"id": TIER_HOLY,  "slug": "holy",  "sort_order": 4, "min_hp_threshold": 20000, "earn_multiplier": 1.25},
]

SAMPLE_PROFILE = {
    "id": STUDENT_ID,
    "full_name": "Test Student",
    "role": "student",
    "is_active": True,
    "pending_hp_balance": 0,
    "hp_overflow": 0,
    "hp_earned_120day": 0,
    "monthly_hp_earned": 0,
    "tier_bonus_multiplier": 1.0,
}

SAMPLE_WALLET = {
    "user_id": STUDENT_ID,
    "balance": 5000.00,
}
```

### `make_mock_db()` — The mock database factory

Creates a mock that simulates Supabase query responses:
```python
def make_mock_db(data: dict = None):
    # data = {"profiles": profile_dict_or_list, "orders": [...], etc.}
    # Returns a mock db object where:
    # - db.table("tiers").execute() returns data["tiers"] (or [] if key absent)
    # - db.table("profiles").single().execute() returns data["profiles"] (first item if list)
    # - db.table("orders").insert({...}) returns the dict with a generated UUID
```

### Mock limitation to know

The `MockTableQuery` applies filter calls (`.eq()`, `.gte()`, `.neq()`) but they do NOT actually filter the data — they chain and return the mock. This means:

- Supply exactly the data you expect back in `make_mock_db({"table": specific_data})`
- If a service queries for one row, put one row in the mock data
- If a service queries for 0 rows (idempotency check), supply an empty list `[]`

---

## conftest.py (FastAPI) — The FastAPI Mock System

```python
# fastapi_app/tests/conftest.py

@pytest.fixture
def fastapi_app():
    return create_fastapi_app()

@pytest.fixture
def mock_db_student():
    return make_mock_db({
        "profiles": [SAMPLE_PROFILE],
        "wallets":  [SAMPLE_WALLET],
        "tiers":    SAMPLE_TIERS,
        "hp_transactions": [],
        "orders":   [],
    })

@pytest.fixture
def client(fastapi_app, mock_db_student):
    # Patch at the app.db level — propagates through fastapi_app.deps.get_db
    with patch("app.db.get_db", return_value=mock_db_student):
        with TestClient(fastapi_app) as c:
            yield c

# Auth tokens
STUDENT_TOKEN = create_jwt_token(STUDENT_ID, role="student")
ADMIN_TOKEN   = create_jwt_token(ADMIN_ID,   role="admin")

student_headers = {"Authorization": f"Bearer {STUDENT_TOKEN}"}
admin_headers   = {"Authorization": f"Bearer {ADMIN_TOKEN}"}
```

### Critical FastAPI patch rule

Service functions imported directly into routers must be patched **at the router's import site**, not at the service module:

```python
# ✅ CORRECT — patches the router's local reference
with patch("fastapi_app.routers.hp.get_hp_balance", return_value=MOCK_BALANCE):
    resp = client.get("/api/hp/balance", headers=student_headers)

# ❌ WRONG — patches the service module, not what the router has imported
with patch("app.services.hp_service.get_hp_balance", return_value=MOCK_BALANCE):
    resp = client.get("/api/hp/balance", headers=student_headers)
```

---

## Writing New Tests

### Flask test class structure
```python
class TestB5WalletTopupHP:
    def test_wallet_topup_earns_active_hp(self, app):
        """B5-1: Wallet topup >= 3000 earns 50 HP ACTIVE."""
        amounts_awarded = []

        def capture(user_id, amount, **kwargs):
            amounts_awarded.append(amount)
            return {"added": amount}

        with patch("app.services.hp_service.get_db", return_value=make_mock_db()), \
             patch("app.services.hp_service._record_hp_transaction", side_effect=capture), \
             patch("app.services.hp_service._update_earned_counters"):
            from app.services.hp_service import award_active_hp
            award_active_hp(STUDENT_ID, 50, source_type="wallet_topup")

        assert 50 in amounts_awarded
```

### FastAPI test class structure
```python
class TestHPBalance:
    def test_balance_returns_all_pools(self, client):
        """HP balance endpoint returns active, pending, overflow."""
        MOCK_BALANCE = {"active": 500, "pending": 100, "overflow": 0, "total_visible": 600}

        with patch("fastapi_app.routers.hp.get_hp_balance", return_value=MOCK_BALANCE):
            resp = client.get("/api/hp/balance", headers=student_headers)

        assert resp.status_code == 200
        assert resp.json()["active"] == 500

    def test_balance_requires_auth(self, client):
        resp = client.get("/api/hp/balance")   # no token
        assert resp.status_code == 401
```

### Key rules for new tests

1. **Always mock DB calls** — never let tests hit real Supabase
2. **Use `side_effect=capture`** to assert what was passed to a function
3. **Import service functions inside the `with patch(...)` block** to ensure patches are active at import time
4. **Name tests clearly**: `test_admin_grant_creates_audit_log` not `test_grant`
5. **Test boundary conditions**: 0 HP, exactly at the cap, just above threshold, just below

---

## Test Coverage by Service

| File | Coverage | Critical Paths Tested |
|------|----------|----------------------|
| `hp_service.py` | 89% | All earn/spend/expire/unlock/tier functions |
| `order_service.py` | 81% | Create, confirm payment, deliver, HP award, add-ons |
| `auth_service.py` | 17% | Basic auth (tested via FastAPI integration tests) |
| `payment_service.py` | 28% | Paystack initialization |
| `wallet_service.py` | 82% | Credit/debit, top-up HP trigger |
| `notification_service.py` | 54% | Send/mark read/blast |

### Paths NOT covered by unit tests (manual QA or staging integration)
- `auth_service.register()` against real Supabase Auth
- `payment_service.initialize_payment()` against real Paystack API
- `send_notification()` email channel (SendGrid)
- All scheduled cron tasks (run them manually or mock in integration tests)
- Paystack webhook signature verification end-to-end

---

## What to Do When a Test Fails

1. **Read the failure message** — it says exactly what value was expected vs received
2. **Check if a business rule changed in `app/config.py`** — if HP amounts were updated, the test asserts the old value
3. **Check if a tier multiplier changed** — both `TIER_SLUGS_MULTIPLIER` in `hp_service.py` and tests' `SAMPLE_TIERS` must reflect the new value
4. **Check if the mock supplies the right data** — a test might have wrong sample data
5. **Never change test expectations just to make tests pass** unless the business logic genuinely changed
6. **Run with `-s` flag** to see print statements:
   ```bash
   pytest tests/test_stress_b_hp_earn.py -v -s
   ```
7. **Run single failing test with full traceback:**
   ```bash
   pytest tests/test_stress_b_hp_earn.py::TestB1::test_name -v --tb=long
   ```

---

## Integration Test Checklist (Manual QA Before Deploy)

Run these manually against the staging environment before each release:

- [ ] Register new user → 201 + JWT tokens returned
- [ ] Login → tokens returned
- [ ] Get profile → correct role shown
- [ ] Browse menu categories and items → public access works
- [ ] Create food order (wallet payment) → order created, wallet debited
- [ ] Create food order (card) → Paystack URL returned
- [ ] Simulate Paystack webhook `charge.success` → order moves to `received`
- [ ] Kitchen: update order to `preparing` then `ready`
- [ ] Rider: update order to `dispatched` then `delivered`
- [ ] Check HP balance → active balance increased (base + tier bonus)
- [ ] Check pending pool unlocked if food spend ≥ ₦1,000
- [ ] Welcome bonus awarded on first order → 50 active HP
- [ ] Leave order review → 20 pending HP
- [ ] Redeem a reward → HP deducted, `reward_redemptions` row created
- [ ] Fund wallet ≥ ₦3,000 → 50 active HP awarded
- [ ] Register with referral code → referral row created
- [ ] Referred user's first delivered order → 75 pending HP to referrer
- [ ] Check leaderboard → user appears with correct monthly HP
- [ ] Admin: grant HP to user, check audit log entry
- [ ] Admin: deactivate user, verify they can no longer authenticate
