# Holy Grills — Database Schema Reference
## Every Table · Every Column · What It Means

> **Database:** Supabase (PostgreSQL 15)
> **Schema:** `public`
> **Tables confirmed live:** 51
> **Last validated against live DB:** May 2026
> **Migrations applied:** 001 (core) · 002 (HP ecosystem) · 003 (enums + indexes) · 004 (add-ons, variations, daily limits) · 005 (security + RLS)

---

## Reading This Document

**Hardcoded** = value set in Python config or SQL — requires a code deploy to change
**Softcoded** = value stored in DB — admin can change without a deploy
**System-managed** = written by the backend automatically; never sent by the frontend

---

## Table Index

### Core User Tables
1. [profiles](#1-profiles)
2. [wallets](#2-wallets)
3. [wallet_transactions](#3-wallet_transactions)
4. [user_addresses](#4-user_addresses)

### Menu & Orders
5. [menu_categories](#5-menu_categories)
6. [menu_items](#6-menu_items)
7. [menu_addons](#7-menu_addons) *(Migration 004)*
8. [menu_item_variation_groups](#8-menu_item_variation_groups) *(Migration 004)*
9. [menu_item_variation_options](#9-menu_item_variation_options) *(Migration 004)*
10. [kitchen_settings](#10-kitchen_settings) *(Migration 004)*
11. [orders](#11-orders)
12. [order_items](#12-order_items)
13. [order_reviews](#13-order_reviews)
14. [order_status_log](#14-order_status_log)
15. [delivery_windows](#15-delivery_windows)
16. [delivery_batches](#16-delivery_batches)

### HP Loyalty System
17. [hp_transactions](#17-hp_transactions)
18. [pending_hp_transactions](#18-pending_hp_transactions)
19. [hp_unlock_log](#19-hp_unlock_log)
20. [hp_bundle_purchases](#20-hp_bundle_purchases)

### Tier System
21. [tiers](#21-tiers)
22. [user_tiers](#22-user_tiers)

### Rewards Store
23. [rewards](#23-rewards)
24. [reward_redemptions](#24-reward_redemptions)
25. [flash_redemptions](#25-flash_redemptions)

### Leaderboard & Gamification
26. [leaderboard_snapshots](#26-leaderboard_snapshots)
27. [leaderboard_monthly](#27-leaderboard_monthly)
28. [hall_of_fame](#28-hall_of_fame)
29. [spin_win_entries](#29-spin_win_entries)

### Referrals
30. [referrals](#30-referrals)

### Marketplace
31. [marketplace_listings](#31-marketplace_listings)
32. [marketplace_codes](#32-marketplace_codes)
33. [marketplace_purchases](#33-marketplace_purchases)
34. [marketplace_listing_requests](#34-marketplace_listing_requests)

### Events & Challenges
35. [events](#35-events)
36. [event_checkins](#36-event_checkins)
37. [challenges](#37-challenges)
38. [challenge_completions](#38-challenge_completions)

### Notifications
39. [notifications](#39-notifications)
40. [notification_blasts](#40-notification_blasts)

### Payments
41. [promo_codes](#41-promo_codes)
42. [promo_code_uses](#42-promo_code_uses)
43. [webhook_events](#43-webhook_events)

### Storefront & Operations
44. [storefront_sections](#44-storefront_sections)
45. [operating_hours](#45-operating_hours)
46. [operating_hour_overrides](#46-operating_hour_overrides)
47. [abandoned_carts](#47-abandoned_carts)
48. [admin_audit_log](#48-admin_audit_log)
49. [catering_requests](#49-catering_requests)
50. [newsletter_subscriptions](#50-newsletter_subscriptions)
51. [cron_locks](#51-cron_locks)

---

## 1. profiles

One row per registered user. `id` matches `auth.users.id`. Never delete rows — use `is_active = false`.

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid PK | Matches Supabase Auth `auth.users.id` |
| `full_name` | text NOT NULL | Display name (2–100 chars enforced) |
| `email` | text UNIQUE | From Supabase Auth |
| `phone` | text UNIQUE | Optional; regex `^\+?[0-9]{10,15}$` |
| `role` | user_role enum | `student\|kitchen\|rider\|admin\|super_admin` |
| `is_active` | boolean DEFAULT true | False = banned/deactivated |
| `referral_code` | text UNIQUE NOT NULL | Auto-generated (e.g. "HG-ABC123") |
| `referred_by` | uuid FK→profiles | Who referred this user |
| `date_of_birth` | date | Must be ≥10 years ago (CHECK constraint) |
| `google_id` | text UNIQUE | Google OAuth ID (pre-wired) |
| `push_enabled` | boolean | User notification preference |
| `email_notifications` | boolean | User notification preference |
| `has_scheduled_order` | boolean | True if user has an active scheduled order |
| `is_active` | boolean DEFAULT true | False = deactivated |
| `deactivated_at` | timestamptz | Set when deactivated |
| `deactivated_by` | uuid FK→profiles | Admin who deactivated |
| `pending_hp_balance` | integer DEFAULT 0 | Locked HP pending food spend to unlock |
| `hp_overflow` | integer DEFAULT 0 | HP vaulted because pending pool was full |
| `hp_earned_120day` | integer DEFAULT 0 | Rolling 120-day HP — tier determination basis |
| `hp_earned_120day_updated_at` | timestamptz | When 120-day figure was last recalculated |
| `monthly_hp_earned` | integer DEFAULT 0 | HP earned this calendar month |
| `last_monthly_reset_at` | timestamptz | When monthly counter was last zeroed |
| `tier_bonus_multiplier` | numeric(4,2) DEFAULT 1.0 | Current earn multiplier |
| `created_at` | timestamptz DEFAULT now() | |
| `updated_at` | timestamptz | Auto-updated by trigger |

**Constraints:** `pending_hp_balance >= 0`, `hp_overflow >= 0`, `hp_earned_120day >= 0`, `monthly_hp_earned >= 0`, `full_name` 2–100 chars, phone regex, `date_of_birth ≤ 18 years ago`.

**Triggers:** `trg_create_wallet_on_signup` (auto-creates wallet), `trg_audit_role_change` (logs role changes to admin_audit_log), `trg_profiles_updated_at`.

**RLS:** Own SELECT + UPDATE. Admin ALL. No INSERT policy — profiles are created via backend auth service only.

---

## 2. wallets

One wallet per user, auto-created by trigger on profile insert.

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid PK | |
| `user_id` | uuid UNIQUE FK→profiles | One wallet per user |
| `balance` | numeric(12,2) DEFAULT 0 | Naira balance. CHECK `balance >= 0`. |
| `currency` | text DEFAULT 'NGN' | Always NGN |
| `virtual_account_number` | text | Paystack DVA account number |
| `virtual_account_bank` | text | Bank name |
| `virtual_account_name` | text | Account holder name |
| `virtual_account_ref` | text UNIQUE | Paystack internal reference |
| `created_at` | timestamptz | |
| `updated_at` | timestamptz | Auto-updated by trigger |

**RLS:** Own SELECT only. All writes via service role.

---

## 3. wallet_transactions

Immutable ledger of all Naira movements.

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid PK | |
| `wallet_id` | uuid FK→wallets | |
| `user_id` | uuid FK→profiles | Denormalised for speed |
| `amount` | numeric(12,2) NOT NULL | Positive = credit, Negative = debit. CHECK `amount <> 0`. |
| `type` | wallet_tx_type enum | `credit_bank_transfer\|credit_card\|credit_admin\|debit_order\|debit_marketplace\|debit_refund\|debit_withdrawal` |
| `balance_after` | numeric(12,2) NOT NULL | Wallet balance after this transaction |
| `reference_id` | uuid | FK to order, promo, etc. (polymorphic) |
| `reference_type` | text | What `reference_id` points to |
| `payment_reference` | text | Paystack reference string |
| `idempotency_key` | text UNIQUE | Prevents double-processing |
| `notes` | text | Human-readable description |
| `provider_response` | jsonb | Raw Paystack payload |
| `created_at` | timestamptz | |

**RLS:** Own SELECT only.

---

## 4. user_addresses

Saved delivery addresses per user.

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid PK | |
| `user_id` | uuid FK→profiles | |
| `label` | text | e.g. "Home", "Office" |
| `address_line` | text | Street address |
| `landmark` | text | Optional landmark |
| `zone` | text | Delivery zone |
| `is_default` | boolean DEFAULT false | Default delivery address |
| `created_at` | timestamptz | |

**RLS:** Own ALL. Admin SELECT.

---

## 5. menu_categories

Food categories (e.g. "Campus Picks", "Drinks").

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid PK | |
| `name` | text NOT NULL | Display name |
| `slug` | text UNIQUE NOT NULL | URL-safe identifier |
| `description` | text | Optional longer description |
| `sort_order` | integer DEFAULT 0 | Lower = displayed first |
| `is_active` | boolean DEFAULT true | False = hidden |
| `image_url` | text | Category hero image |
| `created_at` | timestamptz | |
| `updated_at` | timestamptz | Auto-updated |

**RLS:** Public SELECT. Admin ALL.

---

## 6. menu_items

Individual food items. Soft-delete via `is_archived` preserves order history.

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid PK | |
| `category_id` | uuid FK→menu_categories | |
| `name` | text NOT NULL | Display name |
| `description` | text | Menu description |
| `sku` | text UNIQUE | Optional internal code |
| `price` | numeric(10,2) NOT NULL | Menu price in Naira |
| `cost_price` | numeric(10,2) | Internal cost (HP pricing formula) |
| `perceived_value` | numeric(10,2) | Perceived market value (HP pricing) |
| `hp_earn_value` | integer | Override HP for this item |
| `dietary_tags` | text[] | e.g. `["halal", "grilled"]` |
| `daily_limit` | integer | Max servings per day (null = unlimited) *(Migration 004)* |
| `is_available` | boolean DEFAULT true | Can be toggled for 86'd items |
| `is_archived` | boolean DEFAULT false | Soft delete |
| `archived_at` | timestamptz | |
| `archived_by` | uuid FK→profiles | Admin who archived |
| `last_edited_by` | uuid FK→profiles | Admin who last changed |
| `image_url` | text | Product photo |
| `created_at` | timestamptz | |
| `updated_at` | timestamptz | Auto-updated |

**RLS:** Public SELECT where `is_archived = false`. Admin ALL.

---

## 7. menu_addons *(Migration 004)*

Standalone extras customers can add to any order (e.g. "Extra Sauce", "Bottled Water").

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid PK | |
| `name` | text NOT NULL | Display name |
| `description` | text | Optional description |
| `price` | numeric(10,2) DEFAULT 0 | Additional price in Naira |
| `is_available` | boolean DEFAULT true | Toggle availability |
| `is_archived` | boolean DEFAULT false | Soft delete |
| `sort_order` | integer DEFAULT 0 | Display order |
| `created_at` | timestamptz | |
| `updated_at` | timestamptz | Auto-updated |

**RLS:** Public SELECT where `is_available = true AND is_archived = false`. Admin ALL.

---

## 8. menu_item_variation_groups *(Migration 004)*

Variation groups attached to a menu item (e.g. "Choose your side").

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid PK | |
| `menu_item_id` | uuid FK→menu_items CASCADE DELETE | Parent item |
| `name` | text NOT NULL | e.g. "Choose your side" |
| `is_required` | boolean DEFAULT false | Must customer pick? |
| `min_selections` | integer DEFAULT 0 | Minimum options to select |
| `max_selections` | integer DEFAULT 1 | Maximum options to select |
| `sort_order` | integer DEFAULT 0 | Display order |
| `created_at` | timestamptz | |

**RLS:** Public SELECT. Admin ALL.

---

## 9. menu_item_variation_options *(Migration 004)*

Individual options within a variation group (e.g. "Coleslaw", "Plantain").

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid PK | |
| `variation_group_id` | uuid FK→menu_item_variation_groups CASCADE DELETE | Parent group |
| `name` | text NOT NULL | e.g. "Coleslaw" |
| `price_delta` | numeric(10,2) DEFAULT 0 | Extra charge (0 = included) |
| `is_available` | boolean DEFAULT true | Toggle option availability |
| `sort_order` | integer DEFAULT 0 | Display order |
| `created_at` | timestamptz | |

**RLS:** Public SELECT. Admin ALL.

---

## 10. kitchen_settings *(Migration 004)*

Key-value store for kitchen configuration (daily capacity, etc.).

| Column | Type | Description |
|--------|------|-------------|
| `key` | text PK | Setting key (e.g. `daily_order_capacity`) |
| `value` | text NOT NULL | Setting value |
| `updated_at` | timestamptz | |
| `updated_by` | uuid FK→profiles | Admin who last changed |

**Seed row:** `('daily_order_capacity', '150')`.

**RLS:** Kitchen + admin SELECT. Admin ALL (write).

---

## 11. orders

Core order record. Status machine: `pending_payment → received → preparing → ready → dispatched → delivered`.

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid PK | |
| `user_id` | uuid FK→profiles | Null for guest orders |
| `status` | order_status enum | Current status |
| `version` | integer DEFAULT 1 | Optimistic lock version (auto-incremented) |
| `subtotal` | numeric(12,2) | Sum of items. `>= 0`. |
| `delivery_fee` | numeric(12,2) | Delivery fee. `>= 0`. |
| `promo_discount` | numeric(12,2) DEFAULT 0 | Promo code discount. `>= 0`. |
| `hp_discount` | numeric(12,2) DEFAULT 0 | HP redeemed as Naira discount. `>= 0`. |
| `total` | numeric(12,2) | Final charged. CHECK `total = subtotal + delivery_fee - promo_discount - hp_discount`. |
| `payment_method` | payment_method enum | `wallet\|card\|split\|guest_card` |
| `wallet_amount_used` | numeric(12,2) DEFAULT 0 | Wallet portion paid |
| `card_amount_used` | numeric(12,2) DEFAULT 0 | Card portion paid |
| `payment_reference` | text UNIQUE | Paystack reference |
| `payment_intent_id` | text UNIQUE | Paystack payment intent |
| `payment_confirmed_at` | timestamptz | When webhook confirmed payment |
| `hp_points_used` | integer DEFAULT 0 | HP redeemed |
| `hp_earned` | integer DEFAULT 0 | HP awarded on delivery |
| `tier_bonus_hp` | integer DEFAULT 0 | Bonus HP from tier multiplier |
| `unlocked_pending_hp` | integer DEFAULT 0 | Pending HP this order unlocked |
| `hp_credited_at` | timestamptz | When HP was awarded |
| `promo_code_id` | uuid FK→promo_codes | Applied promo code |
| `delivery_window_id` | uuid FK→delivery_windows | Selected slot |
| `batch_id` | uuid FK→delivery_batches | Assigned rider batch |
| `delivery_address_snapshot` | jsonb | `{address_line, landmark, zone}` frozen at order time |
| `notes` | text | Customer delivery notes |
| `is_scheduled` | boolean DEFAULT false | Pre-ordered |
| `scheduled_for_window_id` | uuid FK→delivery_windows | Target window |
| `review_submitted` | boolean DEFAULT false | True after review |
| `guest_name` | text | Guest checkout name (≤100 chars) |
| `guest_phone` | text | Guest phone (regex) |
| `guest_email` | text | Guest email (regex) |
| `claim_token` | text UNIQUE | UUID for guest to claim order |
| `claimed_by` | uuid FK→profiles | Who claimed a guest order |
| `claimed_at` | timestamptz | When order was claimed |
| `received_at` | timestamptz | Auto-stamped on status='received' |
| `preparing_at` | timestamptz | Auto-stamped |
| `ready_at` | timestamptz | Auto-stamped |
| `dispatched_at` | timestamptz | Auto-stamped |
| `delivered_at` | timestamptz | Auto-stamped |
| `attempted_at` | timestamptz | Auto-stamped |
| `unclaimed_at` | timestamptz | Auto-stamped |
| `cancelled_at` | timestamptz | Auto-stamped |
| `created_at` | timestamptz DEFAULT now() | |
| `updated_at` | timestamptz | Auto-updated |

**Constraints:** Total arithmetic enforced. Guest identity constraint. All amounts >= 0.

**Triggers:** No hard delete. Version bump on UPDATE. Status log on status change. Timestamp stamps on status change.

**RLS:** Own SELECT + kitchen/rider SELECT (scoped). Admin ALL. NO INSERT policy — created exclusively via backend API.

**Order Status Machine:**
```
pending_payment → received → preparing → ready → dispatched → delivered
                                                              → attempted → unclaimed
Any pre-delivery state → cancelled
```

---

## 12. order_items

Line items within an order. Supports both menu items and add-ons.

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid PK | |
| `order_id` | uuid FK→orders | |
| `menu_item_id` | uuid FK→menu_items | Null for add-on rows |
| `item_name` | text NOT NULL | Name frozen at order time |
| `unit_price` | numeric(10,2) NOT NULL | Price frozen at order time |
| `quantity` | integer NOT NULL | |
| `subtotal` | numeric(12,2) | `unit_price × quantity` |
| `hp_earn_value` | integer DEFAULT 0 | HP for this item |
| `selected_variations` | jsonb DEFAULT '[]' | `[{"option_id": "uuid", "name": "Coleslaw", "price_delta": 0}]` *(Migration 004)* |
| `is_addon` | boolean DEFAULT false | True for add-on rows *(Migration 004)* |
| `addon_id` | uuid FK→menu_addons | Set when `is_addon = true` *(Migration 004)* |
| `created_at` | timestamptz | |

**Note:** `menu_item_id` is nullable (for add-on rows). Either `menu_item_id` or `addon_id` must be set.

**RLS:** SELECT via parent order policy.

---

## 13. order_reviews

Customer reviews for delivered orders. Earns 20 HP pending (once per month).

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid PK | |
| `order_id` | uuid FK→orders | Must be status='delivered' |
| `user_id` | uuid FK→profiles | |
| `rating` | review_rating enum | '1' through '5' |
| `comment` | text | Optional written review |
| `hp_awarded` | boolean DEFAULT false | True if monthly review HP granted |
| `hp_transaction_id` | uuid FK→hp_transactions | Link to HP transaction |
| `created_at` | timestamptz | |

**RLS:** Own SELECT + INSERT (immutable after insert). Admin SELECT. No UPDATE or DELETE allowed.

---

## 14. order_status_log

Immutable audit trail of every status change.

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid PK | |
| `order_id` | uuid FK→orders | |
| `from_status` | text | Previous status |
| `to_status` | text | New status |
| `changed_by` | uuid FK→profiles | Who made the change |
| `notes` | text | Optional context |
| `created_at` | timestamptz | Auto-populated by trigger |

**Note:** Rows are written by `trg_log_order_status` trigger — never written directly by application code.

---

## 15. delivery_windows

Time slots when deliveries happen.

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid PK | |
| `label` | text NOT NULL | e.g. "Lunch Mon 12–2pm" |
| `opens_at` | timestamptz | When ordering opens |
| `closes_at` | timestamptz | Ordering deadline |
| `status` | window_status enum | `scheduled\|open\|closed\|dispatched\|completed` |
| `created_by` | uuid FK→profiles | |
| `modified_by` | uuid FK→profiles | |
| `created_at` | timestamptz | |
| `updated_at` | timestamptz | Auto-updated |

**RLS:** Public SELECT. Admin ALL.

---

## 16. delivery_batches

Group of orders assigned to one rider for one zone.

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid PK | |
| `window_id` | uuid FK→delivery_windows | |
| `rider_id` | uuid FK→profiles | Rider (role='rider') assigned |
| `zone` | text NOT NULL | Delivery zone |
| `status` | batch_status enum | `pending\|assigned\|in_progress\|completed` |
| `assigned_at` | timestamptz | |
| `dispatched_at` | timestamptz | |
| `completed_at` | timestamptz | |
| `admin_notes` | text | |
| `created_at` | timestamptz | |
| `updated_at` | timestamptz | Auto-updated |

**RLS:** Rider SELECT (own batch) + UPDATE (own batch). Admin ALL.

---

## 17. hp_transactions

Master HP ledger. Append-only — never modified or deleted. Active balance = `SUM(amount WHERE status='active')`.

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid PK | |
| `user_id` | uuid FK→profiles | |
| `amount` | integer NOT NULL | Positive = earn, Negative = spend/expire. CHECK `amount <> 0`. |
| `type` | hp_transaction_type enum | e.g. `earn_order`, `spend_reward`, `expire`, `unlock` |
| `reference_id` | uuid | FK to order/redemption/referral (polymorphic) |
| `reference_type` | text | What `reference_id` points to |
| `notes` | text | Human-readable description |
| `issued_by_admin_id` | uuid FK→profiles | Set for admin grants |
| `source_type` | text | `food\|referral\|review\|event\|welcome\|birthday\|wallet_topup\|admin\|unlock\|expiry` |
| `status` | text DEFAULT 'active' | `active` (spendable) \| `pending` (locked) \| `overflow` (vaulted) |
| `balance_after` | integer NOT NULL | HP balance snapshot. CHECK `balance_after >= 0`. |
| `unlocked_from_pending_id` | uuid FK→hp_transactions | Links unlock to pending source |
| `created_at` | timestamptz | |

**Triggers:** `trg_hp_tx_immutable` — blocks all UPDATE/DELETE.

**RLS:** Own SELECT. Admin own SELECT (via same policy). No INSERT policy for clients — all writes via service role.

---

## 18. pending_hp_transactions

Detailed log of pending HP earn events. Tracks unlock status per batch.

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid PK | |
| `user_id` | uuid FK→profiles | |
| `amount` | integer NOT NULL | CHECK `amount > 0` |
| `source_type` | text NOT NULL | `referral\|review\|event\|marketplace\|bundle_purchase` |
| `reference_id` | uuid | Polymorphic link |
| `reference_type` | text | |
| `status` | text DEFAULT 'pending' | CHECK `status IN ('pending','unlocked','expired','overflow')` |
| `unlocked_amount` | integer DEFAULT 0 | How much of this batch unlocked so far |
| `unlocked_at` | timestamptz | When fully unlocked |
| `expires_at` | timestamptz | Optional expiry |
| `notes` | text | |
| `created_at` | timestamptz | |

**RLS:** Own SELECT. Admin own SELECT.

---

## 19. hp_unlock_log

Audit trail of every pending→active HP unlock event.

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid PK | |
| `user_id` | uuid FK→profiles | |
| `order_id` | uuid FK→orders | Food order that triggered unlock |
| `food_spend_amount` | numeric(12,2) | Amount spent |
| `hp_unlocked` | integer | HP moved pending→active |
| `hp_overflow_restored` | integer DEFAULT 0 | HP moved overflow→pending |
| `pending_balance_before` | integer | Snapshot before unlock |
| `pending_balance_after` | integer | Snapshot after unlock |
| `active_balance_after` | integer | Active balance after |
| `created_at` | timestamptz | |

**RLS:** Own SELECT. Admin ALL.

---

## 20. hp_bundle_purchases

Event hosts buying HP at ₦5/HP to award attendees.

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid PK | |
| `event_host_id` | uuid FK→profiles | Organizer who bought HP |
| `hp_amount` | integer NOT NULL | CHECK `hp_amount > 0` |
| `naira_paid` | numeric(12,2) | Amount paid |
| `price_per_hp` | numeric(6,2) DEFAULT 5.00 | Always ₦5/HP |
| `payment_reference` | text | Paystack reference |
| `hp_tx_id` | uuid FK→hp_transactions | HP transaction created |
| `created_at` | timestamptz | |

**RLS:** Own SELECT (event_host_id). Admin ALL.

---

## 21. tiers

Tier definitions. Seeded once. Four tiers: Ember, Flame, Blaze, Holy.

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid PK | |
| `name` | text UNIQUE NOT NULL | "Ember", "Flame", "Blaze", "Holy" |
| `slug` | text UNIQUE NOT NULL | "ember", "flame", "blaze", "holy" |
| `sort_order` | integer UNIQUE NOT NULL | 1=Ember … 4=Holy. Used for comparisons. |
| `min_hp_threshold` | integer NOT NULL | Rolling 120-day HP to HOLD this tier |
| `earn_multiplier` | numeric(4,2) DEFAULT 1.0 | Food order HP multiplier |
| `badge_color_hex` | text | UI badge color |
| `perks` | jsonb | Free-form tier perks for display |
| `created_at` | timestamptz | |

**Seed data:**

| Tier | sort_order | min_hp_threshold | earn_multiplier |
|------|-----------|-----------------|----------------|
| Ember | 1 | 0 | 1.00 |
| Flame | 2 | 2,500 | 1.08 |
| Blaze | 3 | 7,500 | 1.15 |
| Holy | 4 | 20,000 | 1.25 |

**RLS:** Public SELECT. Admin ALL.

---

## 22. user_tiers

History of each user's tier memberships. Only `is_current = true` row is active.

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid PK | |
| `user_id` | uuid FK→profiles | |
| `tier_id` | uuid FK→tiers | |
| `is_current` | boolean DEFAULT false | True for the active tier row |
| `achieved_at` | timestamptz | When user first reached this tier |
| `is_in_grace_period` | boolean DEFAULT false | True during 7-day grace |
| `grace_period_ends_at` | timestamptz | When grace expires |
| `downgraded_at` | timestamptz | When dropped from a tier |
| `downgraded_to_tier_id` | uuid FK→tiers | Tier dropped to |

**RLS:** Own SELECT. Admin via service role.

---

## 23. rewards

HP reward store. Active rewards visible to all users.

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid PK | |
| `name` | text NOT NULL | Display name |
| `description` | text | Store description |
| `category` | reward_category enum | `food\|discount\|event_ticket\|service_voucher\|giveaway_entry\|exclusive_perk` |
| `hp_cost` | integer NOT NULL | HP required |
| `image_url` | text | Product image |
| `is_active` | boolean DEFAULT true | False = hidden |
| `quantity_available` | integer | Null = unlimited |
| `quantity_redeemed` | integer DEFAULT 0 | Auto-incremented |
| `min_tier_id` | uuid FK→tiers | Minimum tier required |
| `starts_at` | timestamptz | Availability start |
| `ends_at` | timestamptz | Availability end |
| `created_at` | timestamptz | |
| `updated_at` | timestamptz | Auto-updated |

**RLS:** Public SELECT where `is_active = true`. Admin ALL.

---

## 24. reward_redemptions

Records of HP spent on rewards.

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid PK | |
| `user_id` | uuid FK→profiles | |
| `reward_id` | uuid FK→rewards | |
| `hp_spent` | integer NOT NULL | HP deducted |
| `hp_transaction_id` | uuid FK→hp_transactions | Spend transaction |
| `status` | text | `pending\|completed\|cancelled` |
| `fulfilment_notes` | text | Admin fulfilment notes |
| `created_at` | timestamptz | |
| `updated_at` | timestamptz | |

**RLS:** Own SELECT. Admin via service role.

---

## 25. flash_redemptions

Time-limited flash reward redemptions.

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid PK | |
| `user_id` | uuid FK→profiles | |
| `reward_id` | uuid FK→rewards | |
| `redeemed_at` | timestamptz | |
| `expires_at` | timestamptz | When flash expires |
| `code` | text | Redemption code to show vendor |
| `is_used` | boolean DEFAULT false | Marked used by vendor |

**RLS:** Own SELECT. Admin ALL.

---

## 26. leaderboard_snapshots

Daily HP leaderboard snapshots (top-N users).

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid PK | |
| `snapshot_date` | date | Date of snapshot |
| `user_id` | uuid FK→profiles | |
| `rank` | integer | Position on this date |
| `hp_earned_120day` | integer | Rolling HP on snapshot date |
| `tier_id` | uuid FK→tiers | Tier on snapshot date |
| `created_at` | timestamptz | |

**RLS:** Public SELECT. Admin ALL.

---

## 27. leaderboard_monthly

Monthly cumulative HP leaderboard.

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid PK | |
| `month` | date | First day of month |
| `user_id` | uuid FK→profiles | |
| `rank` | integer | Monthly rank |
| `monthly_hp` | integer | HP earned this month |
| `created_at` | timestamptz | |

**RLS:** Public SELECT. Admin ALL.

---

## 28. hall_of_fame

All-time top performers. Publicly visible.

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid PK | |
| `user_id` | uuid FK→profiles | |
| `category` | text | `top_referrer\|top_earner\|top_spender` etc. |
| `period` | text | `monthly\|all_time` |
| `rank` | integer | |
| `value` | integer | HP or referral count |
| `awarded_at` | timestamptz | |

**RLS:** Public SELECT. Admin ALL.

---

## 29. spin_win_entries

Spin-to-win game entries.

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid PK | |
| `user_id` | uuid FK→profiles | |
| `hp_won` | integer | HP prize |
| `spun_at` | timestamptz | |
| `hp_transaction_id` | uuid FK→hp_transactions | |

**RLS:** Own SELECT. Admin ALL.

---

## 30. referrals

One row per referral relationship.

**UNIQUE constraint:** `(referrer_id, referred_user_id)` — enforced at DB level.

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid PK | |
| `referrer_id` | uuid FK→profiles | User who referred |
| `referred_user_id` | uuid FK→profiles | User who signed up |
| `status` | text | `pending\|completed` |
| `hp_awarded` | boolean DEFAULT false | Whether 75 HP was granted |
| `created_at` | timestamptz | |
| `completed_at` | timestamptz | When referral was completed |

**RLS:** Own SELECT (referrer or referred_user_id = auth.uid()).

---

## 31. marketplace_listings

HP-priced items/codes available in the marketplace.

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid PK | |
| `name` | text NOT NULL | |
| `description` | text | |
| `type` | listing_type enum | `code\|link\|manual` |
| `hp_price` | integer NOT NULL | HP cost |
| `quantity_available` | integer | Total quantity |
| `quantity_sold` | integer DEFAULT 0 | Auto-updated |
| `is_active` | boolean DEFAULT true | |
| `is_out_of_stock` | boolean DEFAULT false | Auto-updated by trigger |
| `low_inventory_threshold` | integer | Triggers low-stock flag |
| `image_url` | text | |
| `vendor_name` | text | |
| `created_at` | timestamptz | |
| `updated_at` | timestamptz | Auto-updated |

**RLS:** Public SELECT where `is_active = true`. Admin ALL.

---

## 32. marketplace_codes

Individual redemption codes for code-type listings. Assigned atomically via `claim_marketplace_code()`.

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid PK | |
| `listing_id` | uuid FK→marketplace_listings | |
| `code` | text NOT NULL | The redemption code |
| `status` | code_status enum | `available\|assigned\|redeemed\|expired` |
| `assigned_to_user_id` | uuid FK→profiles | Set on assignment |
| `assigned_at` | timestamptz | |
| `uploaded_at` | timestamptz DEFAULT now() | |

**RLS:** Admin ALL only. Codes are distributed via function, never direct SELECT.

---

## 33. marketplace_purchases

Records of HP spent on marketplace items.

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid PK | |
| `user_id` | uuid FK→profiles | |
| `listing_id` | uuid FK→marketplace_listings | |
| `code_id` | uuid FK→marketplace_codes | Set for code-type purchases |
| `hp_spent` | integer | |
| `hp_transaction_id` | uuid FK→hp_transactions | |
| `created_at` | timestamptz | |

**RLS:** Own SELECT.

---

## 34. marketplace_listing_requests

Vendor requests to list on the marketplace.

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid PK | |
| `vendor_name` | text NOT NULL | |
| `contact_email` | text NOT NULL | |
| `description` | text | What they want to offer |
| `status` | text DEFAULT 'pending' | Admin manages |
| `created_at` | timestamptz | |
| `updated_at` | timestamptz | Auto-updated |

**RLS:** Public INSERT. Admin ALL.

---

## 35. events

Events where attendees earn HP via QR check-in.

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid PK | |
| `title` | text NOT NULL | |
| `slug` | text UNIQUE NOT NULL | |
| `description` | text | |
| `event_date` | date NOT NULL | |
| `venue` | text | |
| `hp_earn` | integer | HP awarded per check-in |
| `qr_code_token` | text UNIQUE | Token embedded in QR code |
| `qr_expires_at` | timestamptz | QR code expiry |
| `is_active` | boolean DEFAULT false | |
| `created_at` | timestamptz | |
| `updated_at` | timestamptz | Auto-updated |

**RLS:** Public SELECT where `is_active = true`. Admin ALL.

---

## 36. event_checkins

Records of QR check-ins at events. UNIQUE per user per event.

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid PK | |
| `event_id` | uuid FK→events | |
| `user_id` | uuid FK→profiles | |
| `hp_awarded` | integer | HP amount given |
| `qr_token_used` | text | Token used (UNIQUE when not null — prevents replay) |
| `scan_timestamp` | timestamptz | When QR was scanned |

**Constraints:** `UNIQUE(event_id, user_id)` — one check-in per user per event. `UNIQUE(qr_token_used)` WHERE NOT NULL — prevents QR replay.

**RLS:** Own SELECT.

---

## 37. challenges

Time-limited HP challenges.

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid PK | |
| `title` | text NOT NULL | |
| `description` | text | |
| `type` | challenge_type enum | e.g. `order_streak`, `referral_milestone`, `review` |
| `hp_reward` | integer NOT NULL | HP awarded on completion |
| `max_completions_per_user` | integer DEFAULT 1 | |
| `starts_at` | timestamptz NOT NULL | |
| `ends_at` | timestamptz | Null = no expiry |
| `criteria` | jsonb DEFAULT '{}' | Criteria for completion |
| `is_active` | boolean DEFAULT false | |
| `created_by` | uuid FK→profiles | |
| `created_at` | timestamptz | |
| `updated_at` | timestamptz | Auto-updated |

**RLS:** Public SELECT where `is_active = true`. Admin ALL.

---

## 38. challenge_completions

Records of challenge completions per user.

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid PK | |
| `user_id` | uuid FK→profiles | |
| `challenge_id` | uuid FK→challenges | |
| `hp_awarded` | integer | HP given |
| `hp_transaction_id` | uuid FK→hp_transactions | |
| `completed_at` | timestamptz DEFAULT now() | |

**Constraint:** Partial UNIQUE index: `UNIQUE(user_id, challenge_id) WHERE max_completions_per_user = 1` — prevents double-completing once-only challenges.

**RLS:** Own SELECT.

---

## 39. notifications

Per-user in-app notifications.

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid PK | |
| `user_id` | uuid FK→profiles | |
| `type` | notification_type enum | e.g. `order_update`, `hp_earned` |
| `channel` | notification_channel enum | `in_app\|push\|email` |
| `title` | text | |
| `body` | text | |
| `data` | jsonb | Extra payload |
| `is_read` | boolean DEFAULT false | |
| `read_at` | timestamptz | |
| `created_at` | timestamptz | |

**RLS:** Own SELECT + UPDATE (mark read). No admin read policy (use service role).

---

## 40. notification_blasts

Admin-sent broadcast notifications.

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid PK | |
| `title` | text NOT NULL | |
| `body` | text NOT NULL | |
| `target_role` | text | Null = all users |
| `sent_at` | timestamptz | |
| `sent_by` | uuid FK→profiles | |
| `recipient_count` | integer | |

**RLS:** Admin ALL only.

---

## 41. promo_codes

Promo/discount codes.

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid PK | |
| `code` | text UNIQUE NOT NULL | Case-insensitive code |
| `discount_type` | discount_type enum | `percentage\|flat` |
| `discount_value` | numeric(10,2) | |
| `scope` | promo_scope enum | `cart_wide\|item_specific` |
| `min_order_value` | numeric(12,2) DEFAULT 0 | |
| `max_discount_amount` | numeric(12,2) | Cap on discount |
| `is_active` | boolean DEFAULT true | |
| `starts_at` | timestamptz | |
| `ends_at` | timestamptz | |
| `max_uses` | integer | Total usage cap |
| `max_uses_per_user` | integer | Per-user cap |
| `used_count` | integer DEFAULT 0 | Auto-incremented by trigger |
| `created_by` | uuid FK→profiles | |
| `created_at` | timestamptz | |
| `updated_at` | timestamptz | Auto-updated |

**RLS:** Public SELECT where `is_active = true`. Admin ALL.

---

## 42. promo_code_uses

Per-use audit trail.

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid PK | |
| `promo_code_id` | uuid FK→promo_codes | |
| `user_id` | uuid FK→profiles | |
| `order_id` | uuid FK→orders | |
| `discount_applied` | numeric(12,2) | |
| `created_at` | timestamptz | |

**Trigger:** `trg_increment_promo_count` — bumps `promo_codes.used_count` on INSERT.

**RLS:** Own SELECT.

---

## 43. webhook_events

Idempotent log of all incoming payment webhooks.

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid PK | |
| `provider` | text NOT NULL | `paystack` |
| `event_type` | text NOT NULL | e.g. `charge.success` |
| `idempotency_key` | text NOT NULL UNIQUE | `"provider:event_type:reference"` |
| `reference` | text | Payment reference |
| `signature_verified` | boolean NOT NULL | True only if HMAC matched |
| `raw_payload` | jsonb NOT NULL | Full event body |
| `processing_status` | text | `pending\|processed\|rejected\|failed` |
| `processing_notes` | text | Error details on failure |
| `received_at` | timestamptz DEFAULT now() | |
| `processed_at` | timestamptz | |

**RLS:** Admin ALL only (via service role in practice).

---

## 44. storefront_sections

Configurable sections on the app home screen.

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid PK | |
| `title` | text NOT NULL | |
| `section_type` | text | e.g. `hero`, `featured`, `challenge` |
| `content` | jsonb | Section-specific data |
| `is_active` | boolean DEFAULT true | |
| `sort_order` | integer DEFAULT 0 | |
| `created_at` | timestamptz | |
| `updated_at` | timestamptz | Auto-updated |

**RLS:** Public SELECT. Admin ALL.

---

## 45. operating_hours

Store hours by day of week. 7 rows (one per day).

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid PK | |
| `day` | day_of_week enum | `monday` through `sunday` |
| `open_time` | time | e.g. `10:00:00` |
| `close_time` | time | e.g. `20:00:00` |
| `is_closed` | boolean DEFAULT false | True for days the store is closed |
| `updated_at` | timestamptz | Auto-updated |

**RLS:** Public SELECT. Admin ALL.

---

## 46. operating_hour_overrides

Holiday and special-day exceptions.

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid PK | |
| `date` | date NOT NULL UNIQUE | Specific date override |
| `is_closed` | boolean DEFAULT false | |
| `open_time` | time | Override open time |
| `close_time` | time | Override close time |
| `reason` | text | e.g. "Public Holiday" |
| `created_at` | timestamptz | |

**RLS:** Public SELECT. Admin ALL.

---

## 47. abandoned_carts

Tracks incomplete checkout sessions for recovery nudges.

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid PK | |
| `user_id` | uuid UNIQUE FK→profiles | One cart per user |
| `cart_snapshot` | jsonb DEFAULT '[]' | Items in cart |
| `item_count` | integer DEFAULT 0 | CHECK `>= 0` |
| `estimated_total` | numeric(12,2) DEFAULT 0 | |
| `last_active_at` | timestamptz DEFAULT now() | |
| `recovery_sent_count` | integer DEFAULT 0 | CHECK `>= 0` |
| `last_recovery_sent_at` | timestamptz | |
| `next_recovery_at` | timestamptz | Scheduled next nudge |
| `is_recovered` | boolean DEFAULT false | True if order placed |
| `recovered_at` | timestamptz | |
| `recovered_order_id` | uuid FK→orders | |
| `created_at` | timestamptz | |
| `updated_at` | timestamptz | Auto-updated |

**RLS:** Own ALL. Admin SELECT.

---

## 48. admin_audit_log

Immutable record of all admin actions. Cannot be updated or deleted.

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid PK | |
| `actor_id` | uuid FK→profiles | Admin who acted |
| `actor_role` | text | Role at time of action |
| `target_table` | text NOT NULL | Which table was affected |
| `target_id` | uuid | Row affected |
| `action` | text NOT NULL | e.g. `role_change`, `ban`, `grant_hp` |
| `before_data` | jsonb | State before change |
| `after_data` | jsonb | State after change |
| `reason` | text | Admin-supplied reason |
| `ip_address` | inet | Client IP |
| `user_agent` | text | Client user agent |
| `created_at` | timestamptz | |

**Trigger:** `trg_admin_audit_immutable` — blocks all UPDATE/DELETE.

**RLS:** Admin SELECT only. No client INSERT (trigger writes via service role).

---

## 49. catering_requests

Event catering inquiry submissions. Public INSERT.

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid PK | |
| `organizer_name` | text NOT NULL | |
| `organizer_email` | text NOT NULL | |
| `event_name` | text NOT NULL | 2–200 chars |
| `event_date` | date NOT NULL | |
| `event_time` | time | |
| `venue` | text NOT NULL | |
| `expected_attendance` | integer NOT NULL | CHECK `> 0` |
| `budget_range` | text | ≤100 chars |
| `catering_notes` | text | ≤2000 chars |
| `hp_promo_optin` | boolean DEFAULT false | Want HP promo at event? |
| `status` | catering_status enum | `submitted\|reviewing\|quoted\|accepted\|declined\|completed` |
| `assigned_to` | uuid FK→profiles | Admin assigned |
| `admin_notes` | text | |
| `quoted_amount` | numeric | |
| `event_id` | uuid FK→events | If linked to an event record |
| `created_at` | timestamptz | |
| `updated_at` | timestamptz | Auto-updated |

**RLS:** Public INSERT. Admin ALL.

---

## 50. newsletter_subscriptions

Email newsletter opt-ins.

| Column | Type | Description |
|--------|------|-------------|
| `id` | uuid PK | |
| `email` | text NOT NULL UNIQUE | |
| `user_id` | uuid FK→profiles | Null for non-registered subscribers |
| `is_subscribed` | boolean DEFAULT true | |
| `subscribed_at` | timestamptz | |
| `unsubscribed_at` | timestamptz | |

**RLS:** Public INSERT. Own UPDATE (unsubscribe). Admin ALL.

---

## 51. cron_locks *(Migration 005)*

Distributed lock table for Celery cron jobs. Server-only access.

| Column | Type | Description |
|--------|------|-------------|
| `lock_name` | text PK | Job name (e.g. `tier_recalc`) |
| `locked_at` | timestamptz DEFAULT now() | When lock was acquired |
| `locked_until` | timestamptz NOT NULL | Lock TTL |
| `locked_by` | text DEFAULT '' | Worker hostname |

**RLS:** Enabled. No client policies. Only the service role (backend) can read/write. Prevents concurrent cron runs across multiple workers.

---

## Enum Types Reference

| Enum | Values |
|------|--------|
| `order_status` | `pending_payment, received, preparing, ready, dispatched, delivered, attempted, unclaimed, cancelled, refunded` |
| `payment_method` | `wallet, card, split, guest_card` |
| `batch_status` | `pending, assigned, in_progress, completed` |
| `window_status` | `scheduled, open, closed, dispatched, completed` |
| `user_role` | `student, kitchen, rider, admin, super_admin` |
| `hp_transaction_type` | `earn_order, earn_first_order, earn_squad_bonus, earn_referral, earn_event_checkin, earn_review, earn_streak, earn_birthday, earn_challenge, earn_admin_grant, spend_reward, spend_marketplace, spend_order_discount, expire, unlock, overflow_to_pending` |
| `wallet_tx_type` | `credit_bank_transfer, credit_card, credit_admin, debit_order, debit_marketplace, debit_refund, debit_withdrawal` |
| `notification_type` | `order_update, hp_earned, tier_upgrade, reward_available, challenge_complete, promo, system, admin_blast` |
| `notification_channel` | `in_app, push, email` |
| `reward_category` | `food, discount, event_ticket, service_voucher, giveaway_entry, exclusive_perk` |
| `challenge_type` | `order_streak, first_marketplace, review, referral_milestone, social_share, admin_custom, monthly_challenge` |
| `discount_type` | `percentage, flat` |
| `promo_scope` | `cart_wide, item_specific` |
| `listing_type` | `code, link, manual` |
| `code_status` | `available, assigned, redeemed, expired` |
| `catering_status` | `submitted, reviewing, quoted, accepted, declined, completed` |
| `review_rating` | `1, 2, 3, 4, 5` |
| `day_of_week` | `monday, tuesday, wednesday, thursday, friday, saturday, sunday` |
