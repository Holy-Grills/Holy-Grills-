-- =============================================================================
-- Holy Grills — Additive Schema: Enums, Indexes & Seed Data
-- Safe to run multiple times (fully idempotent).
-- Run in Supabase Dashboard → SQL Editor → paste → Run
-- =============================================================================

-- =============================================================================
-- SECTION 1: NEW ENUM VALUES (additive only)
-- =============================================================================

DO $$
BEGIN
  -- hp_transaction_type: add 'unlock' and 'overflow_to_pending'
  IF NOT EXISTS (
    SELECT 1 FROM pg_enum e JOIN pg_type t ON e.enumtypid = t.oid
    WHERE t.typname = 'hp_transaction_type' AND e.enumlabel = 'unlock'
  ) THEN
    ALTER TYPE public.hp_transaction_type ADD VALUE IF NOT EXISTS 'unlock';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_enum e JOIN pg_type t ON e.enumtypid = t.oid
    WHERE t.typname = 'hp_transaction_type' AND e.enumlabel = 'overflow_to_pending'
  ) THEN
    ALTER TYPE public.hp_transaction_type ADD VALUE IF NOT EXISTS 'overflow_to_pending';
  END IF;

  -- challenge_type: add 'monthly_challenge'
  IF NOT EXISTS (
    SELECT 1 FROM pg_enum e JOIN pg_type t ON e.enumtypid = t.oid
    WHERE t.typname = 'challenge_type' AND e.enumlabel = 'monthly_challenge'
  ) THEN
    ALTER TYPE public.challenge_type ADD VALUE IF NOT EXISTS 'monthly_challenge';
  END IF;
END$$;


-- =============================================================================
-- SECTION 2: NEW COLUMNS ON EXISTING TABLES (additive, with defaults)
-- =============================================================================

-- profiles table
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS pending_hp_balance    integer     NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS hp_overflow           integer     NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS hp_earned_120day      integer     NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS hp_earned_120day_updated_at timestamptz,
  ADD COLUMN IF NOT EXISTS monthly_hp_earned     integer     NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS last_monthly_reset_at timestamptz,
  ADD COLUMN IF NOT EXISTS tier_bonus_multiplier numeric(4,2) NOT NULL DEFAULT 1.0;

-- orders table
ALTER TABLE public.orders
  ADD COLUMN IF NOT EXISTS tier_bonus_hp         integer     NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS unlocked_pending_hp   integer     NOT NULL DEFAULT 0;

-- hp_transactions table
ALTER TABLE public.hp_transactions
  ADD COLUMN IF NOT EXISTS source_type           text,
  ADD COLUMN IF NOT EXISTS status                text        NOT NULL DEFAULT 'active',
  ADD COLUMN IF NOT EXISTS unlocked_from_pending_id uuid;


-- =============================================================================
-- SECTION 3: NEW TABLES (6 tables)
-- =============================================================================

-- 3a. pending_hp_transactions
CREATE TABLE IF NOT EXISTS public.pending_hp_transactions (
  id               uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id          uuid        NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  amount           integer     NOT NULL CHECK (amount > 0),
  source_type      text        NOT NULL,
  reference_id     uuid,
  reference_type   text,
  status           text        NOT NULL DEFAULT 'pending'
                               CHECK (status IN ('pending','unlocked','expired','overflow')),
  unlocked_amount  integer     NOT NULL DEFAULT 0,
  unlocked_at      timestamptz,
  expires_at       timestamptz,
  notes            text,
  created_at       timestamptz NOT NULL DEFAULT now()
);

-- 3b. hp_unlock_log
CREATE TABLE IF NOT EXISTS public.hp_unlock_log (
  id                        uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id                   uuid        NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  order_id                  uuid        NOT NULL REFERENCES public.orders(id),
  food_spend_amount         numeric(12,2) NOT NULL,
  hp_unlocked               integer     NOT NULL,
  hp_overflow_restored      integer     NOT NULL DEFAULT 0,
  pending_balance_before    integer     NOT NULL,
  pending_balance_after     integer     NOT NULL,
  active_balance_after      integer     NOT NULL,
  created_at                timestamptz NOT NULL DEFAULT now()
);

-- 3c. leaderboard_monthly
CREATE TABLE IF NOT EXISTS public.leaderboard_monthly (
  id           uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id      uuid        NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  period       text        NOT NULL,           -- e.g. '2025-05'
  hp_earned    integer     NOT NULL DEFAULT 0,
  rank         integer,
  prize_awarded text,
  computed_at  timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, period)
);

-- 3d. hall_of_fame
CREATE TABLE IF NOT EXISTS public.hall_of_fame (
  id                 uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id            uuid        NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  month              text        NOT NULL UNIQUE,  -- e.g. '2025-05'
  hp_earned          integer     NOT NULL,
  rank               integer     NOT NULL DEFAULT 1,
  full_name_snapshot text,
  prize_description  text,
  created_at         timestamptz NOT NULL DEFAULT now()
);

-- 3e. spin_win_entries
CREATE TABLE IF NOT EXISTS public.spin_win_entries (
  id           uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id      uuid        NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  month        text        NOT NULL,            -- e.g. '2025-05'
  rank         integer     NOT NULL CHECK (rank BETWEEN 1 AND 10),
  hp_earned    integer     NOT NULL,
  spin_used    boolean     NOT NULL DEFAULT false,
  spin_result  text,
  spun_at      timestamptz,
  created_at   timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, month)
);

-- 3f. hp_bundle_purchases
CREATE TABLE IF NOT EXISTS public.hp_bundle_purchases (
  id              uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  event_host_id   uuid        NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  hp_amount       integer     NOT NULL CHECK (hp_amount > 0),
  naira_paid      numeric(12,2) NOT NULL,
  price_per_hp    numeric(6,2) NOT NULL DEFAULT 5.00,
  payment_reference text,
  hp_tx_id        uuid        REFERENCES public.hp_transactions(id),
  created_at      timestamptz NOT NULL DEFAULT now()
);

-- 3g. flash_redemptions (supporting Section 9 — Flash Redemption Rules)
CREATE TABLE IF NOT EXISTS public.flash_redemptions (
  id                  uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  reward_id           uuid        NOT NULL REFERENCES public.rewards(id) ON DELETE CASCADE,
  discount_percentage numeric(5,2) NOT NULL DEFAULT 50.00,
  quantity_limit      integer     NOT NULL DEFAULT 5,
  window_starts_at    timestamptz NOT NULL,
  window_ends_at      timestamptz NOT NULL,
  is_active           boolean     NOT NULL DEFAULT true,
  created_by          uuid        REFERENCES public.profiles(id),
  created_at          timestamptz NOT NULL DEFAULT now(),
  UNIQUE (reward_id, window_starts_at)
);


-- =============================================================================
-- SECTION 4: CHECK CONSTRAINTS (additive — skipped if column exists)
-- =============================================================================

ALTER TABLE public.profiles
  DROP CONSTRAINT IF EXISTS profiles_pending_hp_balance_check,
  DROP CONSTRAINT IF EXISTS profiles_hp_earned_120day_check,
  DROP CONSTRAINT IF EXISTS profiles_monthly_hp_earned_check,
  DROP CONSTRAINT IF EXISTS profiles_hp_overflow_check;

ALTER TABLE public.profiles
  ADD CONSTRAINT profiles_pending_hp_balance_check
    CHECK (pending_hp_balance >= 0),
  ADD CONSTRAINT profiles_hp_earned_120day_check
    CHECK (hp_earned_120day >= 0),
  ADD CONSTRAINT profiles_monthly_hp_earned_check
    CHECK (monthly_hp_earned >= 0),
  ADD CONSTRAINT profiles_hp_overflow_check
    CHECK (hp_overflow >= 0);

ALTER TABLE public.orders
  DROP CONSTRAINT IF EXISTS orders_tier_bonus_hp_check;

ALTER TABLE public.orders
  ADD CONSTRAINT orders_tier_bonus_hp_check
    CHECK (tier_bonus_hp >= 0);


-- =============================================================================
-- SECTION 5: INDEXES (performance — all additive)
-- =============================================================================

-- profiles
CREATE INDEX IF NOT EXISTS idx_profiles_role
  ON public.profiles(role);
CREATE INDEX IF NOT EXISTS idx_profiles_referral_code
  ON public.profiles(referral_code);
CREATE INDEX IF NOT EXISTS idx_profiles_referred_by
  ON public.profiles(referred_by);
CREATE INDEX IF NOT EXISTS idx_profiles_monthly_hp_earned
  ON public.profiles(monthly_hp_earned DESC);
CREATE INDEX IF NOT EXISTS idx_profiles_hp_earned_120day
  ON public.profiles(hp_earned_120day DESC);
CREATE INDEX IF NOT EXISTS idx_profiles_is_active
  ON public.profiles(is_active) WHERE is_active = true;

-- orders
CREATE INDEX IF NOT EXISTS idx_orders_user_id
  ON public.orders(user_id);
CREATE INDEX IF NOT EXISTS idx_orders_status
  ON public.orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_delivery_window_id
  ON public.orders(delivery_window_id);
CREATE INDEX IF NOT EXISTS idx_orders_batch_id
  ON public.orders(batch_id) WHERE batch_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_orders_created_at
  ON public.orders(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_orders_user_status
  ON public.orders(user_id, status);
CREATE INDEX IF NOT EXISTS idx_orders_payment_reference
  ON public.orders(payment_reference) WHERE payment_reference IS NOT NULL;

-- hp_transactions
CREATE INDEX IF NOT EXISTS idx_hp_transactions_user_id
  ON public.hp_transactions(user_id);
CREATE INDEX IF NOT EXISTS idx_hp_transactions_type
  ON public.hp_transactions(type);
CREATE INDEX IF NOT EXISTS idx_hp_transactions_user_created
  ON public.hp_transactions(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_hp_transactions_source_type
  ON public.hp_transactions(source_type) WHERE source_type IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_hp_transactions_status
  ON public.hp_transactions(status);
CREATE INDEX IF NOT EXISTS idx_hp_transactions_reference_id
  ON public.hp_transactions(reference_id) WHERE reference_id IS NOT NULL;

-- wallet_transactions
CREATE INDEX IF NOT EXISTS idx_wallet_transactions_user_id
  ON public.wallet_transactions(user_id);
CREATE INDEX IF NOT EXISTS idx_wallet_transactions_wallet_id
  ON public.wallet_transactions(wallet_id);
CREATE INDEX IF NOT EXISTS idx_wallet_transactions_created_at
  ON public.wallet_transactions(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_wallet_transactions_payment_reference
  ON public.wallet_transactions(payment_reference) WHERE payment_reference IS NOT NULL;

-- notifications
CREATE INDEX IF NOT EXISTS idx_notifications_user_id
  ON public.notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_user_unread
  ON public.notifications(user_id, is_read) WHERE is_read = false;
CREATE INDEX IF NOT EXISTS idx_notifications_created_at
  ON public.notifications(created_at DESC);

-- orders items
CREATE INDEX IF NOT EXISTS idx_order_items_order_id
  ON public.order_items(order_id);

-- order_status_log
CREATE INDEX IF NOT EXISTS idx_order_status_log_order_id
  ON public.order_status_log(order_id);
CREATE INDEX IF NOT EXISTS idx_order_status_log_created_at
  ON public.order_status_log(created_at DESC);

-- referrals
CREATE INDEX IF NOT EXISTS idx_referrals_referrer_id
  ON public.referrals(referrer_id);
CREATE INDEX IF NOT EXISTS idx_referrals_referred_user_id
  ON public.referrals(referred_user_id);
CREATE INDEX IF NOT EXISTS idx_referrals_hp_awarded_at
  ON public.referrals(hp_awarded_at) WHERE hp_awarded_at IS NOT NULL;

-- user_tiers
CREATE INDEX IF NOT EXISTS idx_user_tiers_user_id
  ON public.user_tiers(user_id);
CREATE INDEX IF NOT EXISTS idx_user_tiers_current
  ON public.user_tiers(user_id, is_current) WHERE is_current = true;

-- events
CREATE INDEX IF NOT EXISTS idx_events_event_date
  ON public.events(event_date);
CREATE INDEX IF NOT EXISTS idx_events_is_active
  ON public.events(is_active) WHERE is_active = true;

-- event_checkins
CREATE INDEX IF NOT EXISTS idx_event_checkins_user_id
  ON public.event_checkins(user_id);
CREATE INDEX IF NOT EXISTS idx_event_checkins_event_id
  ON public.event_checkins(event_id);

-- challenges
CREATE INDEX IF NOT EXISTS idx_challenges_is_active
  ON public.challenges(is_active) WHERE is_active = true;
CREATE INDEX IF NOT EXISTS idx_challenge_completions_user_challenge
  ON public.challenge_completions(user_id, challenge_id);

-- marketplace
CREATE INDEX IF NOT EXISTS idx_marketplace_listings_is_active
  ON public.marketplace_listings(is_active) WHERE is_active = true;
CREATE INDEX IF NOT EXISTS idx_marketplace_codes_listing_status
  ON public.marketplace_codes(listing_id, status);
CREATE INDEX IF NOT EXISTS idx_marketplace_purchases_user_id
  ON public.marketplace_purchases(user_id);

-- reward_redemptions
CREATE INDEX IF NOT EXISTS idx_reward_redemptions_user_id
  ON public.reward_redemptions(user_id);
CREATE INDEX IF NOT EXISTS idx_reward_redemptions_reward_id
  ON public.reward_redemptions(reward_id);

-- admin_audit_log
CREATE INDEX IF NOT EXISTS idx_admin_audit_log_actor_id
  ON public.admin_audit_log(actor_id);
CREATE INDEX IF NOT EXISTS idx_admin_audit_log_created_at
  ON public.admin_audit_log(created_at DESC);

-- webhook_events
CREATE UNIQUE INDEX IF NOT EXISTS idx_webhook_events_idempotency_key
  ON public.webhook_events(idempotency_key);
CREATE INDEX IF NOT EXISTS idx_webhook_events_payment_reference
  ON public.webhook_events(payment_reference) WHERE payment_reference IS NOT NULL;

-- new tables
CREATE INDEX IF NOT EXISTS idx_pending_hp_transactions_user_id
  ON public.pending_hp_transactions(user_id);
CREATE INDEX IF NOT EXISTS idx_pending_hp_transactions_status
  ON public.pending_hp_transactions(user_id, status);

CREATE INDEX IF NOT EXISTS idx_hp_unlock_log_user_id
  ON public.hp_unlock_log(user_id);
CREATE INDEX IF NOT EXISTS idx_hp_unlock_log_order_id
  ON public.hp_unlock_log(order_id);

CREATE INDEX IF NOT EXISTS idx_leaderboard_monthly_period
  ON public.leaderboard_monthly(period, hp_earned DESC);
CREATE INDEX IF NOT EXISTS idx_leaderboard_monthly_user_period
  ON public.leaderboard_monthly(user_id, period);

CREATE INDEX IF NOT EXISTS idx_spin_win_entries_month
  ON public.spin_win_entries(month, rank);

CREATE INDEX IF NOT EXISTS idx_hp_bundle_purchases_event_host
  ON public.hp_bundle_purchases(event_host_id);

CREATE INDEX IF NOT EXISTS idx_flash_redemptions_reward_active
  ON public.flash_redemptions(reward_id, is_active) WHERE is_active = true;

-- promo_codes
CREATE INDEX IF NOT EXISTS idx_promo_codes_code
  ON public.promo_codes(code) WHERE is_active = true;

-- abandoned_carts
CREATE INDEX IF NOT EXISTS idx_abandoned_carts_user_id
  ON public.abandoned_carts(user_id);
CREATE INDEX IF NOT EXISTS idx_abandoned_carts_next_recovery
  ON public.abandoned_carts(next_recovery_at) WHERE is_recovered = false;

-- leaderboard_snapshots
CREATE INDEX IF NOT EXISTS idx_leaderboard_snapshots_period_rank
  ON public.leaderboard_snapshots(period, rank);
CREATE INDEX IF NOT EXISTS idx_leaderboard_snapshots_user_period
  ON public.leaderboard_snapshots(user_id, period);


-- =============================================================================
-- SECTION 6: SUPABASE RPCS — New functions (additive)
-- =============================================================================

-- earn_pending_hp: safely adds to pending pool, enforces ceiling
CREATE OR REPLACE FUNCTION public.earn_pending_hp(
  p_user_id      uuid,
  p_amount       integer,
  p_source_type  text
)
RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER
AS $$
DECLARE
  v_active        integer;
  v_pending       integer;
  v_overflow      integer;
  v_ceiling       integer;
  v_space         integer;
  v_to_pending    integer;
  v_to_overflow   integer;
BEGIN
  SELECT
    COALESCE(pending_hp_balance, 0),
    COALESCE(hp_overflow, 0)
  INTO v_pending, v_overflow
  FROM public.profiles WHERE id = p_user_id FOR UPDATE;

  -- active balance from transactions
  SELECT COALESCE(SUM(amount), 0) INTO v_active
  FROM public.hp_transactions
  WHERE user_id = p_user_id AND status = 'active';

  v_ceiling    := GREATEST(FLOOR(v_active * 0.35)::integer, 200);
  v_space      := GREATEST(0, v_ceiling - v_pending);
  v_to_pending := LEAST(p_amount, v_space);
  v_to_overflow := p_amount - v_to_pending;

  UPDATE public.profiles SET
    pending_hp_balance = v_pending + v_to_pending,
    hp_overflow        = v_overflow + v_to_overflow
  WHERE id = p_user_id;

  RETURN jsonb_build_object(
    'added_to_pending',  v_to_pending,
    'added_to_overflow', v_to_overflow,
    'ceiling',           v_ceiling
  );
END;
$$;

-- unlock_pending_hp: unlocks 100 HP per ₦1,000 food spend
CREATE OR REPLACE FUNCTION public.unlock_pending_hp(
  p_user_id         uuid,
  p_order_id        uuid,
  p_food_spend      numeric
)
RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER
AS $$
DECLARE
  v_to_unlock       integer;
  v_pending         integer;
  v_overflow        integer;
  v_actually        integer;
  v_active_after    integer;
  v_new_ceiling     integer;
  v_space           integer;
  v_restore         integer;
BEGIN
  v_to_unlock := FLOOR(p_food_spend / 1000 * 100)::integer;
  IF v_to_unlock <= 0 THEN
    RETURN jsonb_build_object('unlocked', 0, 'overflow_restored', 0);
  END IF;

  SELECT COALESCE(pending_hp_balance,0), COALESCE(hp_overflow,0)
  INTO v_pending, v_overflow
  FROM public.profiles WHERE id = p_user_id FOR UPDATE;

  v_actually := LEAST(v_to_unlock, v_pending);

  SELECT COALESCE(SUM(amount),0) INTO v_active_after
  FROM public.hp_transactions WHERE user_id = p_user_id AND status = 'active';
  v_active_after := v_active_after + v_actually;

  v_new_ceiling := GREATEST(FLOOR(v_active_after * 0.35)::integer, 200);
  v_space       := GREATEST(0, v_new_ceiling - (v_pending - v_actually));
  v_restore     := LEAST(v_overflow, v_space);

  UPDATE public.profiles SET
    pending_hp_balance = v_pending - v_actually + v_restore,
    hp_overflow        = v_overflow - v_restore
  WHERE id = p_user_id;

  INSERT INTO public.hp_unlock_log (
    user_id, order_id, food_spend_amount, hp_unlocked,
    hp_overflow_restored, pending_balance_before, pending_balance_after,
    active_balance_after
  ) VALUES (
    p_user_id, p_order_id, p_food_spend, v_actually,
    v_restore, v_pending, v_pending - v_actually + v_restore,
    v_active_after
  );

  RETURN jsonb_build_object('unlocked', v_actually, 'overflow_restored', v_restore);
END;
$$;

-- calculate_rolling_120day_hp: sum HP earned in last 120 days (active only)
CREATE OR REPLACE FUNCTION public.calculate_rolling_120day_hp(p_user_id uuid)
RETURNS integer
LANGUAGE sql STABLE SECURITY DEFINER
AS $$
  SELECT COALESCE(SUM(amount), 0)::integer
  FROM public.hp_transactions
  WHERE user_id = p_user_id
    AND status   = 'active'
    AND type     = 'earn'
    AND amount   > 0
    AND created_at >= now() - interval '120 days';
$$;

-- update_tier_and_bonus: recalculates tier from hp_earned_120day
CREATE OR REPLACE FUNCTION public.update_tier_and_bonus(p_user_id uuid)
RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER
AS $$
DECLARE
  v_earned    integer;
  v_tier      record;
  v_cur_tier  uuid;
BEGIN
  v_earned := public.calculate_rolling_120day_hp(p_user_id);

  UPDATE public.profiles SET
    hp_earned_120day             = v_earned,
    hp_earned_120day_updated_at  = now()
  WHERE id = p_user_id;

  SELECT id, name, slug, earn_multiplier, min_hp_threshold
  INTO v_tier
  FROM public.tiers
  WHERE min_hp_threshold <= v_earned
  ORDER BY min_hp_threshold DESC
  LIMIT 1;

  IF v_tier.id IS NULL THEN RETURN '{"changed":false}'::jsonb; END IF;

  SELECT tier_id INTO v_cur_tier FROM public.user_tiers
  WHERE user_id = p_user_id AND is_current = true;

  IF v_cur_tier = v_tier.id THEN RETURN '{"changed":false}'::jsonb; END IF;

  UPDATE public.user_tiers SET is_current = false WHERE user_id = p_user_id AND is_current = true;
  INSERT INTO public.user_tiers (user_id, tier_id, is_current, achieved_at)
  VALUES (p_user_id, v_tier.id, true, now());

  UPDATE public.profiles SET tier_bonus_multiplier = v_tier.earn_multiplier WHERE id = p_user_id;

  RETURN jsonb_build_object('changed', true, 'tier_id', v_tier.id, 'tier_slug', v_tier.slug);
END;
$$;

-- reset_monthly_leaderboard: archives top 10, resets monthly counters
CREATE OR REPLACE FUNCTION public.reset_monthly_leaderboard()
RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER
AS $$
DECLARE
  v_period  text := to_char(now() - interval '1 month', 'YYYY-MM');
  v_count   integer := 0;
  v_rec     record;
  v_rank    integer := 1;
BEGIN
  -- Archive top 10 to spin_win_entries
  FOR v_rec IN
    SELECT id, full_name, monthly_hp_earned
    FROM public.profiles
    WHERE monthly_hp_earned > 0
    ORDER BY monthly_hp_earned DESC
    LIMIT 10
  LOOP
    INSERT INTO public.spin_win_entries (user_id, month, rank, hp_earned)
    VALUES (v_rec.id, v_period, v_rank, v_rec.monthly_hp_earned)
    ON CONFLICT (user_id, month) DO NOTHING;

    IF v_rank = 1 THEN
      INSERT INTO public.hall_of_fame (user_id, month, hp_earned, full_name_snapshot)
      VALUES (v_rec.id, v_period, v_rec.monthly_hp_earned, v_rec.full_name)
      ON CONFLICT (month) DO NOTHING;
    END IF;

    -- Upsert leaderboard_monthly
    INSERT INTO public.leaderboard_monthly (user_id, period, hp_earned, rank)
    VALUES (v_rec.id, v_period, v_rec.monthly_hp_earned, v_rank)
    ON CONFLICT (user_id, period) DO UPDATE
      SET hp_earned = EXCLUDED.hp_earned, rank = EXCLUDED.rank;

    v_rank := v_rank + 1;
  END LOOP;

  -- Reset monthly_hp_earned for all users
  UPDATE public.profiles SET monthly_hp_earned = 0, last_monthly_reset_at = now();
  GET DIAGNOSTICS v_count = ROW_COUNT;

  RETURN jsonb_build_object('reset_count', v_count, 'period', v_period);
END;
$$;

-- calculate_breakage: returns HP eligible for expiry (20-30% of inactive balance)
CREATE OR REPLACE FUNCTION public.calculate_breakage(
  p_user_id        uuid,
  p_inactivity_days integer DEFAULT 90
)
RETURNS jsonb
LANGUAGE plpgsql STABLE SECURITY DEFINER
AS $$
DECLARE
  v_last_activity timestamptz;
  v_active_hp     integer;
  v_breakage      integer;
BEGIN
  SELECT MAX(created_at) INTO v_last_activity
  FROM public.hp_transactions WHERE user_id = p_user_id;

  IF v_last_activity IS NULL OR v_last_activity > now() - (p_inactivity_days || ' days')::interval THEN
    RETURN jsonb_build_object('eligible', false, 'reason', 'recent_activity');
  END IF;

  SELECT COALESCE(SUM(amount), 0)::integer INTO v_active_hp
  FROM public.hp_transactions WHERE user_id = p_user_id AND status = 'active';

  IF v_active_hp <= 0 THEN
    RETURN jsonb_build_object('eligible', false, 'reason', 'no_balance');
  END IF;

  v_breakage := FLOOR(v_active_hp * 0.25)::integer;
  RETURN jsonb_build_object(
    'eligible',           true,
    'active_hp',          v_active_hp,
    'breakage_amount',    v_breakage,
    'inactivity_days',    p_inactivity_days,
    'last_activity',      v_last_activity
  );
END;
$$;

-- process_flash_redeem: 50% HP discount, first N users, 24h window
CREATE OR REPLACE FUNCTION public.process_flash_redeem(
  p_reward_id uuid,
  p_user_id   uuid
)
RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER
AS $$
DECLARE
  v_flash          record;
  v_reward         record;
  v_count          integer;
  v_discounted     integer;
  v_active_hp      integer;
  v_redemption_id  uuid;
BEGIN
  SELECT * INTO v_flash FROM public.flash_redemptions
  WHERE reward_id = p_reward_id AND is_active = true
    AND window_starts_at <= now() AND window_ends_at >= now()
  LIMIT 1;

  IF NOT FOUND THEN RAISE EXCEPTION 'No active flash sale'; END IF;

  SELECT COUNT(*) INTO v_count FROM public.reward_redemptions
  WHERE reward_id = p_reward_id AND created_at >= v_flash.window_starts_at;
  IF v_count >= v_flash.quantity_limit THEN RAISE EXCEPTION 'Flash sale sold out'; END IF;

  SELECT hp_cost INTO v_reward FROM public.rewards WHERE id = p_reward_id;
  v_discounted := CEIL(v_reward.hp_cost * (1 - v_flash.discount_percentage/100))::integer;

  SELECT COALESCE(SUM(amount),0)::integer INTO v_active_hp
  FROM public.hp_transactions WHERE user_id = p_user_id AND status = 'active';
  IF v_active_hp < v_discounted THEN RAISE EXCEPTION 'Insufficient HP'; END IF;

  INSERT INTO public.reward_redemptions (user_id, reward_id, hp_cost_snapshot, is_fulfilled)
  VALUES (p_user_id, p_reward_id, v_discounted, false)
  RETURNING id INTO v_redemption_id;

  INSERT INTO public.hp_transactions (user_id, amount, type, reference_id, reference_type, status, notes)
  VALUES (p_user_id, -v_discounted, 'spend', v_redemption_id, 'flash_reward_redemption', 'active',
          'Flash deal — 50% off');

  RETURN jsonb_build_object('redemption_id', v_redemption_id, 'hp_spent', v_discounted);
END;
$$;

-- process_hp_bundle_purchase: event hosts buy HP at ₦5/HP → pending pool
CREATE OR REPLACE FUNCTION public.process_hp_bundle_purchase(
  p_event_host_id    uuid,
  p_hp_amount        integer,
  p_naira_paid       numeric,
  p_payment_reference text DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER
AS $$
DECLARE
  v_expected numeric;
  v_tx_id    uuid;
  v_pending  jsonb;
BEGIN
  v_expected := p_hp_amount * 5.0;
  IF ABS(p_naira_paid - v_expected) > 1 THEN
    RAISE EXCEPTION 'Payment mismatch: received % expected %', p_naira_paid, v_expected;
  END IF;

  INSERT INTO public.hp_transactions
    (user_id, amount, type, reference_type, source_type, status, notes)
  VALUES
    (p_event_host_id, p_hp_amount, 'earn', 'bundle_purchase', 'bundle_purchase', 'pending',
     format('%s HP bundle at ₦5/HP (₦%s total)', p_hp_amount, p_naira_paid))
  RETURNING id INTO v_tx_id;

  INSERT INTO public.hp_bundle_purchases
    (event_host_id, hp_amount, naira_paid, price_per_hp, payment_reference, hp_tx_id)
  VALUES
    (p_event_host_id, p_hp_amount, p_naira_paid, 5.00, p_payment_reference, v_tx_id);

  v_pending := public.earn_pending_hp(p_event_host_id, p_hp_amount, 'bundle_purchase');
  RETURN v_pending || jsonb_build_object('tx_id', v_tx_id);
END;
$$;


-- =============================================================================
-- SECTION 7: SEED DATA
-- =============================================================================

-- Tiers
INSERT INTO public.tiers (id, name, slug, min_hp_threshold, sort_order, earn_multiplier, badge_color_hex, perks_description)
VALUES
  ('00000000-0000-0000-0000-000000000001', 'Ember', 'ember', 0,     1, 1.00, '#F97316',
   'Base tier. Earn 1 HP per ₦10. Access to standard rewards.'),
  ('00000000-0000-0000-0000-000000000002', 'Flame', 'flame', 2500,  2, 1.08, '#EF4444',
   '8% HP bonus on food orders. Priority queue. Flame-exclusive rewards.'),
  ('00000000-0000-0000-0000-000000000003', 'Blaze', 'blaze', 7500,  3, 1.15, '#7C3AED',
   '15% HP bonus. Early access to new menu items. Free delivery 2×/month.'),
  ('00000000-0000-0000-0000-000000000004', 'Holy',  'holy',  20000, 4, 1.25, '#F59E0B',
   '25% HP bonus. VIP table reservations. Monthly Holy Grail box. Hall of Fame eligibility.')
ON CONFLICT (id) DO UPDATE SET
  name              = EXCLUDED.name,
  earn_multiplier   = EXCLUDED.earn_multiplier,
  badge_color_hex   = EXCLUDED.badge_color_hex,
  perks_description = EXCLUDED.perks_description;

-- Operating Hours (Mon–Sat 10:00–21:00, Sunday closed)
INSERT INTO public.operating_hours (day, open_time, close_time, is_closed)
VALUES
  ('monday',    '10:00', '21:00', false),
  ('tuesday',   '10:00', '21:00', false),
  ('wednesday', '10:00', '21:00', false),
  ('thursday',  '10:00', '21:00', false),
  ('friday',    '10:00', '22:00', false),
  ('saturday',  '10:00', '22:00', false),
  ('sunday',    '12:00', '20:00', false)
ON CONFLICT DO NOTHING;

-- Menu Categories
INSERT INTO public.menu_categories (id, name, slug, description, sort_order, is_active)
VALUES
  ('10000000-0000-0000-0000-000000000001', 'Grills',       'grills',       'Charcoal-grilled meats & proteins',        1, true),
  ('10000000-0000-0000-0000-000000000002', 'Rice Bowls',   'rice-bowls',   'Jollof, fried rice, coconut rice combos',  2, true),
  ('10000000-0000-0000-0000-000000000003', 'Small Chops',  'small-chops',  'Puff puff, samosa, spring rolls & more',   3, true),
  ('10000000-0000-0000-0000-000000000004', 'Proteins',     'proteins',     'Chicken, fish, beef, turkey add-ons',      4, true),
  ('10000000-0000-0000-0000-000000000005', 'Drinks',       'drinks',       'Cold drinks, water, zobo, kunu',           5, true),
  ('10000000-0000-0000-0000-000000000006', 'Sides',        'sides',        'Coleslaw, plantain, moi moi, salads',      6, true),
  ('10000000-0000-0000-0000-000000000007', 'Combos',       'combos',       'Full meal deals — protein + carb + drink', 7, true)
ON CONFLICT (id) DO NOTHING;

-- Menu Items
INSERT INTO public.menu_items (id, name, slug, category_id, price, hp_earn_value, is_available, is_archived, description, dietary_tags)
VALUES
  ('20000000-0000-0000-0000-000000000001', 'Holy Grilled Chicken', 'holy-grilled-chicken',
   '10000000-0000-0000-0000-000000000001', 3500, 35, true, false,
   'Full chicken, charcoal-grilled, seasoned Holy Grills style', ARRAY['halal']),
  ('20000000-0000-0000-0000-000000000002', 'Suya Stick (3 pcs)', 'suya-stick-3',
   '10000000-0000-0000-0000-000000000001', 1500, 15, true, false,
   'Spiced beef suya on skewers with onions & tomatoes', ARRAY['halal','spicy']),
  ('20000000-0000-0000-0000-000000000003', 'Jollof Rice + Chicken', 'jollof-rice-chicken',
   '10000000-0000-0000-0000-000000000002', 2500, 25, true, false,
   'Party jollof rice with 1 full chicken quarter', ARRAY['halal']),
  ('20000000-0000-0000-0000-000000000004', 'Fried Rice + Fish', 'fried-rice-fish',
   '10000000-0000-0000-0000-000000000002', 2200, 22, true, false,
   'Seasoned fried rice with grilled tilapia', ARRAY['halal']),
  ('20000000-0000-0000-0000-000000000005', 'Puff Puff (10 pcs)', 'puff-puff-10',
   '10000000-0000-0000-0000-000000000003', 800,  8,  true, false,
   'Soft, golden deep-fried dough balls', ARRAY['vegetarian']),
  ('20000000-0000-0000-0000-000000000006', 'Spring Rolls (5 pcs)', 'spring-rolls-5',
   '10000000-0000-0000-0000-000000000003', 1200, 12, true, false,
   'Crispy vegetable spring rolls, served with chilli sauce', ARRAY['vegetarian']),
  ('20000000-0000-0000-0000-000000000007', 'Chicken Quarter (Grilled)', 'chicken-quarter-grilled',
   '10000000-0000-0000-0000-000000000004', 1800, 18, true, false,
   'Bone-in chicken quarter, grilled over charcoal', ARRAY['halal']),
  ('20000000-0000-0000-0000-000000000008', 'Zobo Drink (50cl)', 'zobo-50cl',
   '10000000-0000-0000-0000-000000000005', 400,  4,  true, false,
   'Chilled hibiscus drink, lightly sweetened', ARRAY['vegan']),
  ('20000000-0000-0000-0000-000000000009', 'Bottled Water (50cl)', 'water-50cl',
   '10000000-0000-0000-0000-000000000005', 200,  2,  true, false,
   'Chilled bottled water', ARRAY['vegan']),
  ('20000000-0000-0000-0000-000000000010', 'Fried Plantain', 'fried-plantain',
   '10000000-0000-0000-0000-000000000006', 600,  6,  true, false,
   'Sweet ripe plantain, deep fried to golden perfection', ARRAY['vegan']),
  ('20000000-0000-0000-0000-000000000011', 'Holy Combo (Chicken+Rice+Drink)', 'holy-combo',
   '10000000-0000-0000-0000-000000000007', 3800, 40, true, false,
   'Grilled chicken quarter + jollof rice + zobo. Best value on campus!', ARRAY['halal']),
  ('20000000-0000-0000-0000-000000000012', 'Student Combo (Suya+Rice)', 'student-combo',
   '10000000-0000-0000-0000-000000000007', 2000, 20, true, false,
   'Suya sticks + jollof rice — perfect for a quick campus meal', ARRAY['halal'])
ON CONFLICT (id) DO NOTHING;

-- Storefront Sections (homepage CMS)
INSERT INTO public.storefront_sections (type, title, subtitle, body, is_active, sort_order)
VALUES
  ('hero',      'Holy Grills FUTA',
                'Campus Food. Real Rewards.',
                'Order your favourite grills and earn HP — Holy Points — with every bite. Level up from Ember to Holy tier.',
                true, 1),
  ('hp_explainer', 'What Are Holy Points?',
                   'Earn. Unlock. Redeem.',
                   'Every ₦10 you spend on food earns you 1 HP. Refer friends, attend events, and leave reviews to build your pending pool. Order food to unlock it all.',
                   true, 2),
  ('tiers',     'The Four Tiers',
                'Ember → Flame → Blaze → Holy',
                'Your tier is based on HP earned in the last 120 days. Higher tiers earn bigger bonuses on every order.',
                true, 3),
  ('marketplace', 'Holy Grills Marketplace',
                  'Spend HP on partner deals',
                  'From laundry discounts to data bundles — use your HP or pay with your wallet for exclusive campus deals.',
                  true, 4),
  ('referral',  'Refer & Earn',
                '75 HP for every friend who orders',
                'Share your referral code. When your friend places their first order, you both earn HP. Milestone bonuses at 5 and 10 referrals.',
                true, 5)
ON CONFLICT DO NOTHING;

-- Challenges (sample active challenges)
INSERT INTO public.challenges (title, description, type, hp_reward, max_completions_per_user, starts_at, ends_at, is_active, criteria)
VALUES
  ('First Order Challenge', 'Place your very first order on Holy Grills', 'order_milestone', 50, 1,
   now(), now() + interval '1 year', true, '{"order_count": 1}'::jsonb),
  ('Weekly Warrior', 'Order at least 3 times this week', 'weekly_streak', 75, 4,
   now(), now() + interval '1 year', true, '{"orders_per_week": 3}'::jsonb),
  ('Social Star', 'Share your Holy Grills order on social media and tag us', 'social_share', 25, 1,
   now(), now() + interval '6 months', true, '{"platform": "instagram"}'::jsonb),
  ('Review Hero', 'Leave a detailed review of 3 orders', 'review', 60, 1,
   now(), now() + interval '1 year', true, '{"review_count": 3}'::jsonb),
  ('May Monthly Challenge', 'Earn 500 HP in the month of May 2026', 'monthly_challenge', 100, 1,
   '2026-05-01'::timestamptz, '2026-05-31 23:59:59'::timestamptz, true, '{"target_monthly_hp": 500}'::jsonb)
ON CONFLICT DO NOTHING;

-- Sample Rewards
INSERT INTO public.rewards (name, slug, description, category, hp_cost, quantity_available, quantity_redeemed, is_active, min_tier_id, image_url, terms)
VALUES
  ('Free Puff Puff (10 pcs)', 'free-puff-puff', 'Redeem for a free portion of our famous puff puff',
   'food', 150, 100, 0, true, NULL, NULL, 'Valid for 7 days from redemption. One per order.'),
  ('Free Zobo Drink', 'free-zobo', 'A chilled zobo on us',
   'food', 80, 200, 0, true, NULL, NULL, 'Valid for 7 days. Not combinable with other offers.'),
  ('₦500 Wallet Credit', 'wallet-credit-500', '₦500 added to your Holy Grills wallet',
   'marketplace', 3200, 50, 0, true, '00000000-0000-0000-0000-000000000002', NULL,
   'Flame tier and above only. Credited within 24 hours.'),
  ('Free Holy Combo Meal', 'free-holy-combo', 'Our best-selling Holy Combo — completely free',
   'food', 600, 30, 0, true, '00000000-0000-0000-0000-000000000003', NULL,
   'Blaze tier and above. Valid for 14 days.'),
  ('Holy Grills Branded T-Shirt', 'hg-tshirt', 'Limited edition Holy Grills merch',
   'merch', 2500, 20, 0, true, '00000000-0000-0000-0000-000000000002', NULL,
   'Flame tier and above. Sizing subject to availability. Allow 5–7 days delivery.')
ON CONFLICT DO NOTHING;

-- Promo Codes (sample)
INSERT INTO public.promo_codes (code, discount_type, discount_value, scope, min_order_value, max_discount_cap, max_uses, max_uses_per_user, valid_from, valid_until, is_active, used_count)
VALUES
  ('WELCOME10',  'percentage', 10, 'cart', 1000,  500,  500, 1, now(), now() + interval '1 year', true, 0),
  ('GRILLS500',  'flat',       500,'cart', 3000,  500,  100, 1, now(), now() + interval '3 months', true, 0),
  ('FUTA2026',   'percentage', 15, 'cart', 2000,  1000, 200, 2, now(), now() + interval '6 months', true, 0),
  ('FIRSTORDER', 'percentage', 20, 'cart', 1000,  800,  1000,1, now(), now() + interval '1 year', true, 0)
ON CONFLICT DO NOTHING;


-- =============================================================================
-- DONE — run SELECT * FROM public.tiers; to verify
-- =============================================================================
