# Holy Grills — Frontend Integration Guide (v2)

> **Last updated:** May 2026
> **Live DB:** Supabase `xqglpwcfofkioqdjywvd` — migrations 001–005 applied
> **Backend:** Flask 3 (port 5000) + FastAPI 0.136 (port 8000, identical endpoints)
> **Swagger UI:** `GET /api/docs` (FastAPI) · FastAPI schema at `/api/openapi.json`
> **Auth:** JWT Bearer tokens — include in every authenticated request

---

## Base URL & Auth

All endpoints are prefixed `/api`. Every authenticated call needs:

```http
Authorization: Bearer <jwt_token>
Content-Type: application/json
```

The JWT is returned by `POST /api/auth/login` and `POST /api/auth/register`. Tokens do not expire in dev; use Supabase JWT secret for validation.

---

## Order Status Machine (Live DB Enum Values)

> **Important:** The `orders.status` field is a PostgreSQL enum. Use these exact strings — any other value will be rejected with a 400.

```
pending_payment → received → preparing → ready → dispatched → delivered
                                                              → attempted → unclaimed
Any pre-delivery state → cancelled
delivered / cancelled → (terminal, no further transitions)
```

**Status timestamps** are auto-stamped by DB trigger:
`received_at`, `preparing_at`, `ready_at`, `dispatched_at`, `delivered_at`, `attempted_at`, `unclaimed_at`, `cancelled_at`

---

## 1. Authentication

### Register
```http
POST /api/auth/register
{
  "email": "user@example.com",
  "password": "min8chars",
  "full_name": "Ada Okafor",
  "referral_code": "HG-XYZ123"   // optional — referrer's code
}
→ 201 { "token": "...", "user": { "id", "role", "referral_code", ... } }
```

### Login
```http
POST /api/auth/login
{ "email": "...", "password": "..." }
→ 200 { "token": "...", "user": { "id", "role", ... } }
```

### Get Profile
```http
GET /api/auth/profile          // requires auth
→ 200 { "id", "full_name", "email", "role", "tier", "referral_code",
         "pending_hp_balance", "hp_overflow", "monthly_hp_earned", ... }
```

### Update Profile
```http
PATCH /api/auth/profile
{ "full_name": "Ada Okafor-Nwosu", "phone": "+2348012345678" }
→ 200 { ...updated profile }
```

---

## 2. Menu

### List Categories
```http
GET /api/menu/categories
→ 200 [ { "id", "name", "slug", "sort_order", "image_url", "is_active" }, ... ]
```

### List Items
```http
GET /api/menu/items?category_id=<uuid>&available=true
→ 200 [
    {
      "id", "name", "description", "price",
      "daily_limit": 50,          // null = unlimited
      "daily_remaining": 47,      // how many left today
      "is_sold_out": false,       // true if daily_limit reached OR kitchen at capacity
      "dietary_tags": ["halal"],
      "variation_groups": [
        {
          "id", "name": "Choose your side",
          "is_required": true, "min_selections": 1, "max_selections": 1,
          "options": [
            { "id", "name": "Coleslaw", "price_delta": 0, "is_available": true },
            { "id", "name": "Plantain", "price_delta": 200, "is_available": true }
          ]
        }
      ]
    }
  ]
```

> **is_sold_out logic:** True if `daily_limit` is set and `daily_remaining == 0`, OR if kitchen is at daily order capacity. When `is_sold_out = true`, the Add to Cart button should be disabled.

### Get Single Item
```http
GET /api/menu/items/<item_id>
→ 200 { ...same as above with full variation_groups }
```

### Add-Ons (standalone extras for any order)
```http
GET /api/menu/addons
→ 200 [
    { "id", "name": "Extra Sauce", "description", "price": 200, "sort_order" },
    { "id", "name": "Bottled Water", "price": 300, ... }
  ]
```

> **Add-on vs Variation:** Variations are tied to a specific menu item (side choice). Add-ons are free-standing extras appended to any order at any quantity.

### Kitchen Capacity
```http
GET /api/menu/kitchen-capacity
→ 200 {
    "daily_order_capacity": 150,
    "orders_today": 42,
    "is_at_capacity": false
  }
```

When `is_at_capacity = true`, all menu items will have `is_sold_out: true` and the order CTA should be hidden/disabled.

---

## 3. Orders

### Create Order (v2 Payload)
```http
POST /api/orders
{
  "items": [
    {
      "menu_item_id": "uuid",
      "quantity": 1,
      "selected_variations": [
        { "option_id": "uuid" }       // one per required variation group
      ]
    }
  ],
  "addons": [
    { "addon_id": "uuid", "quantity": 2 }
  ],
  "payment_method": "wallet",         // "wallet" | "card" | "split" | "guest_card"
  "hp_points_to_redeem": 0,           // optional — active HP to use as discount
  "promo_code": "WELCOME10",          // optional
  "delivery_window_id": "uuid",
  "delivery_address": {
    "address_line": "Block C, Unilag",
    "landmark": "Near the Library",
    "zone": "Unilag Main"
  },
  "notes": "Extra spicy",
  // Guest fields (only if not authenticated):
  "guest_name": "John Doe",
  "guest_phone": "+2348012345678",
  "guest_email": "john@example.com"
}
→ 201 {
    "order_id": "uuid",
    "status": "pending_payment",
    "total": 3500.00,
    "payment_reference": "HG-REF-...",
    "claim_token": "uuid"            // only for guest orders
  }
```

**Important field names (live DB):**

| Frontend sends | Stored as in DB |
|----------------|----------------|
| `payment_method: "wallet"` | `payment_method` enum |
| HP discount | `hp_discount`, `hp_points_used` |
| Wallet portion | `wallet_amount_used` |
| Card portion | `card_amount_used` |
| Promo discount | `promo_discount` |
| Address | `delivery_address_snapshot` (jsonb) |

> **Note:** Orders can only be created via this endpoint. Direct Supabase inserts are blocked at the DB level (RLS policy removed by Migration 005).

### List My Orders
```http
GET /api/orders?limit=20&offset=0
→ 200 [ { "id", "status", "total", "created_at", "items": [...] }, ... ]
```

### Get Order Detail
```http
GET /api/orders/<order_id>
→ 200 {
    "id", "status", "total", "subtotal", "delivery_fee",
    "promo_discount", "hp_discount",
    "wallet_amount_used", "card_amount_used",
    "hp_points_used", "hp_earned",
    "delivery_address_snapshot": { "address_line", "landmark", "zone" },
    "items": [
      {
        "id", "item_name", "unit_price", "quantity", "subtotal",
        "selected_variations": [{"option_id", "name", "price_delta"}],
        "is_addon": false
      }
    ],
    "created_at", "received_at", "delivered_at", ...
  }
```

### Submit Order Review
```http
POST /api/orders/<order_id>/review
{ "rating": "5", "comment": "Amazing food!" }
→ 201 { "review_id": "uuid", "hp_pending_awarded": 20 }
```

Earns 20 pending HP (once per calendar month). Rating must be `"1"` through `"5"` (strings).

> **Note:** Reviews are immutable after submission — no UPDATE or DELETE allowed (enforced by DB RLS).

### Claim Guest Order
```http
POST /api/orders/claim
{ "claim_token": "uuid" }    // requires auth
→ 200 { "order_id": "uuid" }
```

---

## 4. HP (Holy Points)

### Get Balance
```http
GET /api/hp/balance            // requires auth
→ 200 {
    "active": 1250,            // spendable HP
    "pending": 75,             // locked, unlocks via food orders
    "overflow": 0,             // vaulted (pending pool was full)
    "total_visible": 1325,
    "monthly_hp_earned": 320,
    "tier": {
      "name": "Flame", "slug": "flame",
      "earn_multiplier": 1.08,
      "badge_color_hex": "#FF6B35"
    }
  }
```

### Transaction History
```http
GET /api/hp/transactions?limit=50&offset=0&type=earn
→ 200 [ { "id", "amount", "type", "source_type", "notes", "status", "created_at" }, ... ]
```

### List Tiers
```http
GET /api/hp/tiers
→ 200 [
    { "name": "Ember", "slug": "ember", "min_hp_threshold": 0, "earn_multiplier": 1.00 },
    { "name": "Flame", "slug": "flame", "min_hp_threshold": 2500, "earn_multiplier": 1.08 },
    { "name": "Blaze", "slug": "blaze", "min_hp_threshold": 7500, "earn_multiplier": 1.15 },
    { "name": "Holy",  "slug": "holy",  "min_hp_threshold": 20000, "earn_multiplier": 1.25 }
  ]
```

### HP Economy — How It Works

**Earning Active HP:**
- 1 HP per ₦10 food spend, multiplied by tier bonus
- Welcome bonus: 50 HP on first delivered order
- Birthday: 150 HP on birthday (if date_of_birth set in profile)
- Wallet top-up ≥ ₦3,000: 50 HP

**Earning Pending HP (locked until food spend):**
- Review: 20 pending HP (once per calendar month)
- Referral: 75 pending HP per completed referral (no monthly cap)
- Event check-in: varies per event
- Challenges: varies per challenge

**Unlocking Pending HP:**
- Every ₦1,000 food spend unlocks 100 pending HP → active
- `pending_balance × 35% OR 200 HP floor` can unlock per order

**Spending HP:**
- HP discount on orders: use `hp_points_to_redeem` field
- Rewards store: `POST /api/rewards/<id>/redeem`
- Marketplace: `POST /api/marketplace/listings/<id>/purchase`

---

## 5. Wallet

### Get Balance
```http
GET /api/wallet/balance        // requires auth
→ 200 { "balance": 5000.00, "currency": "NGN", "virtual_account_number": "..." }
```

### Top Up
```http
POST /api/wallet/topup
{ "amount": 3000, "payment_reference": "PAY-REF-..." }
→ 201 { "new_balance": 8000.00 }
```

### Transaction History
```http
GET /api/wallet/transactions?limit=20
→ 200 [ { "id", "amount", "type", "balance_after", "notes", "created_at" }, ... ]
```

---

## 6. Referrals

### Get My Referral Info
```http
GET /api/referrals             // requires auth
→ 200 {
    "referral_code": "HG-ABC123",
    "referral_link": "https://holygrill.app?ref=HG-ABC123",
    "total_referrals": 7,
    "completed_referrals": 5
  }
```

### Complete a Referral
```http
POST /api/referrals/complete
{ "referred_user_id": "uuid" }
→ 201 { "hp_awarded": 75, "total_completed": 6 }
```

**No monthly cap.** Each completed referral earns 75 pending HP regardless of how many referrals have been made this month.

### Referral Milestones
```http
GET /api/referrals/milestones
→ 200 {
    "milestones": [
      { "at": 5,  "hp": 150, "badge": "super_referrer_5" },
      { "at": 10, "hp": 400, "badge": "super_referrer_10" },
      { "at": 20, "hp": 750, "badge": "super_referrer_20" }
    ]
  }
```

---

## 7. Rewards Store

### List Rewards
```http
GET /api/rewards
→ 200 [ { "id", "name", "description", "hp_cost", "category", "quantity_available", "is_active" }, ... ]
```

### Redeem Reward
```http
POST /api/rewards/<reward_id>/redeem
{ }
→ 201 { "redemption_id": "uuid", "hp_spent": 500, "status": "pending" }
```

Returns 400 if insufficient active HP or reward out of stock. Returns 400 if tier requirement not met.

### Flash Rewards
```http
GET /api/rewards/flash
→ 200 [ { "id", "name", "hp_cost", "expires_at" }, ... ]
```

---

## 8. Marketplace

### List Listings
```http
GET /api/marketplace/listings
→ 200 [ { "id", "name", "type", "hp_price", "is_active", "is_out_of_stock", "vendor_name" }, ... ]
```

### Purchase Listing
```http
POST /api/marketplace/listings/<listing_id>/purchase
{ }
→ 201 { "purchase_id": "uuid", "code": "VENDOR-CODE-123", "hp_spent": 500 }
```

Code is returned immediately for `type: "code"` listings. Returns 400 if out of stock or insufficient HP.

### Request to List
```http
POST /api/marketplace/vendor-request
{ "vendor_name": "Bolu's Bakes", "contact_email": "bolu@example.com", "description": "..." }
→ 201 { "message": "Request submitted" }
```

---

## 9. Leaderboard

```http
GET /api/leaderboard?period=monthly&limit=10
→ 200 {
    "period": "monthly",
    "entries": [
      { "rank": 1, "full_name": "Ada O.", "monthly_hp": 1450, "tier": "Holy" },
      ...
    ],
    "my_rank": 12,
    "my_hp": 320
  }
```

---

## 10. Events

### List Active Events
```http
GET /api/events
→ 200 [ { "id", "title", "slug", "event_date", "venue", "hp_earn", "is_active" }, ... ]
```

### QR Check-in
```http
POST /api/events/checkin
{ "event_id": "uuid", "qr_token": "TOKEN-FROM-QR" }
→ 201 { "hp_awarded": 50, "checkin_id": "uuid" }
→ 400 { "error": "already_checked_in" | "invalid_qr_token" | "qr_expired" }
```

---

## 11. Challenges

```http
GET /api/challenges
→ 200 [ { "id", "title", "type", "hp_reward", "starts_at", "ends_at", "is_active" }, ... ]

GET /api/challenges/<id>
→ 200 { ...detail + "my_completions": 0, "max_completions_per_user": 1 }
```

---

## 12. Notifications

```http
GET /api/notifications?limit=20&unread_only=true
→ 200 [ { "id", "type", "title", "body", "is_read", "created_at" }, ... ]

PATCH /api/notifications/<id>/read
{ }
→ 200 { "is_read": true }
```

---

## 13. Delivery Windows

```http
GET /api/storefront/delivery-windows
→ 200 [ { "id", "label", "opens_at", "closes_at", "status" }, ... ]
```

Only return windows with `status = "open"` to the customer.

---

## 14. Storefront / Operating Hours

```http
GET /api/storefront/operating-hours
→ 200 [
    { "day": "monday", "open_time": "10:00:00", "close_time": "20:00:00", "is_closed": false },
    ...
  ]

GET /api/storefront/sections
→ 200 [ { "id", "title", "section_type", "content", "sort_order" }, ... ]
```

---

## 15. Catering Requests

```http
POST /api/events/catering-request
{
  "organizer_name": "Tunde Bakare",
  "organizer_email": "tunde@school.edu.ng",
  "event_name": "Freshers Week Dinner",
  "event_date": "2026-09-15",
  "venue": "Sports Complex Hall",
  "expected_attendance": 200,
  "budget_range": "₦150k–₦200k",
  "catering_notes": "Mix of jollof and pasta stations",
  "hp_promo_optin": true
}
→ 201 { "message": "Catering request submitted" }
```

---

## Error Responses

All errors follow this format:
```json
{ "error": "human readable message" }
```

| Status | When |
|--------|------|
| 400 | Validation error, business rule violation (insufficient HP, sold out, etc.) |
| 401 | Missing or invalid Authorization header |
| 403 | Authenticated but wrong role for endpoint |
| 404 | Resource not found |
| 409 | Conflict (duplicate claim, already checked in, etc.) |
| 422 | FastAPI request body validation error (Pydantic) |
| 500 | Unexpected server error |

---

## HP Points Redemption at Checkout

```http
POST /api/orders
{
  "items": [...],
  "payment_method": "split",
  "hp_points_to_redeem": 200,    // converts to Naira at 1 HP = ₦1
  ...
}
```

The backend validates:
1. `hp_points_to_redeem ≤ user.active_hp`
2. HP discount cannot exceed 50% of subtotal (configurable)
3. Remaining balance paid via wallet/card

The response will show `hp_discount` (Naira value) and `hp_points_used` (HP deducted).

---

## Pagination

All list endpoints support:
```
?limit=20&offset=0
```

Max `limit` is endpoint-specific (usually 50–200). Default is 20 or 50.

---

## Admin-Only Endpoints Summary

These require `role IN ('admin', 'super_admin')`:

```
POST   /api/menu/categories
PATCH  /api/menu/categories/<id>
POST   /api/menu/items
PATCH  /api/menu/items/<id>
DELETE /api/menu/items/<id>          (archives, never hard-deletes)
POST   /api/menu/addons
PATCH  /api/menu/addons/<id>
POST   /api/menu/items/<id>/variation-groups
PATCH  /api/kitchen/capacity         { "daily_order_capacity": 120 }
PATCH  /api/orders/<id>/status       { "status": "preparing", "notes": "..." }
POST   /api/admin/users/<id>/deactivate
POST   /api/admin/users/<id>/role    { "role": "kitchen" }
POST   /api/hp/admin/grant           { "user_id": "uuid", "amount": 100, "reason": "..." }
POST   /api/admin/delivery-windows
POST   /api/admin/batches
GET    /api/analytics/...
GET    /api/admin/audit-log
```

---

## Kitchen-Only Endpoints

Require `role = 'kitchen'`:

```
GET    /api/kitchen/queue            // today's orders grouped by status
PATCH  /api/kitchen/orders/<id>/status  { "status": "preparing" | "ready" }
GET    /api/kitchen/capacity         // same as /api/menu/kitchen-capacity
```

---

## Rider-Only Endpoints

Require `role = 'rider'`:

```
GET    /api/riders/batch             // rider's assigned batch
PATCH  /api/riders/batch/<id>/order/<order_id>/delivered
PATCH  /api/riders/batch/<id>/order/<order_id>/attempted
GET    /api/riders/order/<id>/contact  // secure call link (masked phone)
```
