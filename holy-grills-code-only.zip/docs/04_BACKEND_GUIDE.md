# Holy Grills — Backend Developer Guide
## Auth · Services · Routes · Payments · Webhooks · Cron Jobs · Notifications

> This document is the onboarding guide for a new backend developer joining the project.
> Read `01_BUSINESS_LOGIC.md` first. Read `03_DATABASE_SCHEMA.md` alongside this.

---

## Project Structure

```
holy-grills-backend/
├── app/
│   ├── __init__.py              ← Flask app factory, blueprint registration
│   ├── config.py                ← ALL configuration constants (HP rates, JWT, secrets)
│   ├── db.py                    ← Supabase client wrapper (MockableQuery pattern)
│   ├── middleware/
│   │   ├── auth.py              ← @require_auth, @require_role, @optional_auth
│   │   └── rate_limit.py        ← @rate_limit decorator
│   ├── routes/
│   │   ├── auth.py              ← /api/auth/*
│   │   ├── orders.py            ← /api/orders/*
│   │   ├── menu.py              ← /api/menu/*
│   │   ├── hp.py                ← /api/hp/*
│   │   ├── rewards.py           ← /api/rewards/*
│   │   ├── referrals.py         ← /api/referrals/*
│   │   ├── wallet.py            ← /api/wallet/*
│   │   ├── leaderboard.py       ← /api/leaderboard/*
│   │   ├── notifications.py     ← /api/notifications/*
│   │   ├── admin.py             ← /api/admin/*
│   │   ├── analytics.py         ← /api/analytics/*
│   │   ├── webhooks.py          ← /api/webhooks/*
│   │   ├── events.py            ← /api/events/*
│   │   ├── challenges.py        ← /api/challenges/*
│   │   ├── marketplace.py       ← /api/marketplace/*
│   │   ├── storefront.py        ← /api/storefront/*
│   │   ├── kitchen.py           ← /api/kitchen/*
│   │   ├── riders.py            ← /api/riders/*
│   │   └── analytics.py        ← /api/analytics/*
│   ├── services/
│   │   ├── hp_service.py        ← ALL HP logic (earn, spend, tier, pending pool)
│   │   ├── order_service.py     ← Order creation, payment confirmation, HP trigger
│   │   ├── auth_service.py      ← Registration, login, profile updates
│   │   ├── wallet_service.py    ← Wallet credit/debit
│   │   ├── payment_service.py   ← Paystack API calls
│   │   └── notification_service.py ← send_notification(), send_blast()
│   ├── tasks/
│   │   ├── celery_app.py        ← Celery instance
│   │   └── scheduled.py         ← All cron jobs
│   └── utils/
│       ├── email.py             ← SendGrid email sending
│       └── validators.py        ← Input validation helpers
├── tests/
│   ├── conftest.py              ← Mock DB, sample data, fixtures
│   ├── test_stress_a_*.py       ← HP balance tests
│   ├── test_stress_b_*.py       ← HP earn/spend tests
│   ├── test_stress_c_*.py       ← Order + payment tests
│   ├── test_stress_d_*.py       ← Tier system tests
│   ├── test_stress_e_*.py       ← Leaderboard tests
│   ├── test_stress_f_*.py       ← Marketplace/rewards tests
│   ├── test_stress_g_*.py       ← Concurrency/idempotency tests
│   └── test_stress_h_*.py       ← Data consistency tests
├── docs/                        ← This documentation suite
├── migrations/                  ← Schema migrations (run in Supabase SQL editor)
├── docs/enums_indexes_seed.sql  ← HP ecosystem additive schema (idempotent)
├── run.py                       ← App entry point
├── pytest.ini                   ← Test config
└── requirements.txt             ← Python dependencies
```

---

## 1. Auth Layer

### How it works

Authentication is handled by Supabase Auth. Users receive a JWT from Supabase after login. The backend verifies that JWT on every protected request.

**Files:** `app/middleware/auth.py`, `app/services/auth_service.py`

### Token format
```
Authorization: Bearer <supabase_jwt_token>
```

### JWT payload structure (what Supabase encodes)
```json
{
  "sub": "uuid-of-user",           ← This becomes g.user_id in the handler
  "email": "user@example.com",
  "app_metadata": {
    "role": "student"              ← Role is read from the profiles table, NOT here
  },
  "exp": 1234567890
}
```

### Decorators

**`@require_auth`** — Verifies token, loads `profiles` row, sets:
- `g.user_id` = user UUID
- `g.user` = profile dict
- `g.user_role` = role string
- `g.jwt_token` = raw token string
- `g.jwt_payload` = decoded JWT payload

**`@require_role("admin")` / `@require_role("admin", "kitchen")`** — Same as require_auth but also enforces `profiles.role` membership.

**`@optional_auth`** — Tries to load user but doesn't fail on missing token. Used for guest-friendly endpoints.

### Roles
| Role | Can Do |
|------|--------|
| `student` | Order food, earn/spend HP, view own data |
| `admin` | Everything — all admin endpoints, HP grants, user management |
| `kitchen` | Update order status, view delivery windows |
| `rider` | Update order status |

### Configuration (app/config.py)
```python
JWT_SECRET = env["JWT_SECRET"]      # Must match your Supabase JWT secret
JWT_ALGORITHM = "HS256"
JWT_ACCESS_TOKEN_EXPIRES = 3600     # 1 hour
JWT_REFRESH_TOKEN_EXPIRES = 2592000 # 30 days
```

---

## 2. Business Logic Layer (Services)

### Rule: All business logic lives in services, never in routes

Routes are thin controllers. All rules, calculations, and state transitions live in service files.

---

### hp_service.py — The HP engine

This is the most critical file in the backend. Every HP operation goes through here.

> **Critical Architecture Note — Tier Multiplier Dual Source**
>
> The tier earn multiplier (% HP bonus on food orders) lives in **two places**:
>
> 1. `tiers.earn_multiplier` in the DB — used by `recalculate_tier()` to update `profiles.tier_bonus_multiplier`
> 2. `TIER_SLUGS_MULTIPLIER` dict in `hp_service.py` — used by `award_food_order_hp()` for the actual HP calculation
>
> If you update only the DB, food order HP will still use the old rate. **Always update both.** See `docs/00_CHANGE_COOKBOOK.md` Section 1.4 for exact steps.

**Key functions:**

```python
get_hp_balance(user_id) → dict
# Returns: {active, pending, overflow, total_visible, monthly_hp_earned, 
#           hp_earned_120day, tier_bonus_multiplier}

award_active_hp(user_id, amount, txn_type, reference_id, reference_type,
                source_type, notes, issued_by_admin_id) → dict
# Awards HP to ACTIVE pool
# amount > 0 = grant HP
# amount < 0 = reversal (ONLY when issued_by_admin_id is set)
# Writes to: hp_transactions

earn_pending_hp(user_id, amount, source_type, reference_id, notes) → dict
# Awards HP to PENDING pool (ceiling enforced, overflow to vault)
# Returns: {added_to_pending, added_to_overflow, ceiling}

spend_hp(user_id, amount, reference_id, reference_type, notes) → dict
# Deducts from ACTIVE pool. Raises ValueError if insufficient.
# Returns: {spent, balance_after}

unlock_pending_hp(user_id, order_id, food_spend) → dict
# Fires on every delivered order
# Calculates: floor(food_spend / 1000) × 100 HP to unlock
# Moves pending → active, restores overflow → pending if ceiling rises
# Returns: {unlocked, overflow_restored}

get_user_tier(user_id) → dict
# Returns: {tier: {...}, is_in_grace_period, grace_period_ends_at, achieved_at}

recalculate_tier(user_id) → dict
# Compares hp_earned_120day against tier thresholds
# Updates user_tiers and profiles.tier_bonus_multiplier
# Returns: {tier: {...}, changed: bool}

expire_hp(user_id, amount, notes) → dict
# Writes a negative hp_transactions record with type='expire'
# Returns: {expired: int}

award_food_order_hp(user_id, order_id, order_total, tier_slug) → dict
# Called automatically when an order is delivered
# Calculates base + tier bonus HP, writes to active pool
# Also triggers unlock_pending_hp
# Returns: {base_hp, tier_bonus_hp, total_hp, unlocked_pending_hp}
```

---

### order_service.py — Order lifecycle

```python
create_order(user_id, data) → dict
# Validates: items exist, window is open, payment method valid, promo valid
# Creates: order + order_items + payment record
# Handles: guest orders, HP redemption, promo codes, split payment

update_order_status(order_id, new_status, changed_by, notes) → dict
# Validates state machine transition
# On DELIVERED: calls confirm_delivery() which triggers HP award
# Logs to: order_status_log

confirm_order_payment(order_id, payment_reference, provider_response) → dict
# Called by webhook handler
# Moves order from payment_pending → confirmed

confirm_delivery(order_id) → dict
# Called when status → delivered
# Calls: award_food_order_hp(), award_welcome_bonus(), recalculate_tier()
# Triggers: _trigger_referral_completion()
```

---

### notification_service.py

```python
send_notification(user_id, notif_type, title, body, reference_id, 
                  reference_type, channels, action_url) → None
# Writes row(s) to notifications table
# For email channel: calls email.py to send via SendGrid
# For push channel: calls FCM/APNS

send_blast(blast_id) → dict
# Loads blast from notification_blasts table
# Sends to all (or segmented) users
# Updates blast.is_sent and sent_to_count
```

---

## 3. API Routes

### Blueprint Registration (`app/__init__.py`)

All blueprints are registered at `/api/*`:
```python
/api/auth/*          ← auth_bp
/api/orders/*        ← orders_bp
/api/menu/*          ← menu_bp
/api/hp/*            ← hp_bp
/api/rewards/*       ← rewards_bp
/api/referrals/*     ← referrals_bp
/api/wallet/*        ← wallet_bp
/api/leaderboard/*   ← leaderboard_bp
/api/notifications/* ← notifications_bp
/api/admin/*         ← admin_bp
/api/analytics/*     ← analytics_bp
/api/webhooks/*      ← webhooks_bp
/api/events/*        ← events_bp
/api/challenges/*    ← challenges_bp
/api/marketplace/*   ← marketplace_bp
/api/storefront/*    ← storefront_bp
/api/kitchen/*       ← kitchen_bp
/api/riders/*        ← riders_bp
```

### Route Pattern
Every route follows this pattern:
```python
@blueprint.route("/path", methods=["GET"])
@require_auth          # or @require_role("admin")
def handler():
    data = request.get_json(force=True)
    # validate inputs
    try:
        result = service.do_thing(g.user_id, data)
        return jsonify(result), 200
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": "...", "detail": str(e)}), 500
```

---

## 4. Payment Integration (Paystack)

**File:** `app/services/payment_service.py`

### Flow: Card Payment for Order
```
1. User creates order with payment_method="card"
2. Backend calls initialize_payment() → gets authorization_url
3. User redirected to Paystack payment page
4. User completes payment
5. Paystack sends webhook to POST /api/webhooks/paystack
6. Webhook handler calls confirm_order_payment()
7. Order moves to confirmed state
```

### Flow: Wallet Top-up
```
1. User calls POST /api/wallet/fund/card with amount
2. Backend calls initialize_payment() with type=wallet_topup in metadata
3. User pays on Paystack
4. Webhook receives charge.success
5. credit_wallet() is called
6. If amount >= 3000: award 50 HP ACTIVE automatically
```

### Flow: Bank Transfer (DVA)
```
1. User's wallet has a virtual account number (assigned via DVA webhook)
2. User transfers money to that account number from any bank app
3. Paystack sends transfer.success webhook
4. Backend credits the wallet matching the account number
```

### Environment variables required
```
PAYSTACK_SECRET_KEY=sk_live_...
PAYSTACK_PUBLIC_KEY=pk_live_...
PAYSTACK_WEBHOOK_SECRET=...    ← Used for HMAC signature verification
```

---

## 5. Webhook Handlers

**File:** `app/routes/webhooks.py`

### Security first
Every webhook is validated with HMAC-SHA512:
```python
computed = hmac.new(PAYSTACK_WEBHOOK_SECRET.encode(), payload_bytes, hashlib.sha512).hexdigest()
if not hmac.compare_digest(computed, signature):
    abort(401)
```

### Idempotency
Before processing any webhook:
```python
idempotency_key = f"paystack:{event_type}:{reference}"
existing = db.table("webhook_events").eq("idempotency_key", idempotency_key).execute()
if existing:
    return 200  # Already processed, ignore
```

### Supported events
| Event | Handler | What it does |
|-------|---------|-------------|
| `charge.success` | `_handle_charge_success()` | Routes to order payment OR wallet top-up |
| `dedicatedaccount.assign.success` | `_handle_dva_assign()` | Saves virtual account number to wallet |
| `transfer.success` | `_handle_transfer()` | Credits wallet from bank transfer |

### Configuration for Paystack Dashboard
Set webhook URL to: `https://your-domain.com/api/webhooks/paystack`

---

## 6. Cron Jobs (Scheduled Tasks)

**File:** `app/tasks/scheduled.py`

All tasks run via Celery + Redis. All tasks are idempotent (safe to re-run).

### Setting up Celery
```
REDIS_URL=redis://localhost:6379/0
CELERY_BROKER_URL=redis://localhost:6379/0
CELERY_RESULT_BACKEND=redis://localhost:6379/0
```

Start a worker:
```bash
celery -A app.tasks.celery_app worker --loglevel=info
```

Start the beat scheduler:
```bash
celery -A app.tasks.celery_app beat --loglevel=info
```

### Cron Schedule (configure in Celery beat config or use Supabase pg_cron)

| Task | Schedule | What it does |
|------|----------|-------------|
| `reset_monthly_leaderboard` | 1st of month 00:01 WAT | Archives top 10, resets `monthly_hp_earned` to 0 for all users |
| `recalculate_120day_hp` | Daily 02:00 WAT | Recalculates `hp_earned_120day` for all active users |
| `tier_grace_period_check` | Daily 03:00 WAT | Starts/enforces 7-day grace periods, drops tiers |
| `birthday_hp_awards` | Daily 08:00 WAT | Awards 150 HP ACTIVE to users with birthday today |
| `hp_expiry_check` | Weekly Sunday 04:00 WAT | Applies 25% breakage to accounts inactive 90+ days |
| `scan_abandoned_carts` | Every 30 minutes | Flags carts inactive 60+ minutes |

### Distributed Locking
Every cron task acquires a lock via `try_acquire_cron_lock(job_name)` RPC before running. This prevents duplicate runs if multiple workers exist.

```python
lock_acquired = db.rpc("try_acquire_cron_lock", {"p_job_name": "reset_monthly_leaderboard"})
if not lock_acquired:
    return {"skipped": "Lock not acquired"}
# ... do work ...
db.rpc("release_cron_lock", {"p_job_name": "reset_monthly_leaderboard"})
```

---

## 7. Notification System

**File:** `app/services/notification_service.py`

### Channels
- `in_app` — Writes to `notifications` table. User reads via `GET /api/notifications`
- `email` — Sends via SendGrid. Configure `SENDGRID_API_KEY`
- `push` — FCM/APNS push notification (configure separately)

### Usage pattern
```python
from app.services.notification_service import send_notification

send_notification(
    user_id=user_id,
    notif_type="hp_earned",
    title=f"+{total_hp} HP Earned!",
    body="Your food order earned you Holy Points.",
    reference_id=order_id,
    reference_type="order",
    channels=["in_app"],   # or ["in_app", "email", "push"]
)
```

### Required environment variables
```
SENDGRID_API_KEY=SG....
EMAIL_FROM=noreply@holygrills.ng
EMAIL_FROM_NAME=Holy Grills
```

---

## 8. Environment Variables (Full List)

Set all of these in your environment before running the server:

```bash
# Required — no default
SUPABASE_URL=https://xqglpwcfofkioqdjywvd.supabase.co
SUPABASE_SERVICE_ROLE_KEY=eyJ...
SUPABASE_ANON_KEY=eyJ...
SECRET_KEY=<random-secret>
JWT_SECRET=<your-supabase-jwt-secret>

# Payments
PAYSTACK_SECRET_KEY=sk_live_...
PAYSTACK_PUBLIC_KEY=pk_live_...
PAYSTACK_WEBHOOK_SECRET=...

# Email
SENDGRID_API_KEY=SG....
EMAIL_FROM=noreply@holygrills.ng

# Background jobs
REDIS_URL=redis://localhost:6379/0

# Optional
CORS_ORIGINS=https://your-app.com,https://admin.your-app.com
FLASK_DEBUG=false
FLASK_ENV=production
```

---

## 9. Running the Server

### Development
```bash
# Install dependencies
pip install -r requirements.txt

# Set env vars (use .env file with python-dotenv)
cp .env.example .env
# Edit .env with your credentials

# Run the Flask dev server
python run.py

# Or with gunicorn (production-like)
gunicorn -w 4 -b 0.0.0.0:5000 "app:create_app()"
```

### Production
```bash
gunicorn -w 4 -b 0.0.0.0:5000 --timeout 30 "app:create_app()" &
celery -A app.tasks.celery_app worker --loglevel=info &
celery -A app.tasks.celery_app beat --loglevel=info &
```

---

## 10. Making Schema Changes

### Rules
1. NEVER drop columns — use `is_archived` / `is_active` flags instead
2. All migrations must be additive and idempotent
3. Run migrations via Supabase Dashboard → SQL Editor
4. New columns must have defaults so existing rows don't break
5. After any schema change, update `docs/03_DATABASE_SCHEMA.md`

### Migration file convention
Name files: `NNN_description.sql` (e.g. `006_user_feedback.sql`)

Applied migrations:
- `001` — Core schema (profiles, orders, menu, wallet, HP tables)
- `002` — Events, marketplace, leaderboard, challenges
- `003` — Notifications, audit log, storefront
- `004` — Menu addons, variation groups, kitchen settings, daily limits
- `005` — Security RLS fixes, cron_locks, referrals UNIQUE constraint, 8 performance indexes

---

## 11. Common Patterns to Follow

### Pattern: Reading config constants
```python
# ALWAYS read from current_app.config — never hardcode amounts in service functions
config = current_app.config
amount = config["WELCOME_BONUS_HP"]       # ← correct
amount = 50                                # ← wrong — won't reflect config changes
```

### Pattern: Checking idempotency before awarding HP
```python
# Always check before doing an irreversible operation
db = get_db()
existing = (
    db.table("hp_transactions")
    .select("id")
    .eq("user_id", user_id)
    .eq("source_type", "welcome")
    .execute()
)
if existing:
    return {"awarded": 0, "reason": "Already received"}
```

### Pattern: Admin audit log
```python
# After any admin operation, write to the audit log
db.table("admin_audit_log").insert({
    "actor_id": g.user_id,
    "actor_role": "admin",
    "target_table": "profiles",
    "target_id": user_id,
    "action": "hp_grant",
    "after_data": {"amount": amount, "reason": reason},
})
```

### Pattern: Never trust client-submitted amounts
```python
# ALWAYS recalculate totals server-side
subtotal = sum(item["price_snapshot"] * item["quantity"] for item in items)
# NEVER: total = data["total"]  ← client could forge this
```

### Pattern: Frozen snapshots on financial records
```python
# Snapshot price and name AT ORDER TIME, not linked live to menu_items
db.table("order_items").insert({
    "menu_item_id":   item["id"],
    "item_name":      item["name"],    # snapshot — frozen even if menu changes
    "unit_price":     item["price"],   # snapshot — frozen even if price changes
    "quantity":       qty,
})
```

### Pattern: State machine validation before status change
```python
# Always validate against VALID_TRANSITIONS before updating order status
# (app/services/order_service.py)
allowed = VALID_TRANSITIONS.get(current_status, [])
if new_status not in allowed:
    raise ValueError(f"Cannot move from {current_status} to {new_status}")
```

