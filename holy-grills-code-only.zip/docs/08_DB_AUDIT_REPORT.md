# Holy Grills — Live Database Audit Report
## Full Production Readiness Assessment

> **Audited against:** Supabase project `xqglpwcfofkioqdjywvd`
> **Audit date:** May 2026
> **Method:** Direct Management API SQL queries + REST API RLS verification
> **Final Status: PRODUCTION READY** (migrations 004 + 005 applied and verified)

---

## Executive Summary

| Dimension | Before Audit | After Migrations 004+005 |
|-----------|-------------|--------------------------|
| Tables | 46 | **51** |
| RLS enabled | 46/46 (100%) | **51/51 (100%)** |
| Tables with RLS but no policies | 6 broken | **1 (cron_locks — intentional)** |
| Critical security vulnerabilities | 2 | **0** |
| Total indexes | ~200 | **228** |
| Migration 004 tables missing | 4 | **0** |
| Missing cron_locks table | yes | **no** |

---

## Live DB Final Snapshot

```
Total tables:    51
Total policies:  81
Total indexes:   228
Total triggers:  33
Total functions: 68
RLS enabled:     51/51 (100%)
Intentionally locked (no policy):  1  →  cron_locks (server-only via service role)
```

### Seeded Reference Data

| Table | Rows | Content |
|-------|------|---------|
| `tiers` | 4 | Ember (0 HP), Flame (2,500), Blaze (7,500), Holy (20,000) |
| `menu_categories` | 12 | All active |
| `menu_items` | 12 | All active, prices set |
| `operating_hours` | 7 | Mon–Sun 10 am–8 pm |
| `promo_codes` | 4 | WELCOME10 (10%), and 3 others |
| `rewards` | 4 | HP reward store seeded |
| `challenges` | 5 | Active challenges |
| `storefront_sections` | 1 | Hero section |
| `kitchen_settings` | 1 | `daily_order_capacity = 150` |

---

## Strengths

### 1. Immutable Append-Only Ledgers
`hp_transactions` and `admin_audit_log` both have `BEFORE UPDATE/DELETE` triggers that raise an exception — no row can ever be modified or removed. HP balance is always the authoritative `SUM(amount WHERE status='active')` from this table. The audit log cannot be silenced.

### 2. Financial Constraints Enforced at DB Level
```sql
hp_transactions.amount <> 0                         -- no zero-value transactions
hp_transactions.balance_after >= 0                   -- HP can never go negative
wallets.balance >= 0                                  -- wallet can never go negative
wallet_transactions.idempotency_key  UNIQUE           -- prevents double top-up
webhook_events.idempotency_key       UNIQUE           -- prevents double webhook processing
orders.total = subtotal + delivery_fee - promo_discount - hp_discount  -- arithmetic locked
orders.total, subtotal, delivery_fee, promo_discount, hp_discount >= 0 -- all non-negative
profiles.pending_hp_balance >= 0                     -- pending pool can't go negative
profiles.hp_overflow >= 0                            -- overflow can't go negative
```

### 3. Role Security via DB Table, Not JWT Claims
```sql
-- All three functions are SECURITY DEFINER — run as definer, not caller
is_admin()   → SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin','super_admin')
is_kitchen() → SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'kitchen'
is_rider()   → SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'rider'
```
Roles are read from the `profiles` table, not JWT claims. Changing a user's role takes effect immediately — no need to invalidate or re-issue JWTs.

### 4. Atomic DB Functions (Race-Condition Safe)
```sql
checkin_event_atomic()       -- FOR SHARE lock; UNIQUE(event_id, user_id) catches duplicate QR scans
claim_marketplace_code()     -- FOR UPDATE SKIP LOCKED — no double code assignment
claim_next_delivery_batch()  -- FOR UPDATE SKIP LOCKED — no double batch claim
redeem_promo_code_atomic()   -- Atomic inventory check + decrement
place_order_atomic()         -- Atomic kitchen capacity + per-item daily limit check
```

### 5. Order Data Integrity
- PostgreSQL enum `order_status` — only valid status strings can be stored
- `trg_orders_no_hard_delete` — DELETE blocked; use `cancelled` status
- `trg_bump_order_version` — optimistic locking via auto-incremented `version` column
- `trg_log_order_status` — every status change written to `order_status_log` automatically
- `trg_stamp_order_timestamps` — `received_at`, `preparing_at`, `ready_at`, etc. auto-stamped on transition

### 6. Enum Type Safety on All Critical Columns
```
order_status     → pending_payment | received | preparing | ready | dispatched |
                   delivered | attempted | unclaimed | cancelled | refunded
payment_method   → wallet | card | split | guest_card
batch_status     → pending | assigned | in_progress | completed
user_role        → student | kitchen | rider | admin | super_admin
hp_transaction_type → 15 strongly-typed values
wallet_tx_type   → 7 values
```
Invalid strings are rejected at the PostgreSQL type-cast level before any constraint is evaluated.

### 7. Idempotent Webhook Processing
`webhook_events.idempotency_key` format: `"provider:event_type:reference"`. The UNIQUE constraint (`uq_webhook_idem`) causes any duplicate INSERT to fail — preventing double-crediting of wallet top-ups or HP awards.

### 8. Guest Checkout Safety
- `orders.claim_token` UNIQUE — token cannot be reused
- `claim_guest_order()` uses `WHERE claimed_by IS NULL AND user_id IS NULL` — atomic, no double-claim
- Guest email and phone validated by regex CHECK constraints

### 9. Referral Deduplication (DB-Level)
`UNIQUE(referrer_id, referred_user_id)` on `referrals` — one referral record per pair, enforced at the DB layer even if the application sends duplicates.

### 10. Auto Wallet Creation
`trg_create_wallet_on_signup` fires `AFTER INSERT ON profiles` — every new user automatically gets a wallet row. No code path can forget to create the wallet.

### 11. Role Change Auditing
`trg_audit_role_change` fires `AFTER UPDATE ON profiles` — every `role` change is automatically written to `admin_audit_log` with before/after snapshots. Cannot be bypassed.

---

## Vulnerabilities Found and Fixed

### CRITICAL — orders_own_insert removed
**What it was:** `orders_own_insert` RLS policy (`cmd: INSERT, with_check: user_id = auth.uid() OR user_id IS NULL`) allowed any authenticated or anonymous user to `INSERT` orders directly into Supabase, completely bypassing:
- Paystack payment processing
- Price validation against menu_items
- Kitchen capacity checks
- Per-item daily limit enforcement
- HP earning and promo-code logic

A user could insert an order with `total = 0.01` and no payment reference.

**Fix applied (Migration 005):** `DROP POLICY orders_own_insert ON orders` — orders are now exclusively created via the backend API using the service role key. Verified: `pg_policies` contains zero rows with this policy name.

---

### CRITICAL — order_reviews ALL → SELECT + INSERT
**What it was:** `reviews_own` policy (`cmd: ALL, qual: user_id = auth.uid()`) allowed users to:
- UPDATE their own rating from 1★ to 5★ after submission
- DELETE their own review, then resubmit to re-earn the 20 HP monthly review award

**Fix applied (Migration 005):**
- `reviews_own` (ALL) dropped
- `reviews_own_select` (SELECT only) created
- `reviews_own_insert` (INSERT only) created

Reviews are now immutable once submitted. HP can only be earned once per month for reviews.

---

### MEDIUM — 6 Tables with RLS Enabled but No Policies
**What they were:** `hall_of_fame`, `flash_redemptions`, `hp_bundle_purchases`, `hp_unlock_log`, `leaderboard_monthly`, `spin_win_entries` — all had RLS on but zero policies. Any client JWT call to these tables returned an empty result set (safe but silently broken).

**Fix applied (Migration 005):** All 6 tables now have proper policies:
- Public leaderboard tables → `SELECT true` (anyone can read)
- User-owned tables → `SELECT user_id = auth.uid() OR is_admin()`
- Admin write policies on all

---

### MEDIUM — Missing cron_locks Table
**What it was:** The Celery scheduler referenced a `cron_locks` table for distributed locking that didn't exist. On the first cron run, the task would error silently, meaning:
- HP expiry cron could double-run
- Tier recalculations could overlap
- Leaderboard snapshots could be duplicated

**Fix applied (Migration 005):** `cron_locks` table created. Only the service role can access it (RLS on, no client policies).

---

### MEDIUM — Missing Indexes on High-Traffic Columns
**What was missing:** `hp_transactions.user_id`, `orders.user_id`, `referrals.referrer_id`, `pending_hp_transactions.user_id`, `notifications.user_id`, `webhook_events.idempotency_key`, `orders.status`.

**Fix applied (Migration 005):** 8 targeted indexes added (see listing below).

---

### LOW — Missing RLS on Migration 004 Tables
`menu_addons`, `menu_item_variation_groups`, `menu_item_variation_options`, `kitchen_settings` were created without RLS policies.

**Fix applied (Migration 005):** All 4 tables now have RLS + appropriate policies.

---

## Remaining Limitations (Not Yet Fixed)

### 1. In-Memory Rate Limiting
`app/middleware/rate_limit.py` uses a Python dictionary. Limits don't persist across restarts or coordinate across Gunicorn workers.

**Remediation:** Use `flask-limiter` with `RATELIMIT_STORAGE_URI = os.environ['REDIS_URL']`. Redis is already in the env var list.

### 2. Active HP Balance Not Pre-Computed
Active HP = `SUM(hp_transactions.amount WHERE user_id=X AND status='active')`. At 100k+ transactions this becomes a slow query.

**Remediation:** Add `profiles.active_hp_balance integer DEFAULT 0` and a trigger on `hp_transactions INSERT` to maintain it.

### 3. No DB-Level Price Validation for Order Items
`order_items.unit_price` is not validated against `menu_items.price`. Only application-layer validation exists.

**Remediation:** Add a trigger that checks `ABS(NEW.unit_price - menu_items.price) / menu_items.price < 0.05`.

### 4. Stale Tier Display Between Cron Runs
Tier recalculation is daily (Celery cron). A user who just crossed a threshold sees the old tier until the next cron run.

**Remediation:** Add `recalculate_user_tier(user_id)` DB function called as an `AFTER INSERT` trigger on `hp_transactions`.

---

## Indexes Added (Migration 005)

```sql
idx_hp_tx_user_status     ON hp_transactions (user_id, status)
idx_hp_tx_user_created    ON hp_transactions (user_id, created_at DESC) WHERE amount > 0
idx_orders_status_created ON orders (status, created_at DESC)
idx_orders_user_created   ON orders (user_id, created_at DESC)
idx_referrals_referrer_status ON referrals (referrer_id, status)
idx_pending_hp_user_status    ON pending_hp_transactions (user_id, status)
idx_notifications_user_read   ON notifications (user_id, is_read) WHERE is_read = false
idx_webhook_idem              ON webhook_events (idempotency_key)
```

---

## Column Name Corrections (Live DB vs Docs)

The live database column names differ from what was in the original docs for the `orders` and `order_items` tables. The Flask services already use the correct live column names.

| Table | Original Docs | Live DB (Correct) |
|-------|--------------|-------------------|
| `orders` | `discount` | `promo_discount` |
| `orders` | `wallet_amount` | `wallet_amount_used` |
| `orders` | `card_amount` | `card_amount_used` |
| `orders` | `hp_points_redeemed` | `hp_points_used` |
| `orders` | `delivery_address` | `delivery_address_snapshot` |
| `order_items` | `name_snapshot` | `item_name` |
| `order_items` | `price_snapshot` | `unit_price` |
| `profiles` | not documented | `google_id` (UNIQUE) — Google OAuth pre-wired |

---

## Tables in Live DB but Not in Original Docs

These 7 tables are fully functional and have RLS policies:

| Table | Purpose |
|-------|---------|
| `catering_requests` | Catering inquiry form; public INSERT, admin manages |
| `marketplace_listing_requests` | Vendor listing requests; public INSERT, admin manages |
| `newsletter_subscriptions` | Email opt-ins; public INSERT, own UPDATE |
| `operating_hours` | Store open/close hours by day of week |
| `operating_hour_overrides` | Holiday/special-day hour exceptions |
| `promo_code_uses` | Per-use ledger for promo code redemptions |
| `user_addresses` | Saved delivery addresses per user |

---

## Tables in Docs but Not in Live DB

| Table | Verdict |
|-------|---------|
| `riders` | Not needed. Riders = `profiles.role='rider'`. Rider routes use `delivery_batches`. |
| `kitchen_staff` | Not needed. Kitchen staff = `profiles.role='kitchen'`. |
| `storefront_pages` | Not present and not referenced by any route. Vestigial. |
| `banners` | Not present and not referenced by any route. Remove from docs. |

---

## Supabase Performance Advisor — All Issues Resolved

| Advisor Finding | Table | Status |
|----------------|-------|--------|
| Missing index on FK | `hp_transactions.user_id` | ✅ Migration 005 |
| Missing index on FK | `orders.user_id` | ✅ Migration 005 |
| Missing index on FK | `referrals.referrer_id` | ✅ Migration 005 |
| Missing index on FK | `pending_hp_transactions.user_id` | ✅ Migration 005 |
| Missing index on FK | `notifications.user_id` | ✅ Migration 005 |
| Unindexed unique key | `webhook_events.idempotency_key` | ✅ Migration 005 |
| Sequential scan risk | `orders.status` | ✅ Composite index added |
| Unread filter | `notifications.is_read` | ✅ Partial index added |

---

## Live API Test Results

| Test | Result |
|------|--------|
| Service role reads all 51 tables | ✅ |
| Anon key reads menu categories (12) | ✅ |
| Anon key reads menu items (12) | ✅ |
| Anon key reads tiers (4) | ✅ |
| Anon key BLOCKED from orders | ✅ (0 rows — RLS) |
| Anon key BLOCKED from profiles | ✅ (0 rows — RLS) |
| Anon key BLOCKED from hp_transactions | ✅ (0 rows — RLS) |
| Anon key reads hall_of_fame (post-fix) | ✅ |
| kitchen_settings responds post-004 | ✅ (`daily_order_capacity = 150`) |
| menu_addons table accessible post-004 | ✅ (0 rows — awaiting seed data) |
| orders_own_insert policy absent | ✅ Confirmed via pg_policies |
| reviews_own ALL policy absent | ✅ Confirmed via pg_policies |
| cron_locks table exists | ✅ |
| referrals UNIQUE(referrer, referred) | ✅ |
| Flask test suite (799 tests) | ✅ All pass |
| FastAPI test suite (87 tests) | ✅ All pass |
