# Holy Grills — Business Logic Document
## State Machines · Rules · Validations · Workflows

> Last validated against: 541/541 tests passing · Live Supabase schema confirmed · May 2026

---

## Table of Contents
1. [HP (Holy Points) Economy](#1-hp-holy-points-economy)
2. [HP Balance Pools](#2-hp-balance-pools)
3. [HP Earn Rules](#3-hp-earn-rules)
4. [HP Spend Rules](#4-hp-spend-rules)
5. [HP Expiry & Breakage](#5-hp-expiry--breakage)
6. [Tier System State Machine](#6-tier-system-state-machine)
7. [Order State Machine](#7-order-state-machine)
8. [Referral Workflow](#8-referral-workflow)
9. [Leaderboard & Monthly Reset](#9-leaderboard--monthly-reset)
10. [Flash Redemption Rules](#10-flash-redemption-rules)
11. [Marketplace HP Pricing Formula](#11-marketplace-hp-pricing-formula)
12. [Payment & Wallet Rules](#12-payment--wallet-rules)
13. [Notification Triggers](#13-notification-triggers)
14. [Rate Limits & Caps](#14-rate-limits--caps)

---

## 1. HP (Holy Points) Economy

Holy Points (HP) is the proprietary loyalty currency for Holy Grills. Every rule below is hardcoded in `app/config.py` and enforced in `app/services/hp_service.py`.

### Core Constants (all from Master Brand Document)

> **How to change any of these:** See `docs/00_CHANGE_COOKBOOK.md` Section 2 for exact steps.

| Constant | Value | Meaning | Configured At |
|----------|-------|---------|---------------|
| `HP_LIABILITY_VALUE` | ₦0.185 | Internal accounting value per HP | `app/config.py` |
| `HP_PER_NAIRA_FOOD` | 0.1 | 1 HP earned per ₦10 spent on food | `app/config.py` |
| `HP_UNLOCK_RATE` | 100 HP | Unlocked per ₦1,000 food spend | `app/config.py` |
| `PENDING_CEILING_RATIO` | 35% | Pending pool max = 35% of active balance | `app/config.py` |
| `PENDING_FLOOR_HP` | 200 | Minimum pending ceiling for new accounts | `app/config.py` |
| `WELCOME_BONUS_HP` | 50 | Awarded ACTIVE on first order | `app/config.py` |
| `REVIEW_HP` | 20 | Awarded PENDING for review (1× per month cap) | `app/config.py` |
| `REFERRAL_HP` | 75 | Awarded PENDING per successful referral | `app/config.py` |
| `EVENT_CHECKIN_HP` | 40 | Awarded PENDING per event check-in (3× per month cap) | `app/config.py` |
| `BIRTHDAY_HP` | 150 | Awarded ACTIVE on user's birthday (30-day window) | `app/config.py` |
| `WALLET_TOPUP_HP` | 50 | Awarded ACTIVE when wallet funded ≥ ₦3,000 | `app/config.py` |
| `WALLET_TOPUP_MIN` | ₦3,000 | Minimum top-up to earn wallet HP | `app/config.py` |
| `SUBSCRIPTION_HP` | 50 | Awarded ACTIVE on newsletter subscription | `app/config.py` |
| `SOCIAL_SHARE_HP` | 25 | Awarded PENDING per valid social share | `app/config.py` |
| `REFERRAL_MILESTONE_5_HP` | 150 | Bonus ACTIVE HP at 5 completed referrals | `app/config.py` |
| `REFERRAL_MILESTONE_10_HP` | 400 | Bonus ACTIVE HP at 10 completed referrals | `app/config.py` |
| `FLASH_DISCOUNT_PCT` | 50% | Flash sale HP discount | `app/config.py` |
| `FLASH_MAX_QTY` | 5 | Max users per flash sale window | `app/config.py` |
| `HP_BUNDLE_PRICE_PER_HP` | ₦5 | Event hosts buy HP at this rate | `app/config.py` |
| `HP_EXPIRY_INACTIVITY_DAYS` | 90 | Days of inactivity before expiry | `app/config.py` |
| `HP_EXPIRY_BREAKAGE_RATE` | 25% | Percentage of active HP expired on inactivity | `app/config.py` |
| `TIER_GRACE_PERIOD_DAYS` | 7 | Days before tier drops after dip below threshold | `app/config.py` |

---

## 2. HP Balance Pools

Every user has THREE HP pools. These are NOT separate accounts — they are logical states tracked in `profiles` columns plus the `hp_transactions` table.

```
┌─────────────────────────────────────────────────────────────────┐
│                        HP BALANCE POOLS                         │
├─────────────────┬────────────────────┬──────────────────────────┤
│  ACTIVE POOL    │   PENDING POOL     │   OVERFLOW VAULT         │
│                 │                    │                          │
│  Spendable HP   │  Locked HP         │  Overflow when pending   │
│  Earned by:     │  Earned by:        │  pool is full            │
│  • food orders  │  • referrals       │                          │
│  • welcome      │  • reviews         │  Drains back to pending  │
│  • birthday     │  • events          │  as active balance grows │
│  • wallet topup │  • social share    │                          │
│  • admin grant  │  • marketplace     │  Stored in:              │
│                 │  Unlocks at:       │  profiles.hp_overflow    │
│  Stored in:     │  100 HP per ₦1,000 │                          │
│  hp_transactions│  food spend        │                          │
│  (status=active)│                    │                          │
│                 │  Stored in:        │                          │
│                 │  profiles.         │                          │
│                 │  pending_hp_balance│                          │
└─────────────────┴────────────────────┴──────────────────────────┘
```

### Pending Pool Ceiling Rule
```
ceiling = MAX(active_balance × 0.35, 200)

If new_hp > ceiling space → overflow goes to vault
As active balance grows → overflow drains back to pending
```

### `get_hp_balance()` — What is returned to the client
```python
{
    "active":        int,   # HP that can be spent on rewards
    "pending":       int,   # HP locked, must be unlocked by ordering
    "overflow":      int,   # HP in vault waiting for ceiling to rise
    "total_visible": int,   # active + pending + overflow
    "monthly_hp_earned": int,
    "hp_earned_120day":  int,
    "tier_bonus_multiplier": float
}
```

---

## 3. HP Earn Rules

### 3.1 Food Order HP (ACTIVE)
```
base_hp = floor(order_total × HP_PER_NAIRA_FOOD)
          = floor(order_total × 0.1)
          = 1 HP per ₦10

tier_bonus_hp = round(base_hp × (multiplier - 1.0))

total_hp = base_hp + tier_bonus_hp
```
Tier multipliers:
- Ember: 1.00× (no bonus)
- Flame: 1.08× (+8%)
- Blaze: 1.15× (+15%)
- Holy:  1.25× (+25%)

HP credited to ACTIVE pool immediately after order is marked `delivered`.

### 3.2 Pending HP Unlock (food spend trigger)
```
unlock_amount = floor(food_spend / 1000) × 100

Actual unlocked = min(unlock_amount, pending_balance)
```
This fires on every delivered order, converting pending → active.

### 3.3 Welcome Bonus (ACTIVE)
- 50 HP credited on user's FIRST delivered order
- Idempotency check: `hp_transactions.source_type = 'welcome'`
- Only awarded once ever per account

### 3.4 Birthday HP (ACTIVE)
- 150 HP on the user's birthday (matched by MM-DD)
- Awarded by daily cron at 08:00 WAT
- Idempotency: checks `hp_transactions.reference_type = 'birthday'` this calendar month
- 30-day window communicated in notification (not enforced in HP itself)

### 3.5 Wallet Top-up HP (ACTIVE)
- 50 HP when wallet is funded ≥ ₦3,000 in a single transaction
- Source: Paystack webhook `charge.success` with `type=wallet_topup`

### 3.6 Review HP (PENDING)
- 20 HP for leaving a review on a delivered order
- Cap: 1 review HP per calendar month
- One review per order (enforced by `orders.review_submitted = true`)

### 3.7 Referral HP (PENDING)
- 75 HP to the referrer when their referred friend places their first delivered order
- Cap: 3 referral HP awards per calendar month
- Idempotency: `referrals.hp_awarded > 0`

### 3.8 Event Check-in HP (PENDING)
- 40 HP per event check-in
- Cap: 3 per calendar month

### 3.9 Social Share HP (PENDING)
- 25 HP per valid social share
- Verified by admin before award

### 3.10 Admin Grant (ACTIVE, can be negative for reversals)
- Admin can issue any positive HP amount
- Admin can issue NEGATIVE HP (reversal) only when `issued_by_admin_id` is set
- All admin grants are logged in `admin_audit_log`

### 3.11 HP Bundle Purchase (PENDING, event hosts only)
- Event hosts pay ₦5 per HP
- HP credited to PENDING pool
- Validates: `naira_paid` must match `hp_amount × 5.0` within ₦1 tolerance

---

## 4. HP Spend Rules

HP can only be spent from the ACTIVE pool.

### 4.1 Reward Redemption
1. User must have `active_balance >= reward.hp_cost`
2. If `reward.min_tier_id` set: user's tier `sort_order` must be ≥ required tier's `sort_order`
3. `spend_hp()` creates a negative `hp_transactions` record
4. `reward_redemptions` record created with `is_fulfilled = false`
5. Fulfilment done manually by ops team (flip `is_fulfilled = true`)

### 4.2 Flash Redemption
- 50% discount on HP cost
- Only first 5 users within the `flash_redemptions` window
- Window enforced by `window_ends_at`

### 4.3 HP Redemption on Order
- User can partially pay for an order with HP at checkout
- `hp_points_to_redeem` field on order creation
- HP deducted from active balance

---

## 5. HP Expiry & Breakage

### Trigger: 90 days of account inactivity
```
Breakage = 25% of current active balance

Example: 1,000 active HP → 250 HP expired
```

### Warning Schedule (via notifications)
- 14 days before expiry: warning notification
- 3 days before expiry: final warning

### Cron: `hp_expiry_check` — Runs weekly, Sunday 04:00 WAT

---

## 6. Tier System State Machine

### Tiers (thresholds in DB, multiplier in BOTH DB and code)

> **To change tier names:** SQL UPDATE on `tiers.name` — zero code change.  
> **To change thresholds:** SQL UPDATE on `tiers.min_hp_threshold` — zero code change.  
> **To change multiplier %:** SQL UPDATE on `tiers.earn_multiplier` AND edit `TIER_SLUGS_MULTIPLIER` dict in `app/services/hp_service.py`. See `docs/00_CHANGE_COOKBOOK.md` Section 1.4.

```
EMBER → FLAME → BLAZE → HOLY
  0       2,500   7,500   20,000
  (HP earned in rolling 120-day window)
```

| Tier | Slug | Threshold | Multiplier | Where multiplier is read for HP calc |
|------|------|-----------|------------|---------------------------------------|
| Ember | `ember` | 0 HP | 1.00× | `TIER_SLUGS_MULTIPLIER` dict in `hp_service.py` |
| Flame | `flame` | 2,500 HP | 1.08× | `TIER_SLUGS_MULTIPLIER` dict in `hp_service.py` |
| Blaze | `blaze` | 7,500 HP | 1.15× | `TIER_SLUGS_MULTIPLIER` dict in `hp_service.py` |
| Holy | `holy` | 20,000 HP | 1.25× | `TIER_SLUGS_MULTIPLIER` dict in `hp_service.py` |

> **Why the dict?** `award_food_order_hp()` is called with a `tier_slug` string. It looks up the multiplier from the `TIER_SLUGS_MULTIPLIER` dict (fast, no DB round-trip). `recalculate_tier()` reads from the DB to update `profiles.tier_bonus_multiplier`. Both must stay in sync when changing a multiplier.

### State Transitions
```
[EMBER] ──────────────────────────────────────────┐
   │                                               │
   │ hp_earned_120day >= 2,500                     │
   ▼                                               │
[FLAME] ──────────────────────────────────────────┤
   │                                               │
   │ hp_earned_120day >= 7,500                     │
   ▼                                               │ drops below threshold
[BLAZE] ──────────────────────────────────────────┤
   │                                               │
   │ hp_earned_120day >= 20,000                    │
   ▼                                               │
[HOLY]  ──────────────────────────────────────────┘
   │
   │ falls below threshold
   ▼
[GRACE PERIOD — 7 days]
   │
   │ recovers → stays at tier
   │ doesn't recover → drops
   ▼
[LOWER TIER]
```

### How tier is calculated
1. `recalculate_120day_hp` cron runs daily — updates `profiles.hp_earned_120day`
2. `recalculate_tier()` in `hp_service.py` compares `hp_earned_120day` against all tier thresholds
3. Tier upgrade: new `user_tiers` row inserted with `is_current = true`, old set to `false`
4. `profiles.tier_bonus_multiplier` updated to match new tier's `earn_multiplier`
5. `tier_grace_period_check` cron runs daily — starts/enforces grace period

### Key Rule: `hp_earned_120day` is the ONLY basis for tier
- It is NOT the same as `monthly_hp_earned`
- It is NOT total lifetime HP
- It is a rolling window recalculated fresh daily

---

## 7. Order State Machine

```
[CREATED] ──payment──► [PAYMENT_PENDING]
                              │
                    webhook confirms
                              │
                              ▼
                       [CONFIRMED]
                              │
                         kitchen picks up
                              │
                              ▼
                       [PREPARING]
                              │
                         rider collects
                              │
                              ▼
                      [OUT_FOR_DELIVERY]
                              │
                         rider delivers
                              │
                              ▼
                       [DELIVERED] ──────────────► HP awarded
                                                   Welcome bonus checked
                                                   Referral completed
                                                   Tier recalculated

At any point before DELIVERING:
[CANCELLED] — no HP awarded, refund issued to wallet if paid
```

### Status change rules
- Only `admin`, `kitchen`, `rider` roles can call `PATCH /api/orders/:id/status`
- Every status change logged to `order_status_log`
- HP is ONLY awarded at `DELIVERED` state, never earlier

### Guest Orders
- Guest (unauthenticated) users can order with `guest_name` + `guest_phone`
- A `claim_token` is generated and returned
- After registration, user can claim the order with the token
- Guest orders cannot use wallet payment or HP redemption

---

## 8. Referral Workflow

```
[USER A shares referral_code]
         │
         ▼
[USER B registers with referred_by_code]
         │
         ▼
[referral row created: referrer=A, referred=B, hp_awarded=0]
         │
         ▼
[USER B places FIRST delivered order]
         │
         ▼
[order_service._trigger_referral_completion()]
         │
         ├─► Check: is this B's first delivered order?
         ├─► Look up referral row for B
         ├─► Check: monthly cap (A has < 3 awards this month)?
         │
         ├─ YES ──► award 75 HP PENDING to A
         │          update referral.hp_awarded = 75
         │          notify A: "+75 HP Pending"
         │
         └─ milestone check:
                5 referrals → +150 HP ACTIVE to A
               10 referrals → +400 HP ACTIVE to A + "super_referrer" badge
```

### Idempotency
- `referrals.hp_awarded > 0` prevents double-awarding
- `referrals.triggering_order_id` records which order triggered it
- Monthly cap enforced by counting `referrals.hp_awarded_at >= month_start`

---

## 9. Leaderboard & Monthly Reset

### Monthly Leaderboard
- Ranking field: `profiles.monthly_hp_earned`
- Reset: 1st of every month at 00:01 WAT
- Live rankings: computed from `profiles` when `leaderboard_snapshots` is empty

### Monthly Reset Flow (cron: `reset_monthly_leaderboard`)
```
1. Fetch top 10 users by monthly_hp_earned
2. Archive rank #1 → hall_of_fame table
3. Archive ranks 1-10 → spin_win_entries table (for Spin & Win prizes)
4. Archive all → leaderboard_monthly table
5. Set monthly_hp_earned = 0 for ALL users
```

### Spin & Win Prizes (Ranks 2-10)
- Ranks 2-10 earn a spin entry (`spin_win_entries.spin_used = false`)
- Prizes: configured in `spin_win_entries.spin_result` after spin
- Rank 1: goes to Hall of Fame (permanent record)

### Hall of Fame
- Permanent record of monthly #1 winners
- One entry per month (unique constraint on `month`)
- Never reset or deleted

---

## 10. Flash Redemption Rules

```
Flash sale configured in flash_redemptions table:
  - reward_id (which reward is on flash)
  - quantity_limit (default 5)
  - window_starts_at / window_ends_at
  - discount_percentage (default 50%)

User calls POST /api/rewards/:id/flash-redeem:
  1. Check: flash sale exists and is_active = true
  2. Check: window_ends_at > now()
  3. Count existing redemptions in this window
  4. Check: count < quantity_limit
  5. Calculate: discounted_cost = hp_cost × (1 - 0.50)
  6. Check: user active_balance >= discounted_cost
  7. Create reward_redemption
  8. Deduct discounted HP from active balance
```

---

## 11. Marketplace HP Pricing Formula

Used for all marketplace rewards (food items, merch, experiences):

```
effective_cost = item_cost + margin_share × (perceived_value - item_cost)

raw_hp = effective_cost / HP_LIABILITY_VALUE
       = effective_cost / 0.185

hp_price = ceil(raw_hp / 50) × 50   ← always rounds UP to nearest 50
```

### Default margin_share = 0.40 (food), 0.50 (merch)

### Examples
| Item | Cost | Perceived | margin_share | HP Price |
|------|------|-----------|--------------|----------|
| Chicken Lap | ₦1,919 | ₦4,700 | 0.40 | 16,400 HP |
| Whole Chicken | ₦7,965 | ₦18,500 | 0.40 | 65,850 HP |
| Sticker Pack | ₦150 | ₦500 | 0.50 | 1,800 HP |
| T-Shirt | ₦1,800 | ₦4,000 | 0.50 | 15,700 HP |
| Hoodie | ₦3,500 | ₦8,000 | 0.50 | 31,100 HP |

---

## 12. Payment & Wallet Rules

### Payment Methods
- `wallet` — deducts from user's wallet balance
- `card` — initialises Paystack payment, confirmed via webhook
- `split` — part wallet, part card

### Wallet Funding
- Card payments via Paystack `initialize_payment()` → redirect → `charge.success` webhook
- Bank transfers via Paystack DVA (dedicated virtual account) → `transfer.success` webhook
- Minimum top-up: ₦100 (card), no minimum on bank transfer

### Wallet Top-up HP
- 50 HP ACTIVE awarded when a single wallet funding ≥ ₦3,000
- Fired in `credit_wallet()` service, not in the webhook directly

### Webhook Security
- All Paystack webhooks verified via HMAC-SHA512 signature
- Idempotency: `webhook_events.idempotency_key = "paystack:{event_type}:{reference}"`
- Duplicate webhooks are silently ignored (200 OK returned)

### Split Payment Logic
- `wallet_amount` deducted immediately from wallet on order creation
- `card_amount` collected via Paystack
- Order confirmed only when BOTH components are settled

---

## 13. Notification Triggers

| Event | Type | Channels | When |
|-------|------|----------|------|
| HP earned from order | `hp_earned` | in_app | Order delivered |
| HP unlocked | `hp_unlocked` | in_app | Order delivered |
| Tier upgrade | `tier_upgrade` | in_app, email | Tier recalculated |
| Tier grace period started | `tier_grace_period` | in_app, email | Daily cron |
| Tier dropped | `tier_dropped` | in_app, email | Grace period expired |
| Referral completed | `referral_completed` | in_app | Friend's first order |
| Referral milestone | `referral_milestone` | in_app, email | 5th or 10th referral |
| Birthday bonus | `birthday_bonus` | in_app, email | Daily cron on birthday |
| Reward redeemed | `reward_redeemed` | in_app, email | On redemption |
| Wallet funded | `wallet_funded` | in_app, email | Paystack webhook |
| HP expired | `hp_expired` | in_app, email | Weekly cron |
| Abandoned cart | `abandoned_cart` | in_app, email | Admin nudge or cron |

---

## 14. Rate Limits & Caps

### API Rate Limits
| Endpoint | Max Requests | Window |
|----------|-------------|--------|
| `POST /api/auth/register` | 10 | 1 hour |
| `POST /api/auth/login` | 20 | 15 minutes |
| `POST /api/auth/reset-password` | 5 | 1 hour |
| `POST /api/orders` | 10 | 5 minutes |

### Business Caps
| Rule | Cap |
|------|-----|
| Review HP | 1× per calendar month |
| Referral HP | 3× per calendar month |
| Event check-in HP | 3× per calendar month |
| Welcome bonus | Once ever per account |
| Birthday HP | Once per birthday (month check) |
| Flash redemption | 5 users per window |
| Admin users per page | 200 max |
| Orders per page | 100 max |
