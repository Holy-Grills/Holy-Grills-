# Holy Grills — Developer Change Cookbook
## The Complete Guide to Modifying Any Feature

> **Who this is for:** Any developer who needs to change a business rule, rename a feature, add a new thing, or understand where each value lives. Read this before touching any code.

---

## Verdict: How Hard Is It to Change Things?

| Change Type | Difficulty | Files to Change | Code Deploy? |
|-------------|-----------|-----------------|--------------|
| Rename a tier (display name) | ⭐ Trivial | 1 SQL statement | No |
| Change tier HP threshold | ⭐ Trivial | 1 SQL statement | No |
| Change HP earn amounts (referral, birthday, etc.) | ⭐ Easy | `app/config.py` only | Yes (restart) |
| Add a menu item, promo code, reward, challenge | ⭐ Easy | 1 SQL INSERT | No |
| **Change tier earn multiplier %** | ⚠️ Medium | `app/config.py` + `hp_service.py` + 1 SQL | Yes (restart) |
| Rename a tier slug | ⚠️ Medium | 1 SQL + `hp_service.py` + tests | Yes (restart) |
| Add a new HP earn event | ⚠️ Medium | `hp_service.py` + `config.py` + route file | Yes (restart) |
| Add a new notification type | ⚠️ Medium | DB enum (migration) + service call | Yes (migration + restart) |
| Add a completely new API feature | 🔧 Standard | 5 files (service + Flask + FastAPI + schema + tests) | Yes (restart) |
| Change order status flow | 🔧 Standard | `order_service.py` (1 dict) | Yes (restart) |
| Add a new payment method | 🔴 Complex | `payment_service.py` + webhook + order flow | Yes (restart) |

**Key Rule:** Most business rule changes are in `app/config.py` only. Most data changes (menu, promos, rewards) are SQL-only. The one exception that trips developers is the **tier multiplier**, which lives in two places — explained in full below.

---

## SECTION 1: Tier System Changes

### 1.1 — Rename a Tier Display Name

**Example:** Change "Ember" → "Starter"

**Difficulty:** ⭐ Trivial. Zero code change. Zero deploy.

```sql
-- Run in Supabase Dashboard → SQL Editor
UPDATE tiers SET name = 'Starter' WHERE slug = 'ember';
```

That's it. The `name` column is for display only. The backend uses `slug` as the identifier everywhere.

**Verify:**
```sql
SELECT slug, name, min_hp_threshold, earn_multiplier FROM tiers ORDER BY sort_order;
```

---

### 1.2 — Rename a Tier Slug

**Example:** Change slug `"ember"` → `"starter"`

**Difficulty:** ⚠️ Medium. Requires code change + SQL.

The slug is used as an identifier in two code locations:

**Step 1 — Update the SQL:**
```sql
UPDATE tiers SET slug = 'starter' WHERE slug = 'ember';
```

**Step 2 — Update `app/services/hp_service.py`:**

Find the `TIER_SLUGS_MULTIPLIER` dict (around line 74) and update it:

```python
# Before
TIER_SLUGS_MULTIPLIER = {
    "ember":   1.00,
    "starter": 1.00,   # ← already has an alias; add/update as needed
    ...
}

# After — add the new slug
TIER_SLUGS_MULTIPLIER = {
    "starter": 1.00,   # ← renamed
    "flame":   1.08,
    "blaze":   1.15,
    "holy":    1.25,
}
```

**Step 3 — Update `app/config.py`:**

Find `TIER_MULTIPLIERS` and `TIER_THRESHOLDS` and rename the key:

```python
TIER_MULTIPLIERS = {
    "starter": 1.00,   # was "ember"
    ...
}
TIER_THRESHOLDS = {
    "starter": 0,      # was "ember"
    ...
}
```

**Step 4 — Update tests (conftest.py):**
```python
# tests/conftest.py and fastapi_app/tests/conftest.py
SAMPLE_TIERS = [
    {"slug": "starter", "sort_order": 1, "min_hp_threshold": 0, "earn_multiplier": 1.00},
    ...
]
```

**Step 5 — Deploy and run tests:**
```bash
python -m pytest tests/ fastapi_app/tests/ -q
```

---

### 1.3 — Change Tier HP Threshold (What HP is required to reach a tier)

**Example:** Make Flame start at 3,000 HP instead of 2,500 HP

**Difficulty:** ⭐ Trivial. Zero code change.

The service reads thresholds from the DB at runtime in `recalculate_tier()`.

```sql
UPDATE tiers SET min_hp_threshold = 3000 WHERE slug = 'flame';
```

**Effect:** Takes effect on the next daily cron run (`recalculate_120day_hp` at 02:00 WAT). Existing users at Flame tier are not immediately dropped — the cron will handle transitions with the 7-day grace period.

**Also update `app/config.py` for documentation consistency (not used by code):**
```python
TIER_THRESHOLDS = {
    "ember": 0,
    "flame": 3000,    # updated
    "blaze": 7500,
    "holy":  20000,
}
```

> ⚠️ Note: `TIER_THRESHOLDS` in `config.py` is documentation only — the service does NOT read from it. The live DB value is what matters.

---

### 1.4 — Change Tier Earn Multiplier % (HP bonus on food orders)

**Example:** Give Flame members 12% bonus instead of 8%

**Difficulty:** ⚠️ Medium. **TWO places must be updated.**

> **Why two places?** `recalculate_tier()` reads `earn_multiplier` from the DB (for updating `profiles.tier_bonus_multiplier`). But `award_food_order_hp()` uses `TIER_SLUGS_MULTIPLIER` — a hardcoded dict in `hp_service.py`. If you only update the DB, existing food order HP calculations will still use the old rate.

**Step 1 — Update the DB:**
```sql
UPDATE tiers SET earn_multiplier = 1.12 WHERE slug = 'flame';
```

**Step 2 — Update `app/services/hp_service.py`:**

Find `TIER_SLUGS_MULTIPLIER` (around line 74):
```python
TIER_SLUGS_MULTIPLIER = {
    "ember":   1.00,
    "starter": 1.00,
    "flame":   1.12,   # was 1.08 — UPDATED HERE
    "blaze":   1.15,
    "inferno": 1.15,
    "holy":    1.25,
}
```

**Step 3 — Update `app/config.py` for consistency:**
```python
TIER_MULTIPLIERS = {
    "ember": 1.00,
    "flame": 1.12,    # was 1.08 — UPDATED HERE
    "blaze": 1.15,
    "holy":  1.25,
}
```

**Step 4 — Update test expectations** in `tests/conftest.py`:
```python
SAMPLE_TIERS = [
    {"slug": "flame", "sort_order": 2, "min_hp_threshold": 2500, "earn_multiplier": 1.12},  # updated
    ...
]
```

**Step 5 — Apply to existing Flame users** (optional, for immediate effect):
```sql
UPDATE profiles
SET tier_bonus_multiplier = 1.12
WHERE id IN (
    SELECT user_id FROM user_tiers
    WHERE tier_id = (SELECT id FROM tiers WHERE slug = 'flame')
    AND is_current = true
);
```

**Step 6 — Run tests and deploy:**
```bash
python -m pytest tests/ fastapi_app/tests/ -q
```

---

## SECTION 2: HP Economy Changes (config.py only)

All values in this section live in `app/config.py`. Change the value, restart the server, done. No DB migration, no SQL.

### 2.1 — Change the Base HP Earn Rate

**Example:** Change from 1 HP per ₦10 to 1 HP per ₦8

```python
# app/config.py
HP_PER_NAIRA_FOOD = 0.125   # was 0.1 (1 HP per ₦10 = 0.1 HP/₦)
                             # 0.125 = 1 HP per ₦8
```

This single constant controls all food order HP. The calculation in `hp_service.py`:
```python
base_hp = int(order_total * config["HP_PER_NAIRA_FOOD"])
```

Restart the server. All new delivered orders use the new rate immediately.

---

### 2.2 — Change Welcome Bonus Amount

```python
# app/config.py
WELCOME_BONUS_HP = 100   # was 50
```

**Effect:** New first-time deliveries award 100 HP. Existing users who already received the welcome bonus are NOT re-awarded (idempotency check prevents it).

---

### 2.3 — Change Referral HP Amount

```python
# app/config.py
REFERRAL_HP = 100   # was 75
```

**Effect:** Future referral completions award 100 HP. Past referrals are not retroactively updated.

> Note: `REFERRAL_HP` is also used for milestone calculations. Check `REFERRAL_MILESTONE_5_HP` and `REFERRAL_MILESTONE_10_HP` if you want milestone bonuses to scale proportionally.

---

### 2.4 — Change Birthday HP Amount

```python
# app/config.py
BIRTHDAY_HP = 200   # was 150
```

**Effect:** Next day the `birthday_hp_awards` cron runs (daily 08:00 WAT), users with today's birthday get 200 HP.

---

### 2.5 — Change Wallet Top-up HP and Minimum

```python
# app/config.py
WALLET_TOPUP_HP = 75      # was 50 — change the HP award amount
WALLET_TOPUP_MIN = 5000   # was 3000 — change the minimum qualifying top-up
```

The check in `wallet_service.py`:
```python
if amount >= config["WALLET_TOPUP_MIN"]:
    award_active_hp(..., amount=config["WALLET_TOPUP_HP"], ...)
```

---

### 2.6 — Change Pending Pool Ceiling Ratio

The pending pool ceiling = `max(active_balance × RATIO, FLOOR)`.

```python
# app/config.py
PENDING_CEILING_RATIO = 0.40   # was 0.35 — now 40% of active balance
PENDING_FLOOR_HP = 300         # was 200 — minimum ceiling for new users
```

**Effect:** Users can hold more pending HP before overflow kicks in. No migration needed.

---

### 2.7 — Change HP Pending Unlock Rate

HP unlocked from pending per ₦1,000 food spend:

```python
# app/config.py
HP_UNLOCK_RATE = 150   # was 100 — now 150 HP unlocked per ₦1,000 spent
```

The calculation in `hp_service.py`:
```python
amount_to_unlock = math.floor(food_spend / 1000) * config["HP_UNLOCK_RATE"]
```

---

### 2.8 — Change HP Expiry Rules

```python
# app/config.py
HP_EXPIRY_INACTIVITY_DAYS = 60   # was 90 — trigger expiry after 60 days
HP_EXPIRY_BREAKAGE_RATE = 0.15   # was 0.25 — expire 15% instead of 25%
TIER_GRACE_PERIOD_DAYS = 14      # was 7 — extend grace before tier drop
```

**Effect:** The weekly `hp_expiry_check` cron picks up the new values automatically.

---

### 2.9 — Change Flash Sale Discount and Limit

```python
# app/config.py
FLASH_DISCOUNT_PCT = 0.40   # was 0.50 — now 40% off instead of 50%
FLASH_MAX_QTY = 10          # was 5 — allow 10 users per flash window
```

---

### 2.10 — Change HP Bundle Price (Event Hosts)

```python
# app/config.py
HP_BUNDLE_PRICE_PER_HP = 3.0   # was 5.0 — event hosts pay ₦3 per HP
```

---

## SECTION 3: Data Changes (SQL Only — No Code, No Deploy)

These changes only require running SQL in the Supabase Dashboard → SQL Editor.

### 3.1 — Add a New Menu Category

```sql
INSERT INTO menu_categories (name, slug, description, sort_order, is_active)
VALUES ('Desserts', 'desserts', 'Sweet treats and pastries', 15, true);
```

---

### 3.2 — Add a New Menu Item

```sql
-- First find the category_id
SELECT id FROM menu_categories WHERE slug = 'grills';

-- Then insert the item
INSERT INTO menu_items (
    name, slug, description, category_id, price,
    is_available, daily_limit, sort_order
) VALUES (
    'Fish Pepper Soup', 'fish-pepper-soup',
    'Spiced catfish in rich broth',
    '<category_id>',
    2500.00,
    true,
    50,    -- 50 portions max per day (NULL for unlimited)
    5
);
```

**To add a sold-out item:**
```sql
UPDATE menu_items SET is_available = false WHERE slug = 'fish-pepper-soup';
```

**To archive (hide without deleting):**
```sql
UPDATE menu_items SET is_archived = true WHERE slug = 'fish-pepper-soup';
```

---

### 3.3 — Add a New Promo Code

```sql
INSERT INTO promo_codes (
    code, discount_type, discount_value, scope,
    min_order_amount, max_uses, valid_from, valid_until, is_active
) VALUES (
    'LAUNCH50',         -- the code users type
    'percentage',       -- 'percentage' or 'flat'
    50.00,              -- 50% off (or ₦50 for flat)
    'cart_wide',        -- 'cart_wide' or 'item_specific'
    2000.00,            -- min order ₦2,000
    500,                -- max 500 uses total (NULL for unlimited)
    now(),
    now() + interval '30 days',
    true
);
```

**To deactivate a promo code:**
```sql
UPDATE promo_codes SET is_active = false WHERE code = 'LAUNCH50';
```

---

### 3.4 — Add a New Reward to the Rewards Store

```sql
INSERT INTO rewards (
    name, slug, description, category,
    hp_cost, quantity_available, is_active
) VALUES (
    'Free Suya Stick (3pcs)', 'free-suya-3',
    'Redeem for 3 suya sticks on your next order',
    'food',     -- see reward_category enum below
    120,        -- HP cost
    100,        -- stock available (NULL for unlimited)
    true
);
```

**Reward category enum values:** `food`, `discount`, `event_ticket`, `service_voucher`, `giveaway_entry`, `exclusive_perk`

**To make a reward tier-gated (e.g. Flame and above only):**
```sql
UPDATE rewards
SET min_tier_id = (SELECT id FROM tiers WHERE slug = 'flame')
WHERE slug = 'free-suya-3';
```

---

### 3.5 — Add a New Challenge

```sql
INSERT INTO challenges (
    title, description, type,
    hp_reward, max_completions_per_user, is_active,
    starts_at, ends_at
) VALUES (
    'Loyal June', 'Order 5 times in June 2026',
    'order_streak',    -- see challenge_type enum below
    150,               -- HP reward on completion
    1,                 -- max 1 completion per user
    true,
    '2026-06-01 00:00:00+01',
    '2026-06-30 23:59:59+01'
);
```

**Challenge type enum values:** `order_streak`, `first_marketplace`, `review`, `referral_milestone`, `social_share`, `admin_custom`, `monthly_challenge`

---

### 3.6 — Change Kitchen Daily Order Capacity

```sql
UPDATE kitchen_settings SET value = '200' WHERE key = 'daily_order_capacity';
```

Takes effect immediately — the kitchen capacity check reads this on every incoming order.

---

### 3.7 — Change Operating Hours

```sql
-- Close on Sundays
UPDATE operating_hours SET is_closed = true WHERE day = 'sunday';

-- Change Saturday hours
UPDATE operating_hours
SET open_time = '10:00:00', close_time = '22:00:00'
WHERE day = 'saturday';
```

---

## SECTION 4: Adding a New HP Earn Event

**Example:** Add "Social Share HP" — user earns 25 HP when they share on Instagram and an admin verifies it.

This is the most common "new HP feature" pattern. You need 5 things:

**Step 1 — Add the constant to `app/config.py`:**
```python
SOCIAL_SHARE_HP = 25   # already exists — adding as example
# For a new event:
PARTNERSHIP_SHARE_HP = 30   # new value
```

**Step 2 — Add the TXN_TYPE mapping in `app/services/hp_service.py`:**

Find `TXN_TYPE_MAP` near the top of the file:
```python
TXN_TYPE_MAP = {
    ...
    "social":           "earn_challenge",   # existing
    "partnership":      "earn_challenge",   # new entry — maps to an existing enum value
    ...
}
```

> Note: If you need a BRAND NEW transaction type (not mapping to an existing enum), you must add it to the `hp_transaction_type` enum in the DB via a migration — see Section 5.

**Step 3 — Add the service function in `app/services/hp_service.py`:**

```python
def award_partnership_hp(user_id: str, share_id: str) -> dict:
    """Award HP for verified partnership share. One-time per share."""
    config = current_app.config

    # Idempotency check — did we already award this share?
    db = get_db()
    existing = (
        db.table("hp_transactions")
        .select("id")
        .eq("user_id", user_id)
        .eq("reference_id", share_id)
        .eq("source_type", "partnership")
        .execute()
    )
    if existing:
        return {"awarded": 0, "reason": "Already awarded for this share"}

    amount = config.get("PARTNERSHIP_SHARE_HP", 30)
    return earn_pending_hp(
        user_id=user_id,
        amount=amount,
        source_type="partnership",
        reference_id=share_id,
        notes="Partnership share verified",
    )
```

**Step 4 — Add the Flask route in `app/routes/` (e.g. `app/routes/admin.py`):**

```python
@admin_bp.route("/verify-partnership-share", methods=["POST"])
@require_role("admin")
def verify_partnership_share():
    data = request.get_json(force=True)
    user_id = data.get("user_id")
    share_id = data.get("share_id")
    if not user_id or not share_id:
        return jsonify({"error": "user_id and share_id required"}), 400
    try:
        from app.services.hp_service import award_partnership_hp
        result = award_partnership_hp(user_id, share_id)
        return jsonify(result), 200
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
```

**Step 5 — Add the FastAPI router endpoint in `fastapi_app/routers/admin.py`:**

```python
class VerifyPartnershipShareRequest(BaseModel):
    user_id: str
    share_id: str

@router.post("/verify-partnership-share")
def verify_partnership_share(
    body: VerifyPartnershipShareRequest,
    user: UserContext = Depends(require_role("admin")),
):
    from app.services.hp_service import award_partnership_hp
    db = get_db()
    result = award_partnership_hp(body.user_id, body.share_id)
    return result
```

**Step 6 — Write tests:**

```python
# tests/test_stress_b_hp_earn.py
class TestB_PartnershipShareHP:
    def test_awards_pending_hp(self, app):
        earned = []
        def capture(user_id, amount, **kwargs):
            earned.append(amount)
            return {"added_to_pending": amount, "added_to_overflow": 0}

        with patch("app.services.hp_service.get_db", return_value=make_mock_db({"hp_transactions": []})), \
             patch("app.services.hp_service.earn_pending_hp", side_effect=capture):
            from app.services.hp_service import award_partnership_hp
            result = award_partnership_hp(STUDENT_ID, "share-abc-123")

        assert 30 in earned

    def test_idempotent_double_award(self, app):
        existing_txn = [{"id": "existing"}]
        with patch("app.services.hp_service.get_db", return_value=make_mock_db({"hp_transactions": existing_txn})):
            from app.services.hp_service import award_partnership_hp
            result = award_partnership_hp(STUDENT_ID, "share-abc-123")
        assert result["awarded"] == 0
```

---

## SECTION 5: Adding a New API Feature (Full Pattern)

**Example:** Add a "user feedback" feature — users can submit written feedback.

This is the standard pattern for any completely new feature. Exactly 5 files.

### File 1: Service — `app/services/feedback_service.py` (NEW FILE)

```python
from app.db import get_db

def submit_feedback(user_id: str, message: str, category: str) -> dict:
    """Submit user feedback. One submission per 24 hours per user."""
    if not message or len(message.strip()) < 10:
        raise ValueError("Feedback must be at least 10 characters")
    if len(message) > 2000:
        raise ValueError("Feedback must be under 2,000 characters")

    db = get_db()
    row = db.table("user_feedback").insert({
        "user_id": user_id,
        "message": message.strip(),
        "category": category,
    }).execute()
    return {"id": row["id"], "submitted": True}


def list_feedback(limit: int = 50, offset: int = 0) -> list:
    """Admin: list all feedback, newest first."""
    db = get_db()
    return (
        db.table("user_feedback")
        .select("*")
        .order("created_at", ascending=False)
        .limit(limit)
        .offset(offset)
        .execute()
    )
```

### File 2: Flask Route — `app/routes/feedback.py` (NEW FILE)

```python
from flask import Blueprint, request, jsonify, g
from app.middleware.auth import require_auth, require_role
from app.services.feedback_service import submit_feedback, list_feedback

feedback_bp = Blueprint("feedback", __name__)

@feedback_bp.route("", methods=["POST"])
@require_auth
def post_feedback():
    data = request.get_json(force=True) or {}
    try:
        result = submit_feedback(g.user_id, data.get("message", ""), data.get("category", "general"))
        return jsonify(result), 201
    except ValueError as e:
        return jsonify({"error": str(e)}), 400

@feedback_bp.route("", methods=["GET"])
@require_role("admin")
def get_feedback():
    limit = min(int(request.args.get("limit", 50)), 200)
    offset = int(request.args.get("offset", 0))
    return jsonify(list_feedback(limit, offset)), 200
```

**Register the blueprint in `app/__init__.py`:**
```python
from app.routes.feedback import feedback_bp
app.register_blueprint(feedback_bp, url_prefix="/api/feedback")
```

### File 3: FastAPI Router — `fastapi_app/routers/feedback.py` (NEW FILE)

```python
from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field
from fastapi_app.deps import get_current_user, require_role, UserContext
from app.services.feedback_service import submit_feedback, list_feedback

router = APIRouter()

class SubmitFeedbackRequest(BaseModel):
    message: str = Field(..., min_length=10, max_length=2000)
    category: str = "general"

@router.post("", status_code=201)
def post_feedback(body: SubmitFeedbackRequest, user: UserContext = Depends(get_current_user)):
    return submit_feedback(user.user_id, body.message, body.category)

@router.get("")
def get_all_feedback(
    limit: int = 50,
    offset: int = 0,
    user: UserContext = Depends(require_role("admin")),
):
    return list_feedback(min(limit, 200), offset)
```

**Register in `fastapi_app/main.py`:**
```python
from fastapi_app.routers import feedback
app.include_router(feedback.router, prefix="/api/feedback", tags=["Feedback"])
```

### File 4: DB Migration — `migrations/006_user_feedback.sql` (NEW FILE)

```sql
-- Migration 006: user_feedback table
CREATE TABLE IF NOT EXISTS user_feedback (
    id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id     uuid REFERENCES profiles(id) ON DELETE CASCADE,
    message     text NOT NULL CHECK (length(message) >= 10 AND length(message) <= 2000),
    category    text NOT NULL DEFAULT 'general',
    is_reviewed boolean DEFAULT false,
    admin_notes text,
    created_at  timestamptz DEFAULT now()
);

-- RLS
ALTER TABLE user_feedback ENABLE ROW LEVEL SECURITY;

-- User: own INSERT
CREATE POLICY "feedback_own_insert" ON user_feedback
    FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());

-- Admin: ALL
CREATE POLICY "feedback_admin_all" ON user_feedback
    FOR ALL TO authenticated USING (
        EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin', 'super_admin'))
    );

-- Performance index
CREATE INDEX IF NOT EXISTS idx_feedback_created ON user_feedback(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_feedback_user ON user_feedback(user_id);
```

**Run this in Supabase Dashboard → SQL Editor.**

### File 5: Tests — `tests/test_feedback.py` (NEW FILE)

```python
from unittest.mock import patch
from tests.conftest import make_mock_db, STUDENT_ID, ADMIN_ID

class TestFeedbackSubmit:
    def test_submit_valid_feedback(self, app):
        inserted = []
        def capture_insert(data):
            inserted.append(data)
            return {**data, "id": "feedback-uuid-001"}

        with patch("app.services.feedback_service.get_db", return_value=make_mock_db()):
            from app.services.feedback_service import submit_feedback
            result = submit_feedback(STUDENT_ID, "This app is amazing! Love it.", "general")

        assert result["submitted"] is True

    def test_reject_short_message(self, app):
        with patch("app.services.feedback_service.get_db", return_value=make_mock_db()):
            from app.services.feedback_service import submit_feedback
            try:
                submit_feedback(STUDENT_ID, "Too short", "general")
                assert False, "Should have raised"
            except ValueError as e:
                assert "10 characters" in str(e)

    def test_list_feedback_admin(self, app):
        sample = [{"id": "f1", "message": "Great food!", "category": "general"}]
        with patch("app.services.feedback_service.get_db", return_value=make_mock_db({"user_feedback": sample})):
            from app.services.feedback_service import list_feedback
            result = list_feedback()
        assert len(result) == 1
```

---

## SECTION 6: Changing the Order Status Flow

The valid order status transitions are a single Python dict in `app/services/order_service.py`:

```python
# app/services/order_service.py (around line 27)
VALID_TRANSITIONS = {
    "pending_payment": ["received", "cancelled"],
    "received":        ["preparing", "cancelled"],
    "preparing":       ["ready", "cancelled"],
    "ready":           ["dispatched", "cancelled"],
    "dispatched":      ["delivered", "attempted"],
    "attempted":       ["dispatched", "unclaimed"],
    "unclaimed":       ["cancelled"],
    "delivered":       [],   # terminal
    "cancelled":       [],   # terminal
    "refunded":        [],   # terminal
}
```

**Example: Allow admins to move orders from `preparing` back to `received`:**
```python
"preparing": ["ready", "received", "cancelled"],   # added "received"
```

> Important: `delivered` triggers HP award, welcome bonus, and referral completion. Do not add transitions OUT of `delivered` unless you also handle rollback of HP.

---

## SECTION 7: Adding a New Notification Type

**The `notification_type` enum is a DB enum**, so adding a new value requires a migration.

**Step 1 — Add the enum value (migration):**
```sql
-- migrations/006_new_notification_type.sql
ALTER TYPE notification_type ADD VALUE IF NOT EXISTS 'partnership_share';
```

> Note: Enum values can only be ADDED, never removed or renamed without full table recreation. Choose names carefully.

**Step 2 — Use it in the service:**
```python
from app.services.notification_service import send_notification

send_notification(
    user_id=user_id,
    notif_type="partnership_share",   # must match the enum value exactly
    title="Thanks for sharing!",
    body="Your social share has been verified. +30 HP incoming.",
    channels=["in_app"],
)
```

**Step 3 — Deploy and restart.**

---

## SECTION 8: Quick Reference — Where Every Value Lives

| Value | Where It Lives | How to Change |
|-------|---------------|---------------|
| Tier display name | `tiers.name` (DB) | SQL UPDATE |
| Tier slug | `tiers.slug` (DB) + `TIER_SLUGS_MULTIPLIER` (code) | SQL + code edit |
| Tier HP threshold | `tiers.min_hp_threshold` (DB) | SQL UPDATE |
| Tier earn multiplier | `tiers.earn_multiplier` (DB) + `TIER_SLUGS_MULTIPLIER` (code) | SQL + code edit |
| HP per ₦ (food) | `config.py` → `HP_PER_NAIRA_FOOD` | Edit config, restart |
| Welcome bonus | `config.py` → `WELCOME_BONUS_HP` | Edit config, restart |
| Referral HP | `config.py` → `REFERRAL_HP` | Edit config, restart |
| Birthday HP | `config.py` → `BIRTHDAY_HP` | Edit config, restart |
| Review HP | `config.py` → `REVIEW_HP` | Edit config, restart |
| Event check-in HP | `config.py` → `EVENT_CHECKIN_HP` | Edit config, restart |
| Social share HP | `config.py` → `SOCIAL_SHARE_HP` | Edit config, restart |
| Wallet topup HP | `config.py` → `WALLET_TOPUP_HP` | Edit config, restart |
| Wallet topup minimum | `config.py` → `WALLET_TOPUP_MIN` | Edit config, restart |
| Pending pool ratio | `config.py` → `PENDING_CEILING_RATIO` | Edit config, restart |
| Pending pool floor | `config.py` → `PENDING_FLOOR_HP` | Edit config, restart |
| HP unlock rate | `config.py` → `HP_UNLOCK_RATE` | Edit config, restart |
| Referral milestone (5×) | `config.py` → `REFERRAL_MILESTONE_5_HP` | Edit config, restart |
| Referral milestone (10×) | `config.py` → `REFERRAL_MILESTONE_10_HP` | Edit config, restart |
| Flash discount % | `config.py` → `FLASH_DISCOUNT_PCT` | Edit config, restart |
| Flash max users | `config.py` → `FLASH_MAX_QTY` | Edit config, restart |
| HP bundle price per HP | `config.py` → `HP_BUNDLE_PRICE_PER_HP` | Edit config, restart |
| HP expiry inactivity days | `config.py` → `HP_EXPIRY_INACTIVITY_DAYS` | Edit config, restart |
| HP expiry breakage rate | `config.py` → `HP_EXPIRY_BREAKAGE_RATE` | Edit config, restart |
| Tier grace period | `config.py` → `TIER_GRACE_PERIOD_DAYS` | Edit config, restart |
| Order status transitions | `order_service.py` → `VALID_TRANSITIONS` dict | Edit code, restart |
| Kitchen daily capacity | `kitchen_settings.value` (DB) | SQL UPDATE |
| Operating hours | `operating_hours` table (DB) | SQL UPDATE |
| Promo codes | `promo_codes` table (DB) | SQL INSERT/UPDATE |
| Rewards | `rewards` table (DB) | SQL INSERT/UPDATE |
| Challenges | `challenges` table (DB) | SQL INSERT/UPDATE |
| Menu items | `menu_items` table (DB) | SQL INSERT/UPDATE |
| Menu categories | `menu_categories` table (DB) | SQL INSERT/UPDATE |
| Notification types | `notification_type` enum (DB migration) | ALTER TYPE + restart |
| HP transaction types | `hp_transaction_type` enum (DB migration) | ALTER TYPE + restart |

---

## SECTION 9: Before You Deploy — Checklist

Every code change must pass this before going live:

```bash
# 1. Run the full test suite (must be 886/886 pass)
python -m pytest tests/ fastapi_app/tests/ -q

# 2. Check for obvious import errors
python -c "from app import create_app; create_app()"
python -c "from fastapi_app.main import create_fastapi_app; create_fastapi_app()"

# 3. If you changed config.py values that tests assert against:
#    Update the expected values in the affected test files

# 4. If you added a DB migration:
#    Run it in Supabase Dashboard → SQL Editor
#    Verify with: SELECT * FROM <new_table> LIMIT 1;

# 5. Deploy
gunicorn -w 4 -b 0.0.0.0:5000 "app:create_app()"
```

---

## SECTION 10: Common Mistakes to Avoid

| Mistake | Consequence | Prevention |
|---------|-------------|------------|
| Changing `tiers.earn_multiplier` in DB but not `TIER_SLUGS_MULTIPLIER` in code | Food order HP uses old multiplier | Always update both (see 1.4) |
| Inserting an order directly via Supabase client | Bypasses payment, validation, HP | Never. Use `POST /api/orders` only |
| Hardcoding HP amounts in routes/services | Config changes don't propagate | Always read from `current_app.config` |
| Using `reference_type` param in `earn_pending_hp()` | TypeError — no such param | Signature: `(user_id, amount, source_type, reference_id, notes)` |
| Forgetting idempotency check on new HP events | Double-awarding HP on retry | Always check `hp_transactions` for existing record first |
| Dropping or renaming a DB column | Breaks production queries | NEVER drop. Add `is_archived` flag instead |
| Changing a tier slug without updating `TIER_SLUGS_MULTIPLIER` | Tier slug falls back to 1.00× multiplier | Always update the dict (see 1.2) |
| Adding a new enum value without a migration | Inserting that value fails at DB level | Always add via `ALTER TYPE ... ADD VALUE` migration |
